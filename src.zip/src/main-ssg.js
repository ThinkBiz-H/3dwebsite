import { ViteSSG } from "vite-ssg";
import { createPinia } from "pinia";
import App from "./App.vue";
import { routerOptions, installGuards } from "./router";

import "./style.css";
import "./assets/article-content.css";

// Single entry for both `vite` (dev) and `vite-ssg build` (production).
// ViteSSG creates the router from routerOptions, so scrollBehavior and the
// auth guard are identical in dev, prerender and the hydrated client.
export const createApp = ViteSSG(App, routerOptions, ({ app, router, isClient }) => {
  app.use(createPinia());

  // The auth check needs the Firebase client session, which doesn't exist
  // while prerendering.
  if (isClient) installGuards(router);
});
