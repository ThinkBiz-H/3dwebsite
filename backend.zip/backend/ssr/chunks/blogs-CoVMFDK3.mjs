import { ac as createPostsService } from "../entry-server.mjs";
const blogs = createPostsService("blogs");
const getBlogs = blogs.list;
const getBlogById = blogs.getById;
const getBlog = blogs.getBySlug;
const blogSlugExists = blogs.slugExists;
const createBlog = blogs.create;
const updateBlog = blogs.update;
const deleteBlog = blogs.remove;
const incrementBlogViews = blogs.incrementViews;
export {
  getBlog as a,
  blogSlugExists as b,
  createBlog as c,
  deleteBlog as d,
  getBlogById as e,
  getBlogs as g,
  incrementBlogViews as i,
  updateBlog as u
};
