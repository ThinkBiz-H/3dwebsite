import { v as vueExports, s as ssrRenderAttrs_1, d as ssrInterpolate_1, C as contactStory, c as ssrRenderList_1, D as contactReviewProcess, E as contactNeverDo, F as contactCorrections, n as ssrRenderAttr_1, G as contactInfo, b as ssrRenderComponent_1, f as ssrRenderClass_1, _ as _sfc_main$9, H as officeHours, o as useSeoMeta, I as contactHero, J as contactGetInTouch, K as contactFaqs, L as contactClosing } from "../entry-server.mjs";
import { r as revealHeading, a as revealUp } from "./useReveal-BQH7su09.mjs";
import { _ as _sfc_main$a } from "./PageHero-C6df2H0i.mjs";
import { G as GlowCard, _ as _sfc_main$8 } from "./FeatureIcon-TMx3acNY.mjs";
import { _ as _sfc_main$b } from "./FaqSection-B4wyQSeE.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main$7 = {
  __name: "WhyWeStarted",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const paraEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(paraEl.value.children, { trigger: paraEl.value, start: "top 85%", y: 24, stagger: 0.1 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-4xl px-6 py-16 lg:px-10"
      }, _attrs))}><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(contactStory).heading)}</h2><div class="mt-8 space-y-5"><!--[-->`);
      ssrRenderList_1(vueExports.unref(contactStory).paragraphs, (p, i) => {
        _push(`<p class="max-w-2xl text-lg leading-8 text-black">${ssrInterpolate_1(p)}</p>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/WhyWeStarted.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "ReviewProcess",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const listEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(listEl.value.children, { trigger: listEl.value, start: "top 85%", y: 30, stagger: 0.08 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-4xl px-6 py-16 lg:px-10"
      }, _attrs))}><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(contactReviewProcess).heading)}</h2><p class="mt-4 max-w-2xl text-lg text-gray-500">${ssrInterpolate_1(vueExports.unref(contactReviewProcess).intro)}</p><div class="mt-12 divide-y divide-slate-200 border-t border-slate-200"><!--[-->`);
      ssrRenderList_1(vueExports.unref(contactReviewProcess).steps, (step, i) => {
        _push(`<div class="grid grid-cols-[56px_1fr] gap-6 py-8"><div class="font-display text-3xl font-bold leading-none text-blue-600">${ssrInterpolate_1(String(i + 1).padStart(2, "0"))}</div><div><h3 class="text-lg font-semibold text-gray-900">${ssrInterpolate_1(step.title)}</h3><p class="mt-2 leading-relaxed text-gray-500">${ssrInterpolate_1(step.description)}</p></div></div>`);
      });
      _push(`<!--]--></div><p class="mt-10 max-w-2xl text-sm leading-relaxed text-gray-500">${ssrInterpolate_1(vueExports.unref(contactReviewProcess).note)}</p></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/ReviewProcess.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "NeverDoList",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const listEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(listEl.value.children, { trigger: listEl.value, start: "top 85%", y: 20, stagger: 0.08 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-4xl px-6 py-16 lg:px-10"
      }, _attrs))}><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(contactNeverDo).heading)}</h2><div class="mt-10 space-y-4"><!--[-->`);
      ssrRenderList_1(vueExports.unref(contactNeverDo).items, (item) => {
        _push(`<div class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white px-6 py-4 shadow-soft"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="mt-0.5 h-5 w-5 shrink-0 text-blue-600"><path d="M20 6 9 17l-5-5"></path></svg><p class="text-[15px] leading-relaxed text-gray-700">${ssrInterpolate_1(item)}</p></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/NeverDoList.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "CorrectionsNote",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const boxEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(boxEl.value, { trigger: boxEl.value, start: "top 88%", y: 20 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-4xl px-6 py-16 lg:px-10"
      }, _attrs))}><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(contactCorrections).heading)}</h2><div class="mt-8 max-w-2xl rounded-2xl border-l-4 border-blue-500 bg-blue-50 p-8"><p class="text-[15px] leading-7 text-gray-700">${ssrInterpolate_1(vueExports.unref(contactCorrections).intro)} <a${ssrRenderAttr_1("href", vueExports.unref(contactCorrections).linkHref)} class="font-semibold text-blue-700 underline underline-offset-2 hover:text-blue-800">${ssrInterpolate_1(vueExports.unref(contactCorrections).linkLabel)}</a>. </p><p class="mt-4 text-[15px] leading-7 text-gray-700">${ssrInterpolate_1(vueExports.unref(contactCorrections).closing)}</p></div></section>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/CorrectionsNote.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "ContactInfoCards",
  __ssrInlineRender: true,
  setup(__props) {
    const gridEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealUp(gridEl.value.children, { trigger: gridEl.value, start: "top 85%", y: 40, stagger: 0.12 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({ class: "relative mx-auto max-w-7xl px-6 pb-16 lg:px-10" }, _attrs))}><div class="grid grid-cols-1 gap-5 sm:grid-cols-3"><!--[-->`);
      ssrRenderList_1(vueExports.unref(contactInfo), (item) => {
        _push(ssrRenderComponent_1(GlowCard, {
          key: item.title,
          class: "p-8",
          "data-cursor-hover": ""
        }, {
          default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex h-11 w-11 items-center justify-center rounded-full bg-blue-50 text-blue-600"${_scopeId}>`);
              _push2(ssrRenderComponent_1(_sfc_main$8, {
                name: item.icon
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="mt-6 text-sm font-medium text-gray-500"${_scopeId}>${ssrInterpolate_1(item.title)}</h3><p class="mt-1 text-lg font-semibold text-gray-900"${_scopeId}>${ssrInterpolate_1(item.detail)}</p><p class="mt-3 text-sm leading-relaxed text-gray-500"${_scopeId}>${ssrInterpolate_1(item.description)}</p>`);
            } else {
              return [
                vueExports.createVNode("div", { class: "flex h-11 w-11 items-center justify-center rounded-full bg-blue-50 text-blue-600" }, [
                  vueExports.createVNode(_sfc_main$8, {
                    name: item.icon
                  }, null, 8, ["name"])
                ]),
                vueExports.createVNode("h3", { class: "mt-6 text-sm font-medium text-gray-500" }, vueExports.toDisplayString(item.title), 1),
                vueExports.createVNode("p", { class: "mt-1 text-lg font-semibold text-gray-900" }, vueExports.toDisplayString(item.detail), 1),
                vueExports.createVNode("p", { class: "mt-3 text-sm leading-relaxed text-gray-500" }, vueExports.toDisplayString(item.description), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/ContactInfoCards.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "ContactForm",
  __ssrInlineRender: true,
  setup(__props) {
    vueExports.ref(null);
    const cardEl = vueExports.ref(null);
    vueExports.ref(null);
    const submitError = vueExports.ref("");
    const fields = vueExports.reactive({ name: "", email: "", subject: "", message: "" });
    const errors = vueExports.reactive({ name: "", email: "", subject: "", message: "" });
    const status = vueExports.ref("idle");
    vueExports.onMounted(() => {
      revealUp(cardEl.value, { trigger: cardEl.value, start: "top 85%", y: 30 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "cardEl",
        ref: cardEl,
        class: "rounded-2xl border border-slate-200/80 bg-white p-8 shadow-soft sm:p-10"
      }, _attrs))}>`);
      if (status.value !== "success") {
        _push(`<!--[--><h3 class="text-xl font-semibold text-gray-900">Send us a message</h3><p class="mt-2 text-sm text-gray-500">We read every one of these ourselves.</p><form class="mt-8 space-y-5" novalidate><div class="grid grid-cols-1 gap-5 sm:grid-cols-2"><div><label class="text-sm font-medium text-gray-700" for="contact-name">Name</label><input id="contact-name"${ssrRenderAttr_1("value", fields.name)} type="text"${ssrRenderAttr_1("data-invalid", !!errors.name)} class="${ssrRenderClass_1([errors.name ? "border-red-300 focus:ring-red-100" : "border-slate-200 focus:border-blue-400 focus:ring-blue-100", "mt-2 w-full rounded-xl border px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:ring-2"])}" placeholder="Jane Cooper">`);
        if (errors.name) {
          _push(`<p class="mt-1.5 text-xs text-red-500">${ssrInterpolate_1(errors.name)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div><label class="text-sm font-medium text-gray-700" for="contact-email">Email</label><input id="contact-email"${ssrRenderAttr_1("value", fields.email)} type="email"${ssrRenderAttr_1("data-invalid", !!errors.email)} class="${ssrRenderClass_1([errors.email ? "border-red-300 focus:ring-red-100" : "border-slate-200 focus:border-blue-400 focus:ring-blue-100", "mt-2 w-full rounded-xl border px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:ring-2"])}" placeholder="jane@email.com">`);
        if (errors.email) {
          _push(`<p class="mt-1.5 text-xs text-red-500">${ssrInterpolate_1(errors.email)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div><div><label class="text-sm font-medium text-gray-700" for="contact-subject">Subject</label><input id="contact-subject"${ssrRenderAttr_1("value", fields.subject)} type="text"${ssrRenderAttr_1("data-invalid", !!errors.subject)} class="${ssrRenderClass_1([errors.subject ? "border-red-300 focus:ring-red-100" : "border-slate-200 focus:border-blue-400 focus:ring-blue-100", "mt-2 w-full rounded-xl border px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:ring-2"])}" placeholder="Question about the Guided plan">`);
        if (errors.subject) {
          _push(`<p class="mt-1.5 text-xs text-red-500">${ssrInterpolate_1(errors.subject)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div><label class="text-sm font-medium text-gray-700" for="contact-message">Message</label><textarea id="contact-message" rows="5"${ssrRenderAttr_1("data-invalid", !!errors.message)} class="${ssrRenderClass_1([errors.message ? "border-red-300 focus:ring-red-100" : "border-slate-200 focus:border-blue-400 focus:ring-blue-100", "mt-2 w-full resize-none rounded-xl border px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:ring-2"])}" placeholder="What&#39;s on your mind?">${ssrInterpolate_1(fields.message)}</textarea>`);
        if (errors.message) {
          _push(`<p class="mt-1.5 text-xs text-red-500">${ssrInterpolate_1(errors.message)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
        if (submitError.value) {
          _push(`<p class="text-sm text-red-500">${ssrInterpolate_1(submitError.value)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(ssrRenderComponent_1(_sfc_main$9, {
          as: "button",
          type: "submit",
          class: "w-full",
          "data-cursor-hover": ""
        }, {
          default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate_1(status.value === "submitting" ? "Sending…" : "Send message")}`);
            } else {
              return [
                vueExports.createTextVNode(vueExports.toDisplayString(status.value === "submitting" ? "Sending…" : "Send message"), 1)
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</form><!--]-->`);
      } else {
        _push(`<div class="flex flex-col items-center py-10 text-center"><div class="flex h-14 w-14 items-center justify-center rounded-full bg-cyan-50 text-cyan-600"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-6 w-6"><path d="M4 10.5 8 14l8-8"></path></svg></div><h3 class="mt-5 text-xl font-semibold text-gray-900">Message sent.</h3><p class="mt-2 max-w-xs text-sm text-gray-500">Thanks for reaching out — we usually reply within one business day.</p><button class="mt-6 text-sm font-medium text-blue-600 hover:text-blue-700"> Send another message </button></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/ContactForm.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "VisitPanel",
  __ssrInlineRender: true,
  setup(__props) {
    const panelEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealUp(panelEl.value, { trigger: panelEl.value, start: "top 85%", y: 30 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "panelEl",
        ref: panelEl,
        class: "flex h-full flex-col overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-soft"
      }, _attrs))}><div class="relative h-48 overflow-hidden bg-slate-50"><svg class="absolute inset-0 h-full w-full text-slate-200" viewBox="0 0 400 200" fill="none"><path d="M0 40h400M0 90h400M0 140h400" stroke="currentColor" stroke-width="1"></path><path d="M60 0v200M160 0v200M260 0v200M340 0v200" stroke="currentColor" stroke-width="1"></path></svg><div class="pointer-events-none absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent"></div><div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"><span class="absolute inset-0 -m-4 animate-ping rounded-full bg-blue-500/20"></span><span class="relative flex h-9 w-9 items-center justify-center rounded-full bg-blue-600 text-white shadow-lift"><svg viewBox="0 0 20 20" fill="currentColor" class="h-4 w-4"><path fill-rule="evenodd" d="M10 2a6 6 0 0 0-6 6c0 4.5 6 10 6 10s6-5.5 6-10a6 6 0 0 0-6-6Zm0 8.25a2.25 2.25 0 1 1 0-4.5 2.25 2.25 0 0 1 0 4.5Z" clip-rule="evenodd"></path></svg></span></div></div><div class="flex flex-1 flex-col p-8"><h3 class="text-lg font-semibold text-gray-900">Visit our studio</h3><p class="mt-1 text-sm text-gray-500">148 Lafayette St, New York, NY — by appointment only.</p><div class="mt-6 space-y-3 border-t border-slate-100 pt-6"><!--[-->`);
      ssrRenderList_1(vueExports.unref(officeHours), (row) => {
        _push(`<div class="flex items-center justify-between text-sm"><span class="text-gray-500">${ssrInterpolate_1(row.day)}</span><span class="font-medium text-gray-900">${ssrInterpolate_1(row.hours)}</span></div>`);
      });
      _push(`<!--]--></div><div class="mt-6 flex gap-4 border-t border-slate-100 pt-6 text-sm text-gray-500"><a href="#" data-cursor-hover class="transition-colors hover:text-blue-600">Twitter</a><a href="#" data-cursor-hover class="transition-colors hover:text-blue-600">LinkedIn</a><a href="#" data-cursor-hover class="transition-colors hover:text-blue-600">Discord</a></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/contact/VisitPanel.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Contact",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: "Contact Cryptolearner | Crypto questions & Support",
      description: "Contact Cryptolearner for questions, feedback, suggestions, or support related to Bitcoin, blockchain, Ethereum, Web3, NFTs, and DeFi.",
      path: "/contact"
    });
    const getInTouchHeadingEl = vueExports.ref(null);
    const getInTouchSectionEl = vueExports.ref(null);
    const closingEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(getInTouchHeadingEl.value, {
        type: "words",
        trigger: getInTouchSectionEl.value,
        stagger: 0.03
      });
      revealUp(closingEl.value, {
        trigger: closingEl.value,
        start: "top 90%",
        y: 16
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent_1(_sfc_main$a, {
        eyebrow: vueExports.unref(contactHero).eyebrow,
        heading: vueExports.unref(contactHero).heading,
        subtitle: vueExports.unref(contactHero).subtitle
      }, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$7, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$6, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$5, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$4, null, null, _parent));
      _push(`<section class="relative mx-auto max-w-4xl px-6 pt-16 lg:px-10"><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(contactGetInTouch).heading)}</h2><p class="mt-4 max-w-2xl text-lg text-gray-500">${ssrInterpolate_1(vueExports.unref(contactGetInTouch).intro)}</p></section>`);
      _push(ssrRenderComponent_1(_sfc_main$3, null, null, _parent));
      _push(`<section class="relative mx-auto max-w-7xl px-6 pb-8 lg:px-10"><div class="grid grid-cols-1 gap-8 lg:grid-cols-2">`);
      _push(ssrRenderComponent_1(_sfc_main$2, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$1, null, null, _parent));
      _push(`</div></section><p class="mx-auto max-w-4xl px-6 pb-16 text-center text-xs font-medium text-amber-700 lg:px-10">${ssrInterpolate_1(vueExports.unref(contactGetInTouch).safetyNote)}</p>`);
      _push(ssrRenderComponent_1(_sfc_main$b, {
        faqs: vueExports.unref(contactFaqs),
        eyebrow: "Common questions",
        heading: "A few things people usually ask.",
        "section-id": "contact-faq"
      }, null, _parent));
      _push(`<section class="border-y border-slate-200 bg-blue-50/50 px-6 py-20 lg:px-10"><p class="mx-auto max-w-3xl text-center text-lg italic leading-8 text-gray-700">${ssrInterpolate_1(vueExports.unref(contactClosing).text)}</p></section><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/Contact.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
