import { o as useSeoMeta, s as ssrRenderAttrs_1, v as vueExports, b as ssrRenderComponent_1, _ as _sfc_main$1 } from "../entry-server.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main = {
  __name: "NotFound",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({ title: "Page not found", description: "This page does not exist.", path: "/404" });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({ class: "flex min-h-[70vh] flex-col items-center justify-center px-6 pt-16 text-center" }, _attrs))}><p class="font-display text-6xl font-bold text-blue-600">404</p><h1 class="mt-4 font-display text-2xl font-bold tracking-tight text-gray-900">This page wandered off.</h1><p class="mt-3 max-w-sm text-gray-500">The page you&#39;re looking for doesn&#39;t exist, or has moved somewhere else.</p>`);
      _push(ssrRenderComponent_1(_sfc_main$1, {
        as: "router-link",
        to: { name: "home" },
        class: "mt-8"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Back to home`);
          } else {
            return [
              vueExports.createTextVNode("Back to home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/NotFound.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
