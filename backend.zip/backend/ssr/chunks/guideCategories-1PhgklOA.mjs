const GUIDE_CATEGORIES = [
  { value: "getting-started", label: "Getting Started" },
  { value: "safety", label: "Safety" },
  { value: "coins", label: "Coins" },
  { value: "exchanges", label: "Exchanges" },
  { value: "taxes", label: "Taxes" },
  { value: "glossary", label: "Glossary" }
];
export {
  GUIDE_CATEGORIES as G
};
