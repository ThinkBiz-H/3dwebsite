import { u as useRoute, v as vueExports, P as PRERENDER_STATE, R as getServerPosts, o as useSeoMeta, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, c as ssrRenderList_1, O as SITE_URL } from "../entry-server.mjs";
import "./articles-DKIQjXzJ.mjs";
import "./blogs-CoVMFDK3.mjs";
import { b as breadcrumbSchema } from "./seoSchemas-BVwnPOyc.mjs";
import { s as slugify } from "./text-scSNyQat.mjs";
import { _ as _sfc_main$2 } from "./PageHero-C6df2H0i.mjs";
import { _ as _sfc_main$3 } from "./BlogCard-CSiqgIBk.mjs";
import _sfc_main$1 from "./NotFound-CXOAyI2n.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./AuthorAvatar--12iQkRN.mjs";
import "./useBookmarks-CDn9mt3k.mjs";
const _sfc_main = {
  __name: "TaxonomyArchive",
  __ssrInlineRender: true,
  props: {
    kind: { type: String, required: true }
    // 'category' | 'tag'
  },
  setup(__props) {
    const props = __props;
    const route = useRoute();
    const prerenderState = vueExports.inject(PRERENDER_STATE, null);
    const label = vueExports.ref("");
    const items = vueExports.ref([]);
    const loading = vueExports.ref(true);
    const stateKey = `${props.kind}:${route.params.slug}`;
    const kindLabel = vueExports.computed(() => props.kind === "tag" ? "Tag" : "Category");
    const path = vueExports.computed(() => `/${props.kind}/${route.params.slug}`);
    function toCard({ content, faqs, keyTakeaways, ...rest }, basePath) {
      return { ...rest, basePath };
    }
    function matches(post, slug) {
      if (props.kind === "tag") {
        return (post.tags || []).some((t) => slugify(String(t)) === slug);
      }
      return !!post.category && slugify(post.category) === slug;
    }
    function labelFor(post, slug) {
      if (props.kind === "tag") {
        return (post.tags || []).find((t) => slugify(String(t)) === slug) || slug;
      }
      return post.category;
    }
    function select(articles, blogs, slug) {
      const found = [
        ...articles.filter((p) => matches(p, slug)).map((p) => toCard(p, "/articles")),
        ...blogs.filter((p) => matches(p, slug)).map((p) => toCard(p, "/blog"))
      ].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      items.value = found;
      label.value = found.length ? labelFor(found[0], slug) : "";
      loading.value = false;
    }
    {
      const ssrContext = vueExports.useSSRContext();
      vueExports.onServerPrefetch(async () => {
        const [articles, blogs] = await Promise.all([
          getServerPosts("articles"),
          getServerPosts("blogs")
        ]);
        select(articles, blogs, route.params.slug);
        if (ssrContext && !items.value.length) ssrContext.statusCode = 404;
        if (prerenderState) {
          prerenderState[stateKey] = { label: label.value, items: items.value };
        }
      });
    }
    useSeoMeta(() => {
      if (loading.value || !items.value.length) return null;
      const url = `${SITE_URL}${path.value}`;
      const title = `${label.value} — ${kindLabel.value}`;
      const description = `${items.value.length} plain-language ${items.value.length === 1 ? "guide" : "guides"} on ${label.value} from the cryptolearner.us team.`;
      return {
        title,
        description,
        path: path.value,
        jsonLd: {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "CollectionPage",
              "@id": `${url}#collection`,
              url,
              name: title,
              description,
              isPartOf: { "@id": `${SITE_URL}/#organization` },
              mainEntity: {
                "@type": "ItemList",
                itemListElement: items.value.map((p, i) => ({
                  "@type": "ListItem",
                  position: i + 1,
                  url: `${SITE_URL}${p.basePath}/${p.slug}`,
                  name: p.title
                }))
              }
            },
            breadcrumbSchema([{ label: `${kindLabel.value}: ${label.value}` }])
          ]
        }
      };
    });
    return (_ctx, _push, _parent, _attrs) => {
      if (loading.value) {
        _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "px-6 pt-40 pb-16" }, _attrs))}><div class="mx-auto max-w-3xl animate-pulse space-y-6 text-center"><div class="mx-auto h-4 w-40 rounded-full bg-slate-100"></div><div class="mx-auto h-10 w-3/4 rounded-2xl bg-slate-100"></div></div></div>`);
      } else if (!items.value.length) {
        _push(ssrRenderComponent_1(_sfc_main$1, _attrs, null, _parent));
      } else {
        _push(`<div${ssrRenderAttrs_1(_attrs)}>`);
        _push(ssrRenderComponent_1(_sfc_main$2, {
          eyebrow: kindLabel.value,
          heading: label.value,
          subtitle: `${items.value.length} ${items.value.length === 1 ? "article" : "articles"}`
        }, null, _parent));
        _push(`<section class="px-6 pb-24 lg:px-10"><div class="mx-auto grid max-w-6xl grid-cols-1 gap-7 sm:grid-cols-2 lg:grid-cols-3"><!--[-->`);
        ssrRenderList_1(items.value, (post) => {
          _push(ssrRenderComponent_1(_sfc_main$3, {
            key: post.id,
            post,
            "base-path": post.basePath
          }, null, _parent));
        });
        _push(`<!--]--></div></section></div>`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/TaxonomyArchive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
