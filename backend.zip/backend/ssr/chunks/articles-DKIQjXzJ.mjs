import { ac as createPostsService } from "../entry-server.mjs";
const articles = createPostsService("articles");
const getArticles = articles.list;
const getArticleById = articles.getById;
const getArticle = articles.getBySlug;
const articleSlugExists = articles.slugExists;
const createArticle = articles.create;
const updateArticle = articles.update;
const deleteArticle = articles.remove;
const incrementArticleViews = articles.incrementViews;
export {
  getArticle as a,
  articleSlugExists as b,
  createArticle as c,
  getArticleById as d,
  deleteArticle as e,
  getArticles as g,
  incrementArticleViews as i,
  updateArticle as u
};
