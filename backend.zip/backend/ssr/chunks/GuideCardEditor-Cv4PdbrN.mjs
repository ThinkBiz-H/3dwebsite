import { u as useRoute, a as useRouter, v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, d as ssrInterpolate_1, V as ssrIncludeBooleanAttr, n as ssrRenderAttr_1, W as ssrLooseContain_1, X as ssrLooseEqual_1, c as ssrRenderList_1 } from "../entry-server.mjs";
import { s as slugify } from "./text-scSNyQat.mjs";
import { G as GUIDE_CATEGORIES } from "./guideCategories-1PhgklOA.mjs";
import { g as getGuideCardById } from "./guideCards-BmvXYWk4.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main = {
  __name: "GuideCardEditor",
  __ssrInlineRender: true,
  props: {
    id: { type: String, default: null }
  },
  setup(__props) {
    const props = __props;
    const route = useRoute();
    useRouter();
    const loading = vueExports.ref(!!props.id);
    const saving = vueExports.ref(false);
    const errorMsg = vueExports.ref("");
    const cardIdTouched = vueExports.ref(false);
    const form = vueExports.reactive({
      title: "",
      cardId: "",
      category: typeof route.query.category === "string" ? route.query.category : "",
      description: "",
      enabled: true
    });
    vueExports.watch(
      () => form.title,
      (title) => {
        if (!cardIdTouched.value) form.cardId = slugify(title);
      }
    );
    async function loadExisting() {
      const card = await getGuideCardById(props.id);
      if (!card) {
        errorMsg.value = "Guide card not found.";
        loading.value = false;
        return;
      }
      Object.assign(form, {
        title: card.title || "",
        cardId: card.cardId || "",
        category: card.category || "",
        description: card.description || "",
        enabled: card.enabled !== false
      });
      cardIdTouched.value = true;
      loading.value = false;
    }
    vueExports.onMounted(() => {
      if (props.id) loadExisting();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "mx-auto max-w-2xl" }, _attrs))}><div class="flex flex-wrap items-center justify-between gap-4"><div>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-guides" },
        class: "text-sm font-medium text-gray-400 hover:text-gray-600"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` ← Back to guide cards `);
          } else {
            return [
              vueExports.createTextVNode(" ← Back to guide cards ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="mt-2 font-display text-2xl font-bold tracking-tight text-gray-900">${ssrInterpolate_1(__props.id ? "Edit" : "New")} guide card </h1></div><button type="button" class="rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"${ssrIncludeBooleanAttr(saving.value) ? " disabled" : ""}>${ssrInterpolate_1(saving.value ? "Saving…" : "Save card")}</button></div>`);
      if (errorMsg.value) {
        _push(`<p class="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">${ssrInterpolate_1(errorMsg.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (loading.value) {
        _push(`<div class="mt-10 text-center text-sm text-gray-400">Loading…</div>`);
      } else {
        _push(`<div class="mt-8 space-y-6 rounded-2xl border border-slate-200/80 bg-white p-6 shadow-soft"><div><label class="text-xs font-medium text-gray-500">Title</label><input${ssrRenderAttr_1("value", form.title)} type="text" placeholder="What Is Bitcoin, Really?" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">Card id</label><input${ssrRenderAttr_1("value", form.cardId)} type="text" class="mt-1.5 w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-gray-600 outline-none focus:border-blue-400"><p class="mt-1 text-xs text-gray-400">Must be unique across every category — this is what an article&#39;s Guide Card field matches against.</p></div><div><label class="text-xs font-medium text-gray-500">Category</label><select class="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-400"><option value="" disabled${ssrIncludeBooleanAttr(Array.isArray(form.category) ? ssrLooseContain_1(form.category, "") : ssrLooseEqual_1(form.category, "")) ? " selected" : ""}>Choose a category</option><!--[-->`);
        ssrRenderList_1(vueExports.unref(GUIDE_CATEGORIES), (c) => {
          _push(`<option${ssrRenderAttr_1("value", c.value)}${ssrIncludeBooleanAttr(Array.isArray(form.category) ? ssrLooseContain_1(form.category, c.value) : ssrLooseEqual_1(form.category, c.value)) ? " selected" : ""}>${ssrInterpolate_1(c.label)}</option>`);
        });
        _push(`<!--]--></select></div><div><label class="text-xs font-medium text-gray-500">Description</label><textarea rows="3" placeholder="Shown on the card beneath the title." class="mt-1.5 w-full resize-none rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">${ssrInterpolate_1(form.description)}</textarea></div><label class="flex items-center justify-between text-sm text-gray-700"> Enabled <input${ssrIncludeBooleanAttr(Array.isArray(form.enabled) ? ssrLooseContain_1(form.enabled, null) : form.enabled) ? " checked" : ""} type="checkbox" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-400"></label></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/GuideCardEditor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
