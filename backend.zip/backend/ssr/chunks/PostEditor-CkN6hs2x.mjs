import { a as useRouter, v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, d as ssrInterpolate_1, V as ssrIncludeBooleanAttr, n as ssrRenderAttr_1, c as ssrRenderList_1, W as ssrLooseContain_1, X as ssrLooseEqual_1, f as ssrRenderClass_1, q as ssrRenderStyle_1 } from "../entry-server.mjs";
import { e as estimateReadingTime, s as slugify, b as stripHtml } from "./text-scSNyQat.mjs";
import { s as sanitizeArticleHtml } from "./sanitizeArticleHtml-CaIpdonf.mjs";
import { u as updateBlog, c as createBlog, b as blogSlugExists, e as getBlogById } from "./blogs-CoVMFDK3.mjs";
import { u as updateArticle, c as createArticle, b as articleSlugExists, d as getArticleById } from "./articles-DKIQjXzJ.mjs";
import { G as GUIDE_CATEGORIES } from "./guideCategories-1PhgklOA.mjs";
import { l as listGuideCards } from "./guideCards-BmvXYWk4.mjs";
import { R as RichTextEditor, _ as _sfc_main$1 } from "./ImageUploader-HSRiOueq.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./cloudinary-oFvjB332.mjs";
const _sfc_main = {
  __name: "PostEditor",
  __ssrInlineRender: true,
  props: {
    postType: { type: String, required: true },
    // 'blog' | 'article'
    id: { type: String, default: null }
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    const api = vueExports.computed(
      () => props.postType === "blog" ? {
        getById: getBlogById,
        slugExists: blogSlugExists,
        create: createBlog,
        update: updateBlog
      } : {
        getById: getArticleById,
        slugExists: articleSlugExists,
        create: createArticle,
        update: updateArticle
      }
    );
    const listRouteName = vueExports.computed(
      () => props.postType === "blog" ? "admin-blogs" : "admin-articles"
    );
    const docId = vueExports.ref(props.id);
    const loading = vueExports.ref(!!props.id);
    const saving = vueExports.ref(false);
    const autoSaveState = vueExports.ref("");
    const slugTouched = vueExports.ref(false);
    const previewOpen = vueExports.ref(false);
    const errorMsg = vueExports.ref("");
    const form = vueExports.reactive({
      title: "",
      slug: "",
      description: "",
      content: "",
      category: "",
      difficulty: "",
      coverImage: "",
      author: "",
      tags: "",
      featured: false,
      published: false,
      seoTitle: "",
      seoDescription: "",
      focusKeyword: "",
      ogImage: "",
      canonicalUrl: "",
      faqs: [],
      keyTakeaways: "",
      guideCategory: "",
      guideCardId: "",
      guideSection: ""
      // 👈 ADD THIS
    });
    const seoOpen = vueExports.ref(false);
    const views = vueExports.ref(0);
    const guideCardOptions = vueExports.ref([]);
    const guideCardsLoading = vueExports.ref(false);
    async function fetchGuideCardOptions(category) {
      if (!category) {
        guideCardOptions.value = [];
        return;
      }
      guideCardsLoading.value = true;
      try {
        guideCardOptions.value = await listGuideCards({ category });
      } finally {
        guideCardsLoading.value = false;
      }
    }
    const readingTime = vueExports.computed(() => estimateReadingTime(form.content));
    const previewHtml = vueExports.computed(() => sanitizeArticleHtml(form.content));
    vueExports.watch(
      () => form.title,
      (title) => {
        if (!slugTouched.value) form.slug = slugify(title);
      }
    );
    const seoTitleIsSlug = vueExports.computed(() => {
      const seo = form.seoTitle.trim();
      return !!seo && (seo === form.slug || /^[a-z0-9]+(-[a-z0-9]+)+$/.test(seo));
    });
    async function loadExisting() {
      const post = await api.value.getById(props.id);
      if (!post) {
        errorMsg.value = "Post not found.";
        loading.value = false;
        return;
      }
      Object.assign(form, {
        title: post.title || "",
        slug: post.slug || "",
        description: post.description || "",
        content: post.content || "",
        category: post.category || "",
        difficulty: post.difficulty || "",
        coverImage: post.coverImage || "",
        author: post.author || "",
        tags: Array.isArray(post.tags) ? post.tags.join(", ") : "",
        featured: !!post.featured,
        published: !!post.published,
        seoTitle: post.seoTitle || "",
        seoDescription: post.seoDescription || "",
        focusKeyword: post.focusKeyword || "",
        ogImage: post.ogImage || "",
        canonicalUrl: post.canonicalUrl || "",
        faqs: Array.isArray(post.faqs) ? post.faqs.map((f) => ({ ...f })) : [],
        keyTakeaways: Array.isArray(post.keyTakeaways) ? post.keyTakeaways.join("\n") : "",
        guideCategory: post.guideCategory || "",
        guideCardId: post.guideCardId || "",
        guideSection: post.guideSection || ""
      });
      views.value = post.views || 0;
      slugTouched.value = true;
      if (form.guideCategory) await fetchGuideCardOptions(form.guideCategory);
      loading.value = false;
    }
    function buildPayload() {
      return {
        title: form.title.trim(),
        slug: form.slug.trim(),
        description: form.description.trim() || stripHtml(form.content, 160),
        content: form.content,
        category: form.category.trim(),
        difficulty: form.difficulty,
        coverImage: form.coverImage,
        author: form.author.trim() || "cryptolearner.us Team",
        readingTime: readingTime.value,
        tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        featured: form.featured,
        published: form.published,
        seoTitle: seoTitleIsSlug.value ? "" : form.seoTitle.trim(),
        seoDescription: form.seoDescription.trim(),
        focusKeyword: form.focusKeyword.trim(),
        ogImage: form.ogImage,
        canonicalUrl: form.canonicalUrl.trim(),
        faqs: form.faqs.filter((f) => f.question.trim() && f.answer.trim()),
        keyTakeaways: form.keyTakeaways.split("\n").map((t) => t.trim()).filter(Boolean),
        guideCategory: form.guideCategory,
        guideCardId: form.guideCategory ? form.guideCardId : "",
        guideSection: form.guideSection || ""
      };
    }
    let persistChain = Promise.resolve();
    function persist(payload) {
      const run = persistChain.then(() => write(payload));
      persistChain = run.catch(() => {
      });
      return run;
    }
    async function write(payload) {
      if (payload.slug && await api.value.slugExists(payload.slug, docId.value)) {
        form.slug = `${payload.slug}-${Date.now().toString(36)}`;
        slugTouched.value = true;
        payload = { ...payload, slug: form.slug };
      }
      if (docId.value) {
        await api.value.update(docId.value, payload);
      } else {
        docId.value = await api.value.create(payload);
        router.replace({
          name: props.postType === "blog" ? "admin-blog-edit" : "admin-article-edit",
          params: { id: docId.value }
        });
      }
    }
    let autoSaveTimer = null;
    vueExports.watch(
      () => JSON.stringify(form),
      () => {
        if (loading.value || !form.title.trim()) return;
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(async () => {
          autoSaveState.value = "saving";
          try {
            await persist(buildPayload());
            autoSaveState.value = "saved";
          } catch (err) {
            console.error(
              "[post-editor] auto-save failed:",
              err.code,
              err.message,
              err
            );
            autoSaveState.value = "";
          }
        }, 2e3);
      }
    );
    vueExports.onBeforeUnmount(() => clearTimeout(autoSaveTimer));
    vueExports.onMounted(() => {
      if (props.id) loadExisting();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "mx-auto max-w-5xl" }, _attrs))}><div class="flex flex-wrap items-center justify-between gap-4"><div>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: listRouteName.value },
        class: "text-sm font-medium text-gray-400 hover:text-gray-600"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` ← Back to ${ssrInterpolate_1(__props.postType === "blog" ? "blogs" : "articles")}`);
          } else {
            return [
              vueExports.createTextVNode(" ← Back to " + vueExports.toDisplayString(__props.postType === "blog" ? "blogs" : "articles"), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="mt-2 font-display text-2xl font-bold tracking-tight text-gray-900">${ssrInterpolate_1(docId.value ? "Edit" : "New")} ${ssrInterpolate_1(__props.postType === "blog" ? "blog post" : "article")}</h1></div><div class="flex items-center gap-3">`);
      if (autoSaveState.value === "saving") {
        _push(`<span class="text-xs text-gray-400">Saving draft…</span>`);
      } else if (autoSaveState.value === "saved") {
        _push(`<span class="text-xs text-cyan-600">Draft saved</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button type="button" class="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"> Preview </button><button type="button" class="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"${ssrIncludeBooleanAttr(saving.value) ? " disabled" : ""}> Save draft </button><button type="button" class="rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"${ssrIncludeBooleanAttr(saving.value) ? " disabled" : ""}>${ssrInterpolate_1(form.published ? "Update & publish" : "Publish")}</button></div></div>`);
      if (errorMsg.value) {
        _push(`<p class="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">${ssrInterpolate_1(errorMsg.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (loading.value) {
        _push(`<div class="mt-10 text-center text-sm text-gray-400"> Loading… </div>`);
      } else {
        _push(`<div class="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[2fr,1fr]"><div class="space-y-6"><div><input${ssrRenderAttr_1("value", form.title)} type="text" placeholder="Post title" class="w-full border-none bg-transparent font-display text-3xl font-bold text-gray-900 outline-none placeholder:text-gray-300"><div class="mt-2 flex items-center gap-2 text-sm text-gray-400"><span>/${ssrInterpolate_1(__props.postType === "blog" ? "blog" : "articles")}/</span><input${ssrRenderAttr_1("value", form.slug)} type="text" class="flex-1 rounded-lg border border-transparent bg-slate-50 px-2 py-1 text-sm text-gray-600 outline-none focus:border-slate-200"></div></div><textarea rows="2" placeholder="Short description (used as excerpt and meta description)" class="w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm text-gray-700 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100">${ssrInterpolate_1(form.description)}</textarea>`);
        _push(ssrRenderComponent_1(RichTextEditor, {
          modelValue: form.content,
          "onUpdate:modelValue": ($event) => form.content = $event
        }, null, _parent));
        _push(`<div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><h3 class="text-sm font-semibold text-gray-900">Key takeaways</h3><p class="mt-1 text-xs text-gray-400"> Optional — one per line. Shown as a highlighted summary box (magazine-style pages only). </p><textarea rows="4" placeholder="Self-custody means holding your own private keys
Practice wallets remove real financial risk while learning" class="mt-3 w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm text-gray-700 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100">${ssrInterpolate_1(form.keyTakeaways)}</textarea></div><div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><div class="flex items-center justify-between"><h3 class="text-sm font-semibold text-gray-900">FAQs</h3><button type="button" class="text-xs font-medium text-blue-600 hover:text-blue-700"> + Add question </button></div><p class="mt-1 text-xs text-gray-400"> Optional — renders as an accordion on the post and adds FAQ structured data. </p>`);
        if (form.faqs.length) {
          _push(`<div class="mt-4 space-y-4"><!--[-->`);
          ssrRenderList_1(form.faqs, (faq, i) => {
            _push(`<div class="rounded-xl border border-slate-100 p-4"><div class="flex items-start gap-2"><div class="flex-1 space-y-2"><input${ssrRenderAttr_1("value", faq.question)} type="text" placeholder="Question" class="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"><textarea rows="2" placeholder="Answer" class="w-full resize-none rounded-lg border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">${ssrInterpolate_1(faq.answer)}</textarea></div><button type="button" class="mt-1 text-xs font-medium text-red-500 hover:text-red-600"> Remove </button></div></div>`);
          });
          _push(`<!--]--></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div><div class="space-y-6"><div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><h3 class="text-sm font-semibold text-gray-900">Cover image</h3><div class="mt-3">`);
        _push(ssrRenderComponent_1(_sfc_main$1, {
          modelValue: form.coverImage,
          "onUpdate:modelValue": ($event) => form.coverImage = $event
        }, null, _parent));
        _push(`</div></div><div class="space-y-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><h3 class="text-sm font-semibold text-gray-900">Details</h3><div><label class="text-xs font-medium text-gray-500">Category</label><input${ssrRenderAttr_1("value", form.category)} type="text" placeholder="Foundations" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">Difficulty</label><select class="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-400"><option value=""${ssrIncludeBooleanAttr(Array.isArray(form.difficulty) ? ssrLooseContain_1(form.difficulty, "") : ssrLooseEqual_1(form.difficulty, "")) ? " selected" : ""}>Not set</option><option value="Beginner"${ssrIncludeBooleanAttr(Array.isArray(form.difficulty) ? ssrLooseContain_1(form.difficulty, "Beginner") : ssrLooseEqual_1(form.difficulty, "Beginner")) ? " selected" : ""}>Beginner</option><option value="Intermediate"${ssrIncludeBooleanAttr(Array.isArray(form.difficulty) ? ssrLooseContain_1(form.difficulty, "Intermediate") : ssrLooseEqual_1(form.difficulty, "Intermediate")) ? " selected" : ""}>Intermediate</option><option value="Advanced"${ssrIncludeBooleanAttr(Array.isArray(form.difficulty) ? ssrLooseContain_1(form.difficulty, "Advanced") : ssrLooseEqual_1(form.difficulty, "Advanced")) ? " selected" : ""}>Advanced</option></select></div><div><label class="text-xs font-medium text-gray-500">Author</label><input${ssrRenderAttr_1("value", form.author)} type="text" placeholder="cryptolearner.us Team" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">Tags (comma separated)</label><input${ssrRenderAttr_1("value", form.tags)} type="text" placeholder="wallets, security" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div class="flex items-center justify-between text-sm text-gray-500"><span>Reading time</span><span class="font-medium text-gray-900">${ssrInterpolate_1(readingTime.value)} min</span></div>`);
        if (docId.value) {
          _push(`<div class="flex items-center justify-between text-sm text-gray-500"><span>Views</span><span class="font-medium text-gray-900">${ssrInterpolate_1(views.value.toLocaleString())}</span></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<label class="flex items-center justify-between text-sm text-gray-700"> Featured <input${ssrIncludeBooleanAttr(Array.isArray(form.featured) ? ssrLooseContain_1(form.featured, null) : form.featured) ? " checked" : ""} type="checkbox" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-400"></label><label class="flex items-center justify-between text-sm text-gray-700"> Published <input${ssrIncludeBooleanAttr(Array.isArray(form.published) ? ssrLooseContain_1(form.published, null) : form.published) ? " checked" : ""} type="checkbox" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-400"></label></div>`);
        if (__props.postType === "article") {
          _push(`<div class="space-y-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><div><h3 class="text-sm font-semibold text-gray-900">Guide linking</h3><p class="mt-1 text-xs text-gray-400"> Optional — attach this article to a guide card so its &quot;Read Guide&quot; button opens it automatically, with no code changes. </p></div><div><label class="text-xs font-medium text-gray-500">Guide category</label><select class="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-400"><option value=""${ssrIncludeBooleanAttr(Array.isArray(form.guideCategory) ? ssrLooseContain_1(form.guideCategory, "") : ssrLooseEqual_1(form.guideCategory, "")) ? " selected" : ""}>None</option><!--[-->`);
          ssrRenderList_1(vueExports.unref(GUIDE_CATEGORIES), (c) => {
            _push(`<option${ssrRenderAttr_1("value", c.value)}${ssrIncludeBooleanAttr(Array.isArray(form.guideCategory) ? ssrLooseContain_1(form.guideCategory, c.value) : ssrLooseEqual_1(form.guideCategory, c.value)) ? " selected" : ""}>${ssrInterpolate_1(c.label)}</option>`);
          });
          _push(`<!--]--></select></div>`);
          if (form.guideCategory) {
            _push(`<div><label class="text-xs font-medium text-gray-500">Guide card</label><select class="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:border-blue-400"${ssrIncludeBooleanAttr(guideCardsLoading.value) ? " disabled" : ""}><option value=""${ssrIncludeBooleanAttr(Array.isArray(form.guideCardId) ? ssrLooseContain_1(form.guideCardId, "") : ssrLooseEqual_1(form.guideCardId, "")) ? " selected" : ""}>${ssrInterpolate_1(guideCardsLoading.value ? "Loading…" : "Select a card")}</option><!--[-->`);
            ssrRenderList_1(guideCardOptions.value, (card) => {
              _push(`<option${ssrRenderAttr_1("value", card.cardId)}${ssrIncludeBooleanAttr(Array.isArray(form.guideCardId) ? ssrLooseContain_1(form.guideCardId, card.cardId) : ssrLooseEqual_1(form.guideCardId, card.cardId)) ? " selected" : ""}>${ssrInterpolate_1(card.title)}</option>`);
            });
            _push(`<!--]--></select>`);
            if (!guideCardsLoading.value && !guideCardOptions.value.length) {
              _push(`<p class="mt-1.5 text-xs text-amber-600"> No guide cards exist in this category yet — add one from Guide Cards management. </p>`);
            } else {
              _push(`<!---->`);
            }
            _push(`</div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="rounded-2xl border border-slate-200/80 bg-white shadow-soft"><button type="button" class="flex w-full items-center justify-between p-5 text-left"><h3 class="text-sm font-semibold text-gray-900">SEO</h3><span class="${ssrRenderClass_1([seoOpen.value && "rotate-180", "text-gray-400 transition-transform duration-200"])}">⌄</span></button><div class="space-y-4 border-t border-slate-100 p-5 pt-4" style="${ssrRenderStyle_1(seoOpen.value ? null : { display: "none" })}"><div><label class="text-xs font-medium text-gray-500">SEO title</label><input${ssrRenderAttr_1("value", form.seoTitle)} type="text"${ssrRenderAttr_1("placeholder", form.title || "Falls back to post title")} class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">`);
        if (seoTitleIsSlug.value) {
          _push(`<p class="mt-1.5 text-xs text-amber-700"> This looks like a URL slug, not a title. It won&#39;t be saved — the post title will be used instead. </p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div><label class="text-xs font-medium text-gray-500">SEO description</label><textarea rows="2"${ssrRenderAttr_1(
          "placeholder",
          form.description || "Falls back to short description"
        )} class="mt-1.5 w-full resize-none rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">${ssrInterpolate_1(form.seoDescription)}</textarea></div><div><label class="text-xs font-medium text-gray-500">Focus keyword</label><input${ssrRenderAttr_1("value", form.focusKeyword)} type="text" placeholder="self-custody wallet" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">Canonical URL</label><input${ssrRenderAttr_1("value", form.canonicalUrl)} type="text"${ssrRenderAttr_1("placeholder", `Falls back to /${__props.postType === "blog" ? "blog" : "articles"}/${form.slug}`)} class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">OG image</label><p class="mb-1.5 text-xs text-gray-400"> Falls back to the cover image if left empty. </p>`);
        _push(ssrRenderComponent_1(_sfc_main$1, {
          modelValue: form.ogImage,
          "onUpdate:modelValue": ($event) => form.ogImage = $event
        }, null, _parent));
        _push(`</div></div></div></div></div>`);
      }
      if (previewOpen.value) {
        _push(`<div class="fixed inset-0 z-[200] overflow-y-auto bg-white"><div class="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/90 px-6 py-4 backdrop-blur"><span class="text-sm font-medium text-gray-500">Preview</span><button class="rounded-xl border border-slate-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-slate-50"> Close </button></div><article class="mx-auto max-w-3xl px-6 py-12"><p class="text-sm font-semibold text-blue-600">${ssrInterpolate_1(form.category || "Uncategorized")}</p><h1 class="mt-3 font-display text-4xl font-bold tracking-tight text-gray-900">${ssrInterpolate_1(form.title || "Untitled post")}</h1><p class="mt-4 text-lg text-gray-500">${ssrInterpolate_1(form.description)}</p>`);
        if (form.coverImage) {
          _push(`<img${ssrRenderAttr_1("src", form.coverImage)} alt="" class="mt-8 w-full rounded-2xl object-cover">`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="article-content mt-10">${previewHtml.value ?? ""}</div></article></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/PostEditor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
