import { v as vueExports, s as ssrRenderAttrs_1, g as gsapWithCSS, c as ssrRenderList_1, f as ssrRenderClass_1, n as ssrRenderAttr_1, b as ssrRenderComponent_1, d as ssrInterpolate_1, o as useSeoMeta, O as SITE_URL } from "../entry-server.mjs";
import { g as getArticles } from "./articles-DKIQjXzJ.mjs";
import { u as usePostListing, _ as _sfc_main$8, a as _sfc_main$9, b as _sfc_main$a } from "./LoadMore-BKFlF3Fv.mjs";
import { f as formatRelativeTime } from "./text-scSNyQat.mjs";
import { o as optimizedUrl } from "./cloudinary-oFvjB332.mjs";
import { p as prefetchRoute, _ as _sfc_main$6 } from "./AuthorAvatar--12iQkRN.mjs";
import { _ as _sfc_main$7, u as useBookmarks } from "./useBookmarks-CDn9mt3k.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main$5 = {
  __name: "CategoryIcon",
  __ssrInlineRender: true,
  props: {
    name: { type: String, default: "" }
  },
  setup(__props) {
    const props = __props;
    const KEYWORD_ICONS = [
      [["featured"], "star"],
      [["beginner", "basics", "foundations"], "seed"],
      [["bitcoin", "btc"], "bitcoin"],
      [["ethereum", "eth"], "ethereum"],
      [["altcoin"], "coins"],
      [["trading", "trade"], "trend"],
      [["wallet", "custody"], "wallet"],
      [["security", "secure"], "shield"],
      [["scam", "fraud"], "alert"],
      [["news", "update"], "news"],
      [["guide"], "compass"],
      [["tutorial", "course", "lesson"], "cap"],
      [["defi"], "layers"],
      [["nft", "collectible"], "frame"],
      [["airdrop"], "gift"],
      [["meme"], "rocket"],
      [["layer 2", "layer2", "l2", "scaling"], "stack"]
    ];
    const resolved = vueExports.computed(() => {
      const n = props.name.toLowerCase();
      if (n === "all" || n === "all articles") return "grid";
      for (const [keywords, icon] of KEYWORD_ICONS) {
        if (keywords.some((k) => n.includes(k))) return icon;
      }
      return "tag";
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<svg${ssrRenderAttrs_1(vueExports.mergeProps({
        "aria-hidden": "true",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        "stroke-width": "1.5",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        class: "h-[18px] w-[18px]"
      }, _attrs))}>`);
      if (resolved.value === "star") {
        _push(`<path d="M12 3.5 14.6 9l6 .9-4.3 4.2 1 6-5.3-2.8-5.3 2.8 1-6-4.3-4.2 6-.9 2.6-5.5Z"></path>`);
      } else if (resolved.value === "seed") {
        _push(`<!--[--><path d="M12 21c0-6-4-9-8-9 0 6 4 9 8 9Z"></path><path d="M12 21c0-8 4-13 8-13 0 8-4 13-8 13Z"></path><!--]-->`);
      } else if (resolved.value === "bitcoin") {
        _push(`<!--[--><circle cx="12" cy="12" r="8.5"></circle><path d="M10.2 8h3.3a2 2 0 0 1 0 4h-3.3m0 0h3.7a2 2 0 0 1 0 4h-3.7m0-8v8m0-8V6.5m0 9.5V17.5M13.4 8V6.5m0 9.5V17.5"></path><!--]-->`);
      } else if (resolved.value === "ethereum") {
        _push(`<!--[--><path d="M12 3v7.2L17.5 13 12 3Z"></path><path d="M12 3 6.5 13 12 10.2V3Z"></path><path d="M12 21v-5.6l5.5-3.9L12 21Z"></path><path d="M12 21v-5.6L6.5 11.5 12 21Z"></path><!--]-->`);
      } else if (resolved.value === "coins") {
        _push(`<!--[--><ellipse cx="9" cy="8" rx="5.5" ry="3"></ellipse><path d="M3.5 8v3c0 1.66 2.46 3 5.5 3s5.5-1.34 5.5-3V8"></path><ellipse cx="15" cy="15" rx="5.5" ry="3"></ellipse><path d="M9.5 15v2c0 1.66 2.46 3 5.5 3s5.5-1.34 5.5-3v-2"></path><!--]-->`);
      } else if (resolved.value === "trend") {
        _push(`<!--[--><path d="M3.5 16.5 9 11l4 4 7.5-8.5"></path><path d="M15.5 6.5h5v5"></path><!--]-->`);
      } else if (resolved.value === "wallet") {
        _push(`<!--[--><rect x="3" y="6" width="18" height="13" rx="2.5"></rect><path d="M3 9.5h18"></path><circle cx="16.5" cy="13.5" r="1.1" fill="currentColor" stroke="none"></circle><!--]-->`);
      } else if (resolved.value === "shield") {
        _push(`<!--[--><path d="M12 3.5 5 6v5.2c0 4.4 3 8 7 9.3 4-1.3 7-4.9 7-9.3V6l-7-2.5Z"></path><path d="M9.2 12.2l1.9 1.9 3.7-3.9"></path><!--]-->`);
      } else if (resolved.value === "alert") {
        _push(`<!--[--><path d="M12 3.5 21.5 20h-19L12 3.5Z"></path><path d="M12 10v4.2"></path><circle cx="12" cy="17" r="0.9" fill="currentColor" stroke="none"></circle><!--]-->`);
      } else if (resolved.value === "news") {
        _push(`<!--[--><rect x="3.5" y="5" width="17" height="14" rx="2"></rect><path d="M7 9h6M7 12.5h10M7 16h10"></path><!--]-->`);
      } else if (resolved.value === "compass") {
        _push(`<!--[--><circle cx="12" cy="12" r="8.5"></circle><path d="m14.5 9.5-2 5-3 1.5 2-5 3-1.5Z"></path><!--]-->`);
      } else if (resolved.value === "cap") {
        _push(`<!--[--><path d="M12 5 2.5 9.5 12 14l9.5-4.5L12 5Z"></path><path d="M6.5 11.7V16c0 1.4 2.5 2.5 5.5 2.5s5.5-1.1 5.5-2.5v-4.3"></path><!--]-->`);
      } else if (resolved.value === "layers") {
        _push(`<!--[--><path d="m12 4 8 4.5-8 4.5-8-4.5L12 4Z"></path><path d="m4 13 8 4.5 8-4.5"></path><!--]-->`);
      } else if (resolved.value === "frame") {
        _push(`<!--[--><rect x="4" y="4" width="16" height="16" rx="2.5"></rect><circle cx="9.5" cy="9.5" r="1.6"></circle><path d="m5.5 17 4.5-4.5 3 3 2-2 3.5 3.5"></path><!--]-->`);
      } else if (resolved.value === "gift") {
        _push(`<!--[--><rect x="3.5" y="9.5" width="17" height="10" rx="1.5"></rect><path d="M3.5 13.5h17M12 9.5v10"></path><path d="M12 9.5c-4-1-4.5-5 0-5s1 4 0 5c1-1 4.5 0 4.5 0M12 9.5c1-1-2.5-4-4.5 0"></path><!--]-->`);
      } else if (resolved.value === "rocket") {
        _push(`<!--[--><path d="M12 3c3 1.5 5 4.7 5 8.5 0 2-1 4-2.4 5.4L12 19l-2.6-2.1C8 15.5 7 13.5 7 11.5 7 7.7 9 4.5 12 3Z"></path><circle cx="12" cy="10.5" r="1.6"></circle><path d="M9 16.5 7 20l3-1.2M15 16.5l2 3.5-3-1.2"></path><!--]-->`);
      } else if (resolved.value === "stack") {
        _push(`<!--[--><rect x="4" y="4" width="7" height="7" rx="1.5"></rect><rect x="13" y="4" width="7" height="7" rx="1.5"></rect><rect x="4" y="13" width="7" height="7" rx="1.5"></rect><rect x="13" y="13" width="7" height="7" rx="1.5"></rect><!--]-->`);
      } else if (resolved.value === "grid") {
        _push(`<!--[--><rect x="3.5" y="3.5" width="7.5" height="7.5" rx="1.8"></rect><rect x="13" y="3.5" width="7.5" height="7.5" rx="1.8"></rect><rect x="3.5" y="13" width="7.5" height="7.5" rx="1.8"></rect><rect x="13" y="13" width="7.5" height="7.5" rx="1.8"></rect><!--]-->`);
      } else {
        _push(`<!--[--><path d="M12 3 5 10v9a1 1 0 0 0 1 1h5l8-8a3 3 0 0 0 0-4.2L15.2 3.8A3 3 0 0 0 12 3Z"></path><circle cx="9.5" cy="9.5" r="1.1" fill="currentColor" stroke="none"></circle><!--]-->`);
      }
      _push(`</svg>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/CategoryIcon.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "Sidebar",
  __ssrInlineRender: true,
  props: {
    categories: { type: Array, default: () => [] },
    // distinct category names, dynamic — no 'all'
    posts: { type: Array, default: () => [] },
    modelValue: { type: String, default: "all" }
    // 'all' | 'featured' | <category name>
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const listEl = vueExports.ref(null);
    const featuredCount = vueExports.computed(() => props.posts.filter((p) => p.featured).length);
    const categoryCounts = vueExports.computed(() => {
      const counts = /* @__PURE__ */ new Map();
      for (const p of props.posts) {
        if (!p.category) continue;
        counts.set(p.category, (counts.get(p.category) || 0) + 1);
      }
      return counts;
    });
    const items = vueExports.computed(() => [
      { key: "all", label: "All articles", icon: "all", count: props.posts.length },
      { key: "featured", label: "Featured", icon: "Featured", count: featuredCount.value },
      ...props.categories.map((name) => ({
        key: name,
        label: name,
        icon: name,
        count: categoryCounts.value.get(name) || 0
      }))
    ]);
    vueExports.onMounted(() => {
      gsapWithCSS.set(listEl.value?.children, { opacity: 0, x: -14 });
      gsapWithCSS.to(listEl.value?.children, {
        opacity: 1,
        x: 0,
        duration: 0.6,
        ease: "power3.out",
        stagger: 0.05,
        delay: 0.15
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs_1(vueExports.mergeProps({
        "aria-label": "Blog categories",
        class: "rounded-[28px] border border-[#E8EEF5] bg-white/70 p-3 shadow-[0_1px_2px_rgba(15,23,42,0.04)] backdrop-blur-xl lg:sticky lg:top-24"
      }, _attrs))}><ul class="flex gap-1.5 overflow-x-auto [scrollbar-width:none] lg:block lg:space-y-1 lg:overflow-visible"><!--[-->`);
      ssrRenderList_1(items.value, (item) => {
        _push(`<li class="shrink-0 lg:shrink"><button type="button" class="${ssrRenderClass_1([__props.modelValue === item.key ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-slate-50 hover:text-gray-900", "group relative flex w-full items-center gap-3 whitespace-nowrap rounded-2xl px-3.5 py-2.5 text-left text-sm transition-colors duration-300"])}"${ssrRenderAttr_1("aria-current", __props.modelValue === item.key ? "true" : void 0)}><span class="${ssrRenderClass_1([__props.modelValue === item.key ? "scale-y-100" : "scale-y-0", "absolute left-0 top-1/2 hidden h-5 w-[3px] -translate-y-1/2 rounded-full bg-blue-600 transition-transform duration-300 lg:block"])}"></span><span class="${ssrRenderClass_1([__props.modelValue === item.key ? "bg-white text-blue-600 shadow-sm" : "bg-slate-50 text-gray-400 group-hover:text-gray-600", "flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-colors duration-300"])}">`);
        _push(ssrRenderComponent_1(_sfc_main$5, {
          name: item.icon
        }, null, _parent));
        _push(`</span><span class="min-w-0 flex-1 truncate font-medium">${ssrInterpolate_1(item.label)}</span><span class="${ssrRenderClass_1([__props.modelValue === item.key ? "bg-blue-100 text-blue-700" : "bg-slate-50 text-gray-400", "shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold tabular-nums transition-colors duration-300"])}">${ssrInterpolate_1(item.count)}</span></button></li>`);
      });
      _push(`<!--]--></ul></nav>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/Sidebar.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "FeedFilters",
  __ssrInlineRender: true,
  props: {
    modelValue: { type: String, default: "newest" }
  },
  emits: ["update:modelValue"],
  setup(__props) {
    const OPTIONS = [
      { value: "trending", label: "Trending" },
      { value: "newest", label: "Latest" },
      { value: "popular", label: "Popular" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "flex items-center gap-2" }, _attrs))}><!--[-->`);
      ssrRenderList_1(OPTIONS, (opt) => {
        _push(`<button type="button" data-cursor-hover class="${ssrRenderClass_1([
          __props.modelValue === opt.value ? "bg-gray-900 text-white shadow-soft" : "border border-[#E8EEF5] bg-white text-gray-600 hover:border-slate-300 hover:text-gray-900",
          "rounded-full px-4 py-2 text-sm font-semibold transition-all duration-300"
        ])}">${ssrInterpolate_1(opt.label)}</button>`);
      });
      _push(`<!--]--></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/feed/FeedFilters.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const STORAGE_KEY = "lumen-ledger:likes";
function readStored() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
const ids = vueExports.ref(new Set(readStored()));
vueExports.watch(
  ids,
  (val) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...val]));
    } catch {
    }
  },
  { deep: true }
);
const _sfc_main$2 = {
  __name: "FeedCard",
  __ssrInlineRender: true,
  props: {
    post: { type: Object, required: true }
  },
  setup(__props) {
    const props = __props;
    const { isBookmarked } = useBookmarks();
    const shareOpen = vueExports.ref(false);
    const shareUrl = vueExports.computed(
      () => `${window.location.origin}/articles/${props.post.slug}`
    );
    const shareLinks = vueExports.computed(() => {
      const u = encodeURIComponent(shareUrl.value);
      const t = encodeURIComponent(props.post.title);
      return [
        { id: "x", href: `https://twitter.com/intent/tweet?url=${u}&text=${t}` },
        {
          id: "linkedin",
          href: `https://www.linkedin.com/sharing/share-offsite/?url=${u}`
        },
        {
          id: "facebook",
          href: `https://www.facebook.com/sharer/sharer.php?u=${u}`
        }
      ];
    });
    function closeShare() {
      shareOpen.value = false;
      window.removeEventListener("click", closeShare);
    }
    vueExports.onBeforeUnmount(() => window.removeEventListener("click", closeShare));
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<article${ssrRenderAttrs_1(vueExports.mergeProps({ class: "group overflow-hidden rounded-[32px] border border-[#E8EEF5] bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_28px_64px_-24px_rgba(15,23,42,0.18)]" }, _attrs))}>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: `/articles/${__props.post.slug}`,
        class: "block",
        "data-cursor-hover": "",
        onMouseenter: ($event) => vueExports.unref(prefetchRoute)("article-details")
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center gap-3 px-7 pt-7 sm:px-9 sm:pt-9"${_scopeId}>`);
            _push2(ssrRenderComponent_1(_sfc_main$6, {
              name: __props.post.author || "cryptolearner.us Team",
              size: "sm"
            }, null, _parent2, _scopeId));
            _push2(`<div class="min-w-0 flex-1"${_scopeId}><p class="truncate text-sm font-semibold text-gray-800"${_scopeId}>${ssrInterpolate_1(__props.post.author || "cryptolearner.us Team")}</p><p class="text-xs text-gray-400"${_scopeId}>${ssrInterpolate_1(vueExports.unref(formatRelativeTime)(__props.post.createdAt))}</p></div>`);
            if (__props.post.category) {
              _push2(ssrRenderComponent_1(_sfc_main$7, {
                label: __props.post.category,
                size: "sm"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><h2 class="mt-5 px-7 font-display text-2xl font-bold leading-snug tracking-tight text-gray-900 transition-colors group-hover:text-blue-700 sm:px-9 sm:text-[1.75rem]"${_scopeId}>${ssrInterpolate_1(__props.post.title)}</h2>`);
            if (__props.post.description) {
              _push2(`<p class="mt-2.5 line-clamp-2 px-7 text-[15px] leading-relaxed text-gray-500 sm:px-9"${_scopeId}>${ssrInterpolate_1(__props.post.description)}</p>`);
            } else {
              _push2(`<!---->`);
            }
            if (__props.post.coverImage) {
              _push2(`<div class="mx-7 mt-6 overflow-hidden rounded-[24px] bg-slate-100 sm:mx-9"${_scopeId}><img${ssrRenderAttr_1("src", vueExports.unref(optimizedUrl)(__props.post.coverImage, { width: 960 }))}${ssrRenderAttr_1("alt", __props.post.title)} loading="lazy" class="aspect-[16/9] w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
          } else {
            return [
              vueExports.createVNode("div", { class: "flex items-center gap-3 px-7 pt-7 sm:px-9 sm:pt-9" }, [
                vueExports.createVNode(_sfc_main$6, {
                  name: __props.post.author || "cryptolearner.us Team",
                  size: "sm"
                }, null, 8, ["name"]),
                vueExports.createVNode("div", { class: "min-w-0 flex-1" }, [
                  vueExports.createVNode("p", { class: "truncate text-sm font-semibold text-gray-800" }, vueExports.toDisplayString(__props.post.author || "cryptolearner.us Team"), 1),
                  vueExports.createVNode("p", { class: "text-xs text-gray-400" }, vueExports.toDisplayString(vueExports.unref(formatRelativeTime)(__props.post.createdAt)), 1)
                ]),
                __props.post.category ? (vueExports.openBlock(), vueExports.createBlock(_sfc_main$7, {
                  key: 0,
                  label: __props.post.category,
                  size: "sm"
                }, null, 8, ["label"])) : vueExports.createCommentVNode("", true)
              ]),
              vueExports.createVNode("h2", { class: "mt-5 px-7 font-display text-2xl font-bold leading-snug tracking-tight text-gray-900 transition-colors group-hover:text-blue-700 sm:px-9 sm:text-[1.75rem]" }, vueExports.toDisplayString(__props.post.title), 1),
              __props.post.description ? (vueExports.openBlock(), vueExports.createBlock("p", {
                key: 0,
                class: "mt-2.5 line-clamp-2 px-7 text-[15px] leading-relaxed text-gray-500 sm:px-9"
              }, vueExports.toDisplayString(__props.post.description), 1)) : vueExports.createCommentVNode("", true),
              __props.post.coverImage ? (vueExports.openBlock(), vueExports.createBlock("div", {
                key: 1,
                class: "mx-7 mt-6 overflow-hidden rounded-[24px] bg-slate-100 sm:mx-9"
              }, [
                vueExports.createVNode("img", {
                  src: vueExports.unref(optimizedUrl)(__props.post.coverImage, { width: 960 }),
                  alt: __props.post.title,
                  loading: "lazy",
                  class: "aspect-[16/9] w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                }, null, 8, ["src", "alt"])
              ])) : vueExports.createCommentVNode("", true)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="flex items-center justify-between px-7 py-6 sm:px-9"><div class="flex items-center gap-2 text-xs font-medium text-gray-400"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" class="h-4 w-4"><circle cx="10" cy="10" r="7"></circle><path d="M10 6v4l3 2"></path></svg> ${ssrInterpolate_1(__props.post.readingTime)} min read </div><div class="flex items-center gap-1.5"><button type="button" data-cursor-hover${ssrRenderAttr_1("aria-pressed", vueExports.unref(isBookmarked)(__props.post.id))}${ssrRenderAttr_1(
        "aria-label",
        vueExports.unref(isBookmarked)(__props.post.id) ? "Remove bookmark" : "Bookmark this article"
      )} class="${ssrRenderClass_1([vueExports.unref(isBookmarked)(__props.post.id) ? "text-blue-600" : "text-gray-500", "flex h-9 w-9 items-center justify-center rounded-full transition-all duration-300 hover:bg-slate-50"])}"><svg viewBox="0 0 20 20"${ssrRenderAttr_1("fill", vueExports.unref(isBookmarked)(__props.post.id) ? "currentColor" : "none")} stroke="currentColor" stroke-width="1.6" class="h-4 w-4"><path d="M5.5 3.5h9a1 1 0 0 1 1 1v12l-5.5-3.2L4.5 16.5v-12a1 1 0 0 1 1-1Z" stroke-linejoin="round"></path></svg></button><div class="relative"><button type="button" data-cursor-hover aria-label="Share this article" class="flex h-9 w-9 items-center justify-center rounded-full text-gray-500 transition-all duration-300 hover:bg-slate-50"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" class="h-4 w-4"><circle cx="15" cy="5" r="2.2"></circle><circle cx="5" cy="10" r="2.2"></circle><circle cx="15" cy="15" r="2.2"></circle><path d="m7 8.8 6-2.6M7 11.2l6 2.6"></path></svg></button>`);
      if (shareOpen.value) {
        _push(`<div class="absolute right-0 top-full z-20 mt-2 flex items-center gap-1 rounded-2xl border border-[#E8EEF5] bg-white p-1.5 shadow-lift"><!--[-->`);
        ssrRenderList_1(shareLinks.value, (link) => {
          _push(`<a${ssrRenderAttr_1("href", link.href)} target="_blank" rel="noopener noreferrer" data-cursor-hover class="flex h-8 w-8 items-center justify-center rounded-full text-gray-500 transition-colors hover:bg-slate-50 hover:text-gray-900">`);
          if (link.id === "x") {
            _push(`<svg viewBox="0 0 24 24" class="h-3.5 w-3.5" fill="currentColor"><path d="M18.3 2H21l-6.7 7.6L22.2 22h-6.9l-5.4-6.9L3.7 22H1l7.2-8.2L1.1 2h7l4.9 6.3L18.3 2Zm-1.2 18h1.9L7 4H5l12.1 16Z"></path></svg>`);
          } else if (link.id === "linkedin") {
            _push(`<svg viewBox="0 0 24 24" class="h-3.5 w-3.5" fill="currentColor"><path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.7h.05c.53-1 1.83-2.1 3.76-2.1 4.02 0 4.76 2.6 4.76 6V21h-4v-5.5c0-1.3-.02-3-1.83-3-1.83 0-2.1 1.4-2.1 2.9V21h-4V9Z"></path></svg>`);
          } else {
            _push(`<svg viewBox="0 0 24 24" class="h-3.5 w-3.5" fill="currentColor"><path d="M13.5 22v-8h2.7l.4-3.2h-3.1V8.7c0-.9.25-1.6 1.6-1.6h1.7V4.2C16.5 4.1 15.4 4 14.2 4c-2.6 0-4.4 1.6-4.4 4.5v2.3H7v3.2h2.8v8h3.7Z"></path></svg>`);
          }
          _push(`</a>`);
        });
        _push(`<!--]--><button type="button" data-cursor-hover aria-label="Copy link" class="flex h-8 w-8 items-center justify-center rounded-full text-gray-500 transition-colors hover:bg-slate-50 hover:text-gray-900"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" class="h-3.5 w-3.5"><rect x="7" y="7" width="10" height="10" rx="2"></rect><path d="M4 13V5a2 2 0 0 1 2-2h8"></path></svg></button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></article>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/feed/FeedCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
    class: "rounded-[32px] border border-[#E8EEF5] bg-white p-2",
    role: "presentation",
    "aria-hidden": "true"
  }, _attrs))}><div class="flex items-center gap-3 px-6 pt-6"><div class="h-9 w-9 animate-pulse rounded-full bg-slate-100"></div><div class="h-3 w-28 animate-pulse rounded-full bg-slate-100"></div></div><div class="mt-5 space-y-3 px-6"><div class="h-6 w-4/5 animate-pulse rounded-full bg-slate-100"></div><div class="h-4 w-full animate-pulse rounded-full bg-slate-100"></div><div class="h-4 w-2/3 animate-pulse rounded-full bg-slate-100"></div></div><div class="mx-6 mt-5 aspect-[16/9] animate-pulse rounded-[24px] bg-slate-100"></div><div class="flex items-center justify-between px-6 py-5"><div class="h-3 w-24 animate-pulse rounded-full bg-slate-100"></div><div class="h-8 w-28 animate-pulse rounded-full bg-slate-100"></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/feed/FeedCardSkeleton.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const FeedCardSkeleton = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const PAGE_STEP = 6;
const _sfc_main = {
  __name: "Articles",
  __ssrInlineRender: true,
  setup(__props) {
    const {
      posts,
      loading,
      error,
      search,
      category,
      sortBy,
      categories,
      isFiltering,
      trending
    } = usePostListing(getArticles);
    const activeSidebar = vueExports.ref("all");
    const sidebarCategories = vueExports.computed(
      () => categories.value.filter((c) => c !== "all")
    );
    const visibleCount = vueExports.ref(PAGE_STEP);
    const loadingMore = vueExports.ref(false);
    vueExports.watch(activeSidebar, (val) => {
      category.value = val === "featured" ? "all" : val;
    });
    vueExports.watch([search, category, sortBy, activeSidebar], () => {
      visibleCount.value = PAGE_STEP;
    });
    const feedPosts = vueExports.computed(() => {
      const q = search.value.trim().toLowerCase();
      const base = posts.value.filter((p) => {
        if (p.guideCardId) return false;
        if (q && !p.title?.toLowerCase().includes(q) && !p.description?.toLowerCase().includes(q))
          return false;
        if (category.value !== "all" && p.category !== category.value) return false;
        return true;
      });
      const sorted = [...base];
      if (sortBy.value === "popular") {
        sorted.sort((a, b) => (b.views || 0) - (a.views || 0));
      } else if (sortBy.value === "trending") {
        const score = (p) => {
          const ageDays = p.createdAt ? Math.max(1, (Date.now() - p.createdAt.getTime()) / 864e5) : 1;
          return (p.views || 0) / ageDays;
        };
        sorted.sort((a, b) => score(b) - score(a));
      } else {
        sorted.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      }
      return sorted;
    });
    const displayPosts = vueExports.computed(() => {
      if (activeSidebar.value === "featured") {
        return posts.value.filter((p) => p.featured && !p.guideCardId);
      }
      return feedPosts.value;
    });
    const visiblePosts = vueExports.computed(
      () => displayPosts.value.slice(0, visibleCount.value)
    );
    const hasMore = vueExports.computed(() => visibleCount.value < displayPosts.value.length);
    vueExports.computed(
      () => trending.value.slice(0, 8).map((p) => ({
        id: p.id,
        slug: p.slug,
        label: p.title,
        meta: `${(p.views || 0).toLocaleString()} views`
      }))
    );
    function loadMore() {
      loadingMore.value = true;
      setTimeout(() => {
        visibleCount.value += PAGE_STEP;
        loadingMore.value = false;
      }, 250);
    }
    function clearFilters() {
      search.value = "";
      sortBy.value = "newest";
      activeSidebar.value = "all";
    }
    const headerEl = vueExports.ref(null);
    const feedEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      gsapWithCSS.fromTo(
        headerEl.value,
        { opacity: 0, y: 16 },
        { opacity: 1, y: 0, duration: 0.7, ease: "power3.out" }
      );
    });
    vueExports.watch(posts, (val) => {
      console.log(
        "DEBUG_POSTS",
        JSON.stringify(
          val.map((p) => ({
            id: p.id,
            slug: p.slug,
            title: p.title?.slice(0, 30),
            featured: p.featured,
            published: p.published,
            category: p.category,
            createdAt: p.createdAt
          }))
        )
      );
      console.log(
        "DEBUG_LATEST_LEN",
        latest.value.length,
        "DISPLAY_LEN",
        displayPosts.value.length
      );
    });
    vueExports.watch(
      visiblePosts,
      async () => {
        await vueExports.nextTick();
        const cards = feedEl.value?.querySelectorAll("[data-feed-card]");
        if (!cards?.length) return;
        gsapWithCSS.fromTo(
          cards,
          { opacity: 0, y: 28 },
          { opacity: 1, y: 0, duration: 0.6, ease: "power3.out", stagger: 0.1 }
        );
      },
      { immediate: true }
    );
    useSeoMeta(() => ({
      title: "Articles",
      description: "In-depth, plain-language articles on blockchain, wallets, and digital assets from the cryptolearner.us team.",
      path: "/articles",
      jsonLd: {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        name: "cryptolearner.us Articles",
        url: `${SITE_URL}/articles`
      }
    }));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "bg-[#F7F9FC] pt-28 pb-10 sm:pt-32 sm:pb-14" }, _attrs))}><div class="mx-auto max-w-[1500px] px-6 lg:px-10"><div class="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"><div><div class="flex items-center gap-3"><h1 class="font-display text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"> Articles </h1><span class="rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500 shadow-[0_1px_2px_rgba(15,23,42,0.04)]">${ssrInterpolate_1(vueExports.unref(loading) ? "…" : displayPosts.value.length)} Reports </span></div><p class="mt-2 max-w-lg text-sm leading-relaxed text-gray-500"> In-depth, plain-language research on blockchain, wallets, and digital assets. </p></div><div class="sm:w-80">`);
      _push(ssrRenderComponent_1(_sfc_main$8, {
        modelValue: vueExports.unref(search),
        "onUpdate:modelValue": ($event) => vueExports.isRef(search) ? search.value = $event : null,
        placeholder: "Search articles…"
      }, null, _parent));
      _push(`</div></div>`);
      if (vueExports.unref(error)) {
        _push(`<p class="mt-8 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800" role="alert">${ssrInterpolate_1(vueExports.unref(error))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[280px_1fr]">`);
      _push(ssrRenderComponent_1(_sfc_main$4, {
        modelValue: activeSidebar.value,
        "onUpdate:modelValue": ($event) => activeSidebar.value = $event,
        categories: sidebarCategories.value,
        posts: displayPosts.value
      }, null, _parent));
      _push(`<div class="min-w-0">`);
      _push(ssrRenderComponent_1(_sfc_main$3, {
        modelValue: vueExports.unref(sortBy),
        "onUpdate:modelValue": ($event) => vueExports.isRef(sortBy) ? sortBy.value = $event : null
      }, null, _parent));
      if (vueExports.unref(loading)) {
        _push(`<div class="mt-6 space-y-8"><!--[-->`);
        ssrRenderList_1(3, (i) => {
          _push(ssrRenderComponent_1(FeedCardSkeleton, { key: i }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else if (!visiblePosts.value.length) {
        _push(ssrRenderComponent_1(_sfc_main$9, {
          title: vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? "No articles found" : "No articles yet",
          message: vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? "Try a different search term or clear your filters." : "New reports will show up here as soon as they’re published.",
          onClear: clearFilters
        }, vueExports.createSlots({ _: 2 }, [
          vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? {
            name: "action",
            fn: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Clear filters`);
              } else {
                return [
                  vueExports.createTextVNode("Clear filters")
                ];
              }
            }),
            key: "0"
          } : void 0
        ]), _parent));
      } else {
        _push(`<!--[--><div class="mt-6 space-y-8"><!--[-->`);
        ssrRenderList_1(visiblePosts.value, (post) => {
          _push(ssrRenderComponent_1(_sfc_main$2, {
            key: post.id,
            post,
            "data-feed-card": ""
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
        if (hasMore.value) {
          _push(`<div class="mt-10 flex justify-center">`);
          _push(ssrRenderComponent_1(_sfc_main$a, {
            loading: loadingMore.value,
            onClick: loadMore
          }, null, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--]-->`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/Articles.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
