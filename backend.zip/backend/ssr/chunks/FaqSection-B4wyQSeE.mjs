import { M as faqs, v as vueExports, s as ssrRenderAttrs_1, d as ssrInterpolate_1, c as ssrRenderList_1, f as ssrRenderClass_1 } from "../entry-server.mjs";
const _sfc_main = {
  __name: "FaqSection",
  __ssrInlineRender: true,
  props: {
    faqs: {
      type: Array,
      default: () => faqs
    },
    eyebrow: {
      type: String,
      default: "Before you start"
    },
    heading: {
      type: String,
      default: "Questions we get asked the most."
    },
    sectionId: {
      type: String,
      default: "faq"
    }
  },
  setup(__props) {
    const props = __props;
    const openIndex = vueExports.ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        id: __props.sectionId,
        class: "relative mx-auto max-w-4xl px-6 py-18 lg:px-10"
      }, _attrs))}><div class="mx-auto max-w-xl text-center"><p class="mb-4 text-sm font-semibold text-cyan-600">${ssrInterpolate_1(__props.eyebrow)}</p><h2 class="font-display text-4xl font-bold leading-tight tracking-tight text-gray-900 sm:text-5xl">${ssrInterpolate_1(__props.heading)}</h2></div><div class="mt-14 space-y-3"><!--[-->`);
      ssrRenderList_1(props.faqs, (faq, index) => {
        _push(`<div class="rounded-2xl border border-slate-200/80 bg-white shadow-soft"><button class="flex w-full items-center justify-between px-7 py-6 text-left" data-cursor-hover><span class="pr-6 text-base font-medium text-gray-900">${ssrInterpolate_1(faq.question)}</span><span class="${ssrRenderClass_1([{ "rotate-45": openIndex.value === index }, "flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-black"])}"> + </span></button>`);
        if (openIndex.value === index) {
          _push(`<div class="px-7 pb-6"><p class="text-sm leading-relaxed text-black">${ssrInterpolate_1(faq.answer)}</p></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/FaqSection.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
