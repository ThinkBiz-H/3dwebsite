import { u as useRoute, v as vueExports, P as PRERENDER_STATE, o as useSeoMeta, ad as getServerPage, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, n as ssrRenderAttr_1, d as ssrInterpolate_1, O as SITE_URL } from "../entry-server.mjs";
import { s as sanitizeArticleHtml } from "./sanitizeArticleHtml-CaIpdonf.mjs";
import { b as breadcrumbSchema } from "./seoSchemas-BVwnPOyc.mjs";
import { a as formatDate } from "./text-scSNyQat.mjs";
import { useAuthStore } from "./auth-BWvem-zv.mjs";
import _sfc_main$1 from "./NotFound-CXOAyI2n.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main = {
  __name: "PageView",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useAuthStore();
    const prerenderState = vueExports.inject(PRERENDER_STATE, null);
    const page = vueExports.ref(null);
    const loading = vueExports.ref(true);
    const notFound = vueExports.ref(false);
    const sanitizedContent = vueExports.computed(
      () => page.value?.content ? sanitizeArticleHtml(page.value.content) : ""
    );
    useSeoMeta(() => {
      if (notFound.value || !page.value) {
        return {
          title: "Page Not Found",
          description: "The requested page could not be found.",
          path: route.path
        };
      }
      return {
        title: page.value.seoTitle || page.value.title,
        description: page.value.metaDescription || page.value.shortDescription || "",
        path: `/${page.value.slug}`,
        canonical: `${SITE_URL}/${page.value.slug}`,
        image: page.value.coverImage || "",
        jsonLd: {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "WebPage",
              "@id": `${SITE_URL}/${page.value.slug}#webpage`,
              url: `${SITE_URL}/${page.value.slug}`,
              name: page.value.seoTitle || page.value.title,
              description: page.value.metaDescription || page.value.shortDescription || void 0,
              dateModified: page.value.updatedAt?.toISOString?.(),
              isPartOf: { "@id": `${SITE_URL}/#organization` }
            },
            breadcrumbSchema([{ label: page.value.title }])
          ]
        }
      };
    });
    const stateKey = `page:${route.params.slug}`;
    {
      const ssrContext = vueExports.useSSRContext();
      vueExports.onServerPrefetch(async () => {
        let data = null;
        try {
          data = await getServerPage(route.params.slug);
        } catch (err) {
          console.error("[PageView] server render failed:", err);
        }
        page.value = data?.published ? data : null;
        notFound.value = !page.value;
        loading.value = false;
        if (ssrContext && notFound.value) ssrContext.statusCode = 404;
        if (prerenderState) {
          prerenderState[stateKey] = page.value ? { page: page.value } : { notFound: true, draft: !!data };
        }
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(_attrs)}>`);
      if (loading.value) {
        _push(`<div class="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8 animate-pulse"><div class="h-80 w-full rounded-3xl bg-slate-200 mb-8"></div><div class="h-10 w-3/4 rounded-xl bg-slate-200"></div><div class="mt-4 h-4 w-1/2 rounded bg-slate-200"></div><div class="mt-10 space-y-4"><div class="h-4 w-full rounded bg-slate-200"></div><div class="h-4 w-5/6 rounded bg-slate-200"></div><div class="h-4 w-4/6 rounded bg-slate-200"></div></div></div>`);
      } else if (notFound.value || !page.value) {
        _push(ssrRenderComponent_1(_sfc_main$1, null, null, _parent));
      } else {
        _push(`<article class="relative min-h-[70vh] py-12 sm:py-16"><div class="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">`);
        if (!page.value.published) {
          _push(`<div class="mb-8 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900"><div class="flex items-center gap-2"><span class="inline-block h-2 w-2 rounded-full bg-amber-500"></span><span><strong>Draft preview:</strong> This page is unpublished and only visible to signed-in admins. </span></div>`);
          _push(ssrRenderComponent_1(_component_router_link, {
            to: {
              name: "admin-page-edit",
              params: {
                id: page.value.id
              }
            },
            class: "font-medium underline"
          }, {
            default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Edit in Admin `);
              } else {
                return [
                  vueExports.createTextVNode(" Edit in Admin ")
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        if (page.value.coverImage) {
          _push(`<div class="mb-10 overflow-hidden rounded-3xl border border-slate-200 shadow-sm"><img${ssrRenderAttr_1("src", page.value.coverImage)}${ssrRenderAttr_1("alt", page.value.title)} class="w-full max-h-[520px] object-cover"></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<header class="mb-10"><h1 class="font-display text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl md:text-5xl lg:text-6xl">${ssrInterpolate_1(page.value.title)}</h1>`);
        if (page.value.shortDescription) {
          _push(`<p class="mt-4 text-lg leading-relaxed text-gray-600">${ssrInterpolate_1(page.value.shortDescription)}</p>`);
        } else {
          _push(`<!---->`);
        }
        if (page.value.updatedAt) {
          _push(`<div class="mt-4 text-xs text-gray-400"> Updated on ${ssrInterpolate_1(vueExports.unref(formatDate)(page.value.updatedAt))}</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</header><div class="article-content">${sanitizedContent.value ?? ""}</div></div></article>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/PageView.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
