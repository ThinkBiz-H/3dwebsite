import { O as SITE_URL, ae as SITE_NAME } from "../entry-server.mjs";
const LOGO_URL = `${SITE_URL}/favicon.svg`;
function organizationSchema() {
  return {
    "@type": "Organization",
    "@id": `${SITE_URL}/#organization`,
    name: SITE_NAME,
    url: SITE_URL,
    logo: LOGO_URL
  };
}
function authorSchema(name) {
  return {
    "@type": "Person",
    name: name || `${SITE_NAME} Team`
  };
}
function breadcrumbSchema(items) {
  const trail = [{ label: "Home", path: "/" }, ...items];
  return {
    "@type": "BreadcrumbList",
    itemListElement: trail.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.label,
      item: item.path ? `${SITE_URL}${item.path}` : void 0
    }))
  };
}
function articlePageSchema({ post, url, path, kind = "BlogPosting", breadcrumbItems }) {
  const articleNode = {
    "@type": kind,
    "@id": `${url}#article`,
    headline: post.seoTitle || post.title,
    description: post.seoDescription || post.description,
    image: post.ogImage || post.coverImage ? [post.ogImage || post.coverImage] : void 0,
    datePublished: toIso(post.createdAt),
    dateModified: toIso(post.updatedAt || post.createdAt),
    author: authorSchema(post.author),
    publisher: { "@id": `${SITE_URL}/#organization` },
    mainEntityOfPage: url,
    keywords: post.tags?.length ? post.tags.join(", ") : void 0
  };
  const faqNode = post.faqs?.length > 0 ? {
    "@type": "FAQPage",
    "@id": `${url}#faq`,
    mainEntity: post.faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: { "@type": "Answer", text: f.answer }
    }))
  } : null;
  return {
    "@context": "https://schema.org",
    "@graph": [articleNode, organizationSchema(), breadcrumbSchema(breadcrumbItems), faqNode].filter(Boolean)
  };
}
function toIso(date) {
  if (!date) return void 0;
  const d = date instanceof Date ? date : new Date(date);
  return Number.isNaN(d.getTime()) ? void 0 : d.toISOString();
}
export {
  articlePageSchema as a,
  breadcrumbSchema as b
};
