import { v as vueExports, s as ssrRenderAttrs_1, d as ssrInterpolate_1 } from "../entry-server.mjs";
const loaders = {
  "blog-details": () => import("./BlogDetails-splZiiLG.mjs"),
  "article-details": () => import("./ArticleDetails-CwzKpWaU.mjs")
};
function prefetchRoute(name) {
  loaders[name]?.();
}
const _sfc_main = {
  __name: "AuthorAvatar",
  __ssrInlineRender: true,
  props: {
    name: { type: String, required: true },
    size: { type: String, default: "md" }
    // 'sm' | 'md' | 'lg'
  },
  setup(__props) {
    const props = __props;
    const SIZES = {
      sm: "h-7 w-7 text-[10px]",
      md: "h-9 w-9 text-xs",
      lg: "h-14 w-14 text-base"
    };
    const FLAT_COLORS = ["#2563EB", "#0E7490", "#B45309", "#6D28D9", "#BE185D", "#047857"];
    const initials = vueExports.computed(
      () => props.name.split(" ").map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase()
    );
    const color = vueExports.computed(() => {
      let hash = 0;
      for (let i = 0; i < props.name.length; i++) hash = (hash * 31 + props.name.charCodeAt(i)) % FLAT_COLORS.length;
      return FLAT_COLORS[Math.abs(hash)];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs_1(vueExports.mergeProps({
        class: ["flex shrink-0 items-center justify-center rounded-full font-semibold text-white", SIZES[__props.size]],
        style: { backgroundColor: color.value }
      }, _attrs))}>${ssrInterpolate_1(initials.value)}</span>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/AuthorAvatar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _,
  prefetchRoute as p
};
