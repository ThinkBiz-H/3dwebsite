import { u as useRoute, a as useRouter, v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, c as ssrRenderList_1, d as ssrInterpolate_1, e as ssrRenderSlot_1 } from "../entry-server.mjs";
import { useAuthStore } from "./auth-BWvem-zv.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main$1 = {
  __name: "AdminSidebar",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    useRouter();
    const auth = useAuthStore();
    const links = [
      { to: { name: "admin-dashboard" }, label: "Dashboard", icon: "grid" },
      { to: { name: "admin-pages" }, label: "Pages", icon: "pages" },
      { to: { name: "admin-blogs" }, label: "Blogs", icon: "book" },
      { to: { name: "admin-articles" }, label: "Articles", icon: "file" },
      { to: { name: "admin-guides" }, label: "Guide Cards", icon: "cards" }
    ];
    function isActive(to) {
      return route.name === to.name || route.matched.some((r) => r.name === to.name);
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<aside${ssrRenderAttrs_1(vueExports.mergeProps({ class: "flex h-screen w-64 shrink-0 flex-col border-r border-slate-200 bg-white" }, _attrs))}><div class="flex h-20 items-center px-6">`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "home" },
        class: "font-display text-lg font-semibold tracking-tight text-gray-900"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` cryptolearner.us `);
          } else {
            return [
              vueExports.createTextVNode(" cryptolearner.us ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><nav class="flex-1 space-y-1 px-4"><!--[-->`);
      ssrRenderList_1(links, (link) => {
        _push(ssrRenderComponent_1(_component_router_link, {
          key: link.label,
          to: link.to,
          class: [
            "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
            isActive(link.to) ? "bg-blue-50 text-blue-700" : "text-gray-500 hover:bg-slate-50 hover:text-gray-900"
          ]
        }, {
          default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" class="h-5 w-5"${_scopeId}>`);
              if (link.icon === "grid") {
                _push2(`<rect x="3" y="3" width="7" height="7" rx="1.5"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "grid") {
                _push2(`<rect x="14" y="3" width="7" height="7" rx="1.5"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "grid") {
                _push2(`<rect x="3" y="14" width="7" height="7" rx="1.5"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "grid") {
                _push2(`<rect x="14" y="14" width="7" height="7" rx="1.5"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "book") {
                _push2(`<path d="M4 5.5C4 4.67 4.67 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z"${_scopeId}></path>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "book") {
                _push2(`<path d="M20 5.5C20 4.67 19.33 4 18.5 4H12v16h6.5a1.5 1.5 0 0 0 1.5-1.5v-13Z"${_scopeId}></path>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "pages") {
                _push2(`<rect x="3" y="3" width="18" height="18" rx="2"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "pages") {
                _push2(`<path d="M3 9h18M9 21V9"${_scopeId}></path>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "file") {
                _push2(`<path d="M6 3.5h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-16a1 1 0 0 1 1-1Z"${_scopeId}></path>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "file") {
                _push2(`<path d="M8 12h8M8 16h8M8 8h4"${_scopeId}></path>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "cards") {
                _push2(`<rect x="3.5" y="4.5" width="13" height="9" rx="1.8" transform="rotate(-8 10 9)"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              if (link.icon === "cards") {
                _push2(`<rect x="5.5" y="10.5" width="15" height="9" rx="1.8"${_scopeId}></rect>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</svg> ${ssrInterpolate_1(link.label)}`);
            } else {
              return [
                (vueExports.openBlock(), vueExports.createBlock("svg", {
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  "stroke-width": "1.6",
                  class: "h-5 w-5"
                }, [
                  link.icon === "grid" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 0,
                    x: "3",
                    y: "3",
                    width: "7",
                    height: "7",
                    rx: "1.5"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "grid" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 1,
                    x: "14",
                    y: "3",
                    width: "7",
                    height: "7",
                    rx: "1.5"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "grid" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 2,
                    x: "3",
                    y: "14",
                    width: "7",
                    height: "7",
                    rx: "1.5"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "grid" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 3,
                    x: "14",
                    y: "14",
                    width: "7",
                    height: "7",
                    rx: "1.5"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "book" ? (vueExports.openBlock(), vueExports.createBlock("path", {
                    key: 4,
                    d: "M4 5.5C4 4.67 4.67 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "book" ? (vueExports.openBlock(), vueExports.createBlock("path", {
                    key: 5,
                    d: "M20 5.5C20 4.67 19.33 4 18.5 4H12v16h6.5a1.5 1.5 0 0 0 1.5-1.5v-13Z"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "pages" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 6,
                    x: "3",
                    y: "3",
                    width: "18",
                    height: "18",
                    rx: "2"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "pages" ? (vueExports.openBlock(), vueExports.createBlock("path", {
                    key: 7,
                    d: "M3 9h18M9 21V9"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "file" ? (vueExports.openBlock(), vueExports.createBlock("path", {
                    key: 8,
                    d: "M6 3.5h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-16a1 1 0 0 1 1-1Z"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "file" ? (vueExports.openBlock(), vueExports.createBlock("path", {
                    key: 9,
                    d: "M8 12h8M8 16h8M8 8h4"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "cards" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 10,
                    x: "3.5",
                    y: "4.5",
                    width: "13",
                    height: "9",
                    rx: "1.8",
                    transform: "rotate(-8 10 9)"
                  })) : vueExports.createCommentVNode("", true),
                  link.icon === "cards" ? (vueExports.openBlock(), vueExports.createBlock("rect", {
                    key: 11,
                    x: "5.5",
                    y: "10.5",
                    width: "15",
                    height: "9",
                    rx: "1.8"
                  })) : vueExports.createCommentVNode("", true)
                ])),
                vueExports.createTextVNode(" " + vueExports.toDisplayString(link.label), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></nav><div class="border-t border-slate-100 p-4">`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "home" },
        class: "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-gray-500 transition-colors hover:bg-slate-50 hover:text-gray-900"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" class="h-5 w-5"${_scopeId}><path d="M3 11.5 12 4l9 7.5"${_scopeId}></path><path d="M5 10v9.5a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"${_scopeId}></path></svg> View site `);
          } else {
            return [
              (vueExports.openBlock(), vueExports.createBlock("svg", {
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "1.6",
                class: "h-5 w-5"
              }, [
                vueExports.createVNode("path", { d: "M3 11.5 12 4l9 7.5" }),
                vueExports.createVNode("path", { d: "M5 10v9.5a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10" })
              ])),
              vueExports.createTextVNode(" View site ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="mt-3 flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2.5"><span class="truncate text-xs text-gray-500">${ssrInterpolate_1(vueExports.unref(auth).user?.email)}</span><button class="shrink-0 text-xs font-medium text-blue-600 hover:text-blue-700"> Log out </button></div></div></aside>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/admin/AdminSidebar.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "AdminLayout",
  __ssrInlineRender: true,
  setup(__props) {
    const auth = useAuthStore();
    vueExports.onMounted(() => auth.init());
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "flex min-h-screen bg-slate-50" }, _attrs))}>`);
      _push(ssrRenderComponent_1(_sfc_main$1, null, null, _parent));
      _push(`<main class="min-w-0 flex-1 px-8 py-8 lg:px-12 lg:py-10">`);
      ssrRenderSlot_1(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/layouts/AdminLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
