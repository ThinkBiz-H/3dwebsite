import { v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, d as ssrInterpolate_1 } from "../entry-server.mjs";
import { g as getBlogs, d as deleteBlog } from "./blogs-CoVMFDK3.mjs";
import { _ as _sfc_main$1 } from "./PostManagerTable-CJVHWpV7.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./text-scSNyQat.mjs";
import "./ConfirmModal-Dm0M1IVG.mjs";
const _sfc_main = {
  __name: "BlogList",
  __ssrInlineRender: true,
  setup(__props) {
    const posts = vueExports.ref([]);
    const loading = vueExports.ref(true);
    const error = vueExports.ref("");
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        posts.value = await getBlogs({ publishedOnly: false });
      } catch (err) {
        error.value = "Could not load blogs. Check your Firebase configuration.";
      } finally {
        loading.value = false;
      }
    }
    async function onDelete(id) {
      await deleteBlog(id);
      posts.value = posts.value.filter((p) => p.id !== id);
    }
    vueExports.onMounted(load);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(_attrs)}><div class="flex flex-wrap items-center justify-between gap-4"><div><h1 class="font-display text-2xl font-bold tracking-tight text-gray-900">Blogs</h1><p class="mt-1 text-sm text-gray-500">Everything published to the public Blog section.</p></div>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-blog-new" },
        class: "rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` New blog post `);
          } else {
            return [
              vueExports.createTextVNode(" New blog post ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (error.value) {
        _push(`<p class="mt-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">${ssrInterpolate_1(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-8">`);
      _push(ssrRenderComponent_1(_sfc_main$1, {
        posts: posts.value,
        loading: loading.value,
        "edit-route-name": "admin-blog-edit",
        onDelete
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/BlogList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
