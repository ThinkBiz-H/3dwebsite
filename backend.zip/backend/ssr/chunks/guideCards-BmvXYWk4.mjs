import { a1 as where, a2 as getDocs, a3 as query, a4 as writeBatch, a5 as doc, a6 as db, a7 as serverTimestamp, a8 as updateDoc, a9 as deleteDoc, aa as getDoc, ab as collection } from "../entry-server.mjs";
const COLLECTION = "guideCards";
const colRef = collection(db, COLLECTION);
function normalize(snap) {
  const data = snap.data();
  return {
    id: snap.id,
    ...data,
    order: typeof data.order === "number" ? data.order : 0,
    enabled: data.enabled !== false,
    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : null,
    updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : null
  };
}
async function listGuideCards({ category, enabledOnly = false } = {}) {
  const constraints = category ? [where("category", "==", category)] : [];
  const snap = await getDocs(query(colRef, ...constraints));
  let cards = snap.docs.map(normalize);
  if (enabledOnly) cards = cards.filter((c) => c.enabled);
  return cards.sort((a, b) => a.order - b.order);
}
async function getGuideCardById(id) {
  const snap = await getDoc(doc(db, COLLECTION, id));
  return snap.exists() ? normalize(snap) : null;
}
async function updateGuideCard(id, data) {
  await updateDoc(doc(db, COLLECTION, id), { ...data, updatedAt: serverTimestamp() });
}
async function deleteGuideCard(id) {
  await deleteDoc(doc(db, COLLECTION, id));
}
async function reorderGuideCards(cards) {
  const batch = writeBatch(db);
  cards.forEach((card, index) => {
    batch.update(doc(db, COLLECTION, card.id), { order: index, updatedAt: serverTimestamp() });
  });
  await batch.commit();
}
export {
  deleteGuideCard as d,
  getGuideCardById as g,
  listGuideCards as l,
  reorderGuideCards as r,
  updateGuideCard as u
};
