import { v as vueExports, N as ssrRenderVNode, e as ssrRenderSlot_1, s as ssrRenderAttrs_1 } from "../entry-server.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main$1 = {
  __name: "GlowCard",
  __ssrInlineRender: true,
  props: {
    as: { type: String, default: "div" }
  },
  setup(__props) {
    const cardEl = vueExports.ref(null);
    const glowX = vueExports.ref("50%");
    const glowY = vueExports.ref("50%");
    function onMove(e) {
      const rect = cardEl.value.getBoundingClientRect();
      glowX.value = `${(e.clientX - rect.left) / rect.width * 100}%`;
      glowY.value = `${(e.clientY - rect.top) / rect.height * 100}%`;
    }
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderVNode(_push, vueExports.createVNode(vueExports.resolveDynamicComponent(__props.as), vueExports.mergeProps({
        ref_key: "cardEl",
        ref: cardEl,
        class: "glow-card relative overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-soft transition-shadow duration-300 hover:shadow-card",
        onPointermove: onMove,
        style: { "--glow-x": glowX.value, "--glow-y": glowY.value }
      }, _attrs), {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="glow-card__sheen pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500" data-v-396618f6${_scopeId}></div><div class="relative z-10 h-full" data-v-396618f6${_scopeId}>`);
            ssrRenderSlot_1(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
            _push2(`</div>`);
          } else {
            return [
              vueExports.createVNode("div", { class: "glow-card__sheen pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500" }),
              vueExports.createVNode("div", { class: "relative z-10 h-full" }, [
                vueExports.renderSlot(_ctx.$slots, "default", {}, void 0, true)
              ])
            ];
          }
        }),
        _: 3
      }), _parent);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/ui/GlowCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const GlowCard = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-396618f6"]]);
const _sfc_main = {
  __name: "FeatureIcon",
  __ssrInlineRender: true,
  props: {
    name: { type: String, required: true }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<svg${ssrRenderAttrs_1(vueExports.mergeProps({
        "aria-hidden": "true",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        "stroke-width": "1.3",
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        class: "h-6 w-6"
      }, _attrs))}>`);
      if (__props.name === "book") {
        _push(`<!--[--><path d="M4 5.5C4 4.67 4.67 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z"></path><path d="M20 5.5C20 4.67 19.33 4 18.5 4H12v16h6.5a1.5 1.5 0 0 0 1.5-1.5v-13Z"></path><!--]-->`);
      } else if (__props.name === "wallet") {
        _push(`<!--[--><rect x="3" y="6" width="18" height="13" rx="2.5"></rect><path d="M3 9.5h18"></path><circle cx="16.5" cy="13.5" r="1.1" fill="currentColor" stroke="none"></circle><!--]-->`);
      } else if (__props.name === "shield") {
        _push(`<!--[--><path d="M12 3.5 5 6v5.2c0 4.4 3 8 7 9.3 4-1.3 7-4.9 7-9.3V6l-7-2.5Z"></path><path d="M9.2 12.2l1.9 1.9 3.7-3.9"></path><!--]-->`);
      } else if (__props.name === "pulse") {
        _push(`<path d="M3 12h4l2-6 4 12 2-6h6"></path>`);
      } else if (__props.name === "map") {
        _push(`<!--[--><path d="M9 4 4 6.5v13L9 17l6 2.5 5-2.5v-13L15 6.5 9 4Z"></path><path d="M9 4v13"></path><path d="M15 6.5v13"></path><!--]-->`);
      } else if (__props.name === "chat") {
        _push(`<!--[--><path d="M4 5h16v11H9l-5 4V5Z"></path><path d="M8 9h8M8 12.5h5"></path><!--]-->`);
      } else if (__props.name === "mail") {
        _push(`<!--[--><rect x="3" y="5.5" width="18" height="13" rx="2"></rect><path d="m4 7 8 6 8-6"></path><!--]-->`);
      } else if (__props.name === "globe") {
        _push(`<!--[--><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18"></path><path d="M12 3a15 15 0 0 1 0 18"></path><path d="M12 3a15 15 0 0 0 0 18"></path><!--]-->`);
      } else if (__props.name === "users") {
        _push(`<!--[--><circle cx="9" cy="8" r="3"></circle><circle cx="17" cy="9" r="2.5"></circle><path d="M4 19c0-3 2.5-5 5-5s5 2 5 5"></path><path d="M15 19c0-2 1.5-3.5 4-3.5"></path><!--]-->`);
      } else if (__props.name === "cpu") {
        _push(`<!--[--><rect x="7" y="7" width="10" height="10" rx="2"></rect><path d="M9 1v4M15 1v4M9 19v4M15 19v4"></path><path d="M1 9h4M1 15h4M19 9h4M19 15h4"></path><!--]-->`);
      } else if (__props.name === "eye") {
        _push(`<!--[--><path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6-10-6-10-6Z"></path><circle cx="12" cy="12" r="2.5"></circle><!--]-->`);
      } else if (__props.name === "link") {
        _push(`<!--[--><path d="M10 14 8 16a3 3 0 1 1-4-4l3-3a3 3 0 0 1 4 0"></path><path d="M14 10l2-2a3 3 0 1 1 4 4l-3 3a3 3 0 0 1-4 0"></path><path d="M9 15l6-6"></path><!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</svg>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/ui/FeatureIcon.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  GlowCard as G,
  _sfc_main as _
};
