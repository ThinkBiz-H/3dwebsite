import { v as vueExports, s as ssrRenderAttrs_1, d as ssrInterpolate_1 } from "../entry-server.mjs";
const _sfc_main = {
  __name: "CategoryChip",
  __ssrInlineRender: true,
  props: {
    label: { type: String, required: true },
    size: { type: String, default: "md" }
    // 'sm' | 'md'
  },
  setup(__props) {
    const props = __props;
    const PALETTE = [
      { bg: "#EAF2FF", fg: "#1D4ED8" },
      { bg: "#EAFBF3", fg: "#047857" },
      { bg: "#FFF3E0", fg: "#B45309" },
      { bg: "#F4EEFF", fg: "#6D28D9" },
      { bg: "#FDEAEF", fg: "#BE185D" },
      { bg: "#E8FBFC", fg: "#0E7490" }
    ];
    const swatch = vueExports.computed(() => {
      let hash = 0;
      for (let i = 0; i < props.label.length; i++) hash = (hash * 31 + props.label.charCodeAt(i)) % PALETTE.length;
      return PALETTE[Math.abs(hash)];
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs_1(vueExports.mergeProps({
        class: ["inline-flex w-fit items-center rounded-full font-semibold", __props.size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs"],
        style: { backgroundColor: swatch.value.bg, color: swatch.value.fg }
      }, _attrs))}>${ssrInterpolate_1(__props.label)}</span>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/CategoryChip.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const STORAGE_KEY = "lumen-ledger:bookmarks";
function readStored() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
const ids = vueExports.ref(new Set(readStored()));
vueExports.watch(
  ids,
  (val) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...val]));
    } catch {
    }
  },
  { deep: true }
);
function useBookmarks() {
  function isBookmarked(id) {
    return ids.value.has(id);
  }
  function toggle(id) {
    const next = new Set(ids.value);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    ids.value = next;
  }
  return { isBookmarked, toggle };
}
export {
  _sfc_main as _,
  useBookmarks as u
};
