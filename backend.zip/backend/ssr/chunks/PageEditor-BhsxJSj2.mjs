import { a as useRouter, v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, d as ssrInterpolate_1, V as ssrIncludeBooleanAttr, n as ssrRenderAttr_1, W as ssrLooseContain_1, f as ssrRenderClass_1, q as ssrRenderStyle_1, Z as updatePage, $ as createPage, a0 as getPageById } from "../entry-server.mjs";
import { s as slugify, b as stripHtml } from "./text-scSNyQat.mjs";
import { s as sanitizeArticleHtml } from "./sanitizeArticleHtml-CaIpdonf.mjs";
import { R as RichTextEditor, _ as _sfc_main$1 } from "./ImageUploader-HSRiOueq.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import "./cloudinary-oFvjB332.mjs";
const _sfc_main = {
  __name: "PageEditor",
  __ssrInlineRender: true,
  props: {
    id: { type: String, default: null }
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    const docId = vueExports.ref(props.id);
    const loading = vueExports.ref(!!props.id);
    const saving = vueExports.ref(false);
    const autoSaveState = vueExports.ref("");
    const slugTouched = vueExports.ref(false);
    const previewOpen = vueExports.ref(false);
    const errorMsg = vueExports.ref("");
    const seoOpen = vueExports.ref(true);
    const form = vueExports.reactive({
      title: "",
      slug: "",
      coverImage: "",
      shortDescription: "",
      content: "",
      seoTitle: "",
      metaDescription: "",
      published: false,
      sortOrder: 0
    });
    const previewHtml = vueExports.computed(() => sanitizeArticleHtml(form.content));
    vueExports.watch(
      () => form.title,
      (title) => {
        if (!slugTouched.value) form.slug = slugify(title);
      }
    );
    async function loadExisting() {
      try {
        const page = await getPageById(props.id);
        if (!page) {
          errorMsg.value = "Page not found.";
          loading.value = false;
          return;
        }
        Object.assign(form, {
          title: page.title || "",
          slug: page.slug || "",
          coverImage: page.coverImage || "",
          shortDescription: page.shortDescription || page.metaDescription || "",
          content: page.content || "",
          seoTitle: page.seoTitle || "",
          metaDescription: page.metaDescription || page.shortDescription || "",
          published: !!page.published,
          sortOrder: typeof page.sortOrder === "number" ? page.sortOrder : Number(page.sortOrder) || 0
        });
        slugTouched.value = true;
      } catch (err) {
        console.error("[PageEditor] failed to load page:", err);
        errorMsg.value = "Failed to load page. Check your Firebase connection.";
      } finally {
        loading.value = false;
      }
    }
    function buildPayload() {
      const shortDesc = form.shortDescription.trim() || stripHtml(form.content, 160);
      return {
        title: form.title.trim(),
        slug: form.slug.trim(),
        coverImage: form.coverImage,
        shortDescription: shortDesc,
        content: form.content,
        seoTitle: form.seoTitle.trim(),
        metaDescription: form.metaDescription.trim() || shortDesc,
        published: form.published,
        sortOrder: Number(form.sortOrder) || 0
      };
    }
    async function persist(payload) {
      if (docId.value) {
        await updatePage(docId.value, payload);
      } else {
        docId.value = await createPage(payload);
        router.replace({
          name: "admin-page-edit",
          params: { id: docId.value }
        });
      }
    }
    let autoSaveTimer = null;
    vueExports.watch(
      () => JSON.stringify(form),
      () => {
        if (loading.value || !form.title.trim()) return;
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(async () => {
          autoSaveState.value = "saving";
          try {
            await persist(buildPayload());
            autoSaveState.value = "saved";
          } catch (err) {
            console.error("[PageEditor] auto-save failed:", err);
            autoSaveState.value = "";
          }
        }, 2e3);
      }
    );
    vueExports.onBeforeUnmount(() => clearTimeout(autoSaveTimer));
    vueExports.onMounted(() => {
      if (props.id) loadExisting();
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "mx-auto max-w-5xl" }, _attrs))}><div class="flex flex-wrap items-center justify-between gap-4"><div>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-pages" },
        class: "text-sm font-medium text-gray-400 hover:text-gray-600 transition-colors"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` ← Back to pages `);
          } else {
            return [
              vueExports.createTextVNode(" ← Back to pages ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="mt-2 font-display text-2xl font-bold tracking-tight text-gray-900">${ssrInterpolate_1(docId.value ? "Edit" : "New")} Page </h1></div><div class="flex items-center gap-3">`);
      if (autoSaveState.value === "saving") {
        _push(`<span class="text-xs text-gray-400"> Saving draft… </span>`);
      } else if (autoSaveState.value === "saved") {
        _push(`<span class="text-xs text-cyan-600"> Draft saved </span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button type="button" class="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"> Preview </button><button type="button" class="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"${ssrIncludeBooleanAttr(saving.value) ? " disabled" : ""}> Save draft </button><button type="button" class="rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"${ssrIncludeBooleanAttr(saving.value) ? " disabled" : ""}>${ssrInterpolate_1(form.published ? "Update & publish" : "Publish")}</button></div></div>`);
      if (errorMsg.value) {
        _push(`<p class="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">${ssrInterpolate_1(errorMsg.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (loading.value) {
        _push(`<div class="mt-10 text-center text-sm text-gray-400"> Loading page… </div>`);
      } else {
        _push(`<div class="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[2fr,1fr]"><div class="space-y-6"><div><input${ssrRenderAttr_1("value", form.title)} type="text" placeholder="Page title (e.g. Bitcoin Guide, Web3 Overview)" class="w-full border-none bg-transparent font-display text-3xl font-bold text-gray-900 outline-none placeholder:text-gray-300"><div class="mt-2 flex items-center gap-2 text-sm text-gray-400"><span class="font-mono text-gray-500">/</span><input${ssrRenderAttr_1("value", form.slug)} type="text" placeholder="page-slug" class="flex-1 rounded-lg border border-transparent bg-slate-50 px-2 py-1 text-sm font-mono text-gray-700 outline-none focus:border-slate-200"></div></div><div><label class="mb-1.5 block text-xs font-medium text-gray-500"> Short Description </label><textarea rows="3" placeholder="Brief summary used on the Home Page card and as search excerpt" class="w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm text-gray-700 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100">${ssrInterpolate_1(form.shortDescription)}</textarea></div><div><label class="mb-1.5 block text-xs font-medium text-gray-500"> Page Content (Rich HTML) </label>`);
        _push(ssrRenderComponent_1(RichTextEditor, {
          modelValue: form.content,
          "onUpdate:modelValue": ($event) => form.content = $event
        }, null, _parent));
        _push(`</div></div><div class="space-y-6"><div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><h3 class="text-sm font-semibold text-gray-900">Cover image</h3><p class="mt-1 text-xs text-gray-400">Featured image shown on the card and at top of the page.</p><div class="mt-3">`);
        _push(ssrRenderComponent_1(_sfc_main$1, {
          modelValue: form.coverImage,
          "onUpdate:modelValue": ($event) => form.coverImage = $event
        }, null, _parent));
        _push(`</div></div><div class="space-y-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-soft"><h3 class="text-sm font-semibold text-gray-900">Page Settings</h3><div><label class="text-xs font-medium text-gray-500">Sort Order</label><p class="text-xs text-gray-400">Lower numbers appear first on the home page.</p><input${ssrRenderAttr_1("value", form.sortOrder)} type="number" min="0" step="1" placeholder="0" class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div class="border-t border-slate-100 pt-3"><label class="flex items-center justify-between text-sm text-gray-700 cursor-pointer"><div><span class="font-medium">Published</span><p class="text-xs text-gray-400">Publicly visible on the website</p></div><input${ssrIncludeBooleanAttr(Array.isArray(form.published) ? ssrLooseContain_1(form.published, null) : form.published) ? " checked" : ""} type="checkbox" class="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-400 cursor-pointer"></label></div></div><div class="rounded-2xl border border-slate-200/80 bg-white shadow-soft"><button type="button" class="flex w-full items-center justify-between p-5 text-left"><div><h3 class="text-sm font-semibold text-gray-900">SEO Settings</h3><p class="text-xs text-gray-400">Search engine title and metadata</p></div><span class="${ssrRenderClass_1([seoOpen.value && "rotate-180", "text-gray-400 transition-transform duration-200"])}"> ⌄ </span></button><div class="space-y-4 border-t border-slate-100 p-5 pt-4" style="${ssrRenderStyle_1(seoOpen.value ? null : { display: "none" })}"><div><label class="text-xs font-medium text-gray-500">SEO Title</label><input${ssrRenderAttr_1("value", form.seoTitle)} type="text"${ssrRenderAttr_1("placeholder", form.title || "Defaults to page title")} class="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400"></div><div><label class="text-xs font-medium text-gray-500">Meta Description</label><textarea rows="3" placeholder="Brief summary for Google search results and social cards" class="mt-1.5 w-full resize-none rounded-xl border border-slate-200 px-3 py-2 text-sm outline-none focus:border-blue-400">${ssrInterpolate_1(form.metaDescription)}</textarea></div></div></div></div></div>`);
      }
      if (previewOpen.value) {
        _push(`<div class="fixed inset-0 z-[200] overflow-y-auto bg-white"><div class="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white/90 px-6 py-4 backdrop-blur"><div class="flex items-center gap-3"><span class="text-sm font-medium text-gray-500">Page Preview</span><span class="rounded-md bg-slate-100 px-2 py-0.5 font-mono text-xs text-gray-600"> /${ssrInterpolate_1(form.slug || "untitled")}</span></div><button class="rounded-xl border border-slate-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-slate-50 transition-colors"> Close </button></div><main class="mx-auto max-w-4xl px-6 py-12">`);
        if (form.coverImage) {
          _push(`<img${ssrRenderAttr_1("src", form.coverImage)} alt="" class="mb-8 w-full rounded-2xl object-cover max-h-[460px]">`);
        } else {
          _push(`<!---->`);
        }
        _push(`<h1 class="font-display text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">${ssrInterpolate_1(form.title || "Untitled Page")}</h1>`);
        if (form.shortDescription) {
          _push(`<p class="mt-4 text-lg text-gray-600">${ssrInterpolate_1(form.shortDescription)}</p>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="article-content mt-10">${previewHtml.value ?? ""}</div></main></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/PageEditor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
