import { s as ssrRenderAttrs_1, v as vueExports, d as ssrInterpolate_1, f as ssrRenderClass_1 } from "../entry-server.mjs";
const _sfc_main = {
  __name: "ConfirmModal",
  __ssrInlineRender: true,
  props: {
    open: { type: Boolean, default: false },
    title: { type: String, default: "Are you sure?" },
    message: { type: String, default: "" },
    confirmLabel: { type: String, default: "Delete" },
    danger: { type: Boolean, default: true }
  },
  emits: ["confirm", "cancel"],
  setup(__props, { emit: __emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      if (__props.open) {
        _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "fixed inset-0 z-[200] flex items-center justify-center bg-gray-900/40 px-6" }, _attrs))}>`);
        if (__props.open) {
          _push(`<div class="w-full max-w-sm rounded-2xl bg-white p-6 shadow-lift"><h3 class="text-lg font-semibold text-gray-900">${ssrInterpolate_1(__props.title)}</h3>`);
          if (__props.message) {
            _push(`<p class="mt-2 text-sm text-gray-500">${ssrInterpolate_1(__props.message)}</p>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<div class="mt-6 flex justify-end gap-3"><button class="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"> Cancel </button><button class="${ssrRenderClass_1([__props.danger ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700", "rounded-xl px-4 py-2.5 text-sm font-medium text-white transition-colors"])}">${ssrInterpolate_1(__props.confirmLabel)}</button></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/admin/ConfirmModal.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
