import { v as vueExports, g as gsapWithCSS, S as SplitText, s as ssrRenderAttrs_1, d as ssrInterpolate_1 } from "../entry-server.mjs";
const _sfc_main = {
  __name: "PageHero",
  __ssrInlineRender: true,
  props: {
    eyebrow: { type: String, default: "" },
    heading: { type: String, required: true },
    subtitle: { type: String, default: "" }
  },
  setup(__props) {
    const eyebrowEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const subtitleEl = vueExports.ref(null);
    let headingSplit;
    vueExports.onMounted(async () => {
      gsapWithCSS.set(eyebrowEl.value, { opacity: 0, y: 12 });
      gsapWithCSS.set(subtitleEl.value, { opacity: 0, y: 16 });
      if (document.fonts?.ready) {
        await document.fonts.ready;
      }
      headingSplit = new SplitText(headingEl.value, {
        type: "chars,lines",
        linesClass: "split-line overflow-hidden"
      });
      gsapWithCSS.set(headingSplit.chars, { yPercent: 110, opacity: 0 });
      const tl = gsapWithCSS.timeline({ delay: 0.1 });
      tl.to(eyebrowEl.value, { opacity: 1, y: 0, duration: 0.7 }).to(
        headingSplit.chars,
        {
          yPercent: 0,
          opacity: 1,
          duration: 1,
          stagger: 0.014,
          ease: "power4.out"
        },
        "-=0.4"
      ).to(subtitleEl.value, { opacity: 1, y: 0, duration: 0.8 }, "-=0.6");
    });
    vueExports.onBeforeUnmount(() => headingSplit?.revert());
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({ class: "relative overflow-hidden px-6 pb-20 pt-40 lg:px-10 lg:pb-28 lg:pt-48" }, _attrs))}><div class="pointer-events-none absolute left-1/2 top-0 h-[28rem] w-[28rem] -translate-x-1/2 rounded-full bg-blue-500/[0.06] blur-[130px]"></div><div class="relative mx-auto max-w-3xl text-center">`);
      if (__props.eyebrow) {
        _push(`<p class="mb-6 inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-1.5 text-sm font-medium text-blue-700"><span class="h-1.5 w-1.5 rounded-full bg-blue-600"></span> ${ssrInterpolate_1(__props.eyebrow)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<h1 class="font-display text-4xl font-bold leading-[1.1] tracking-tight text-gray-900 sm:text-5xl lg:text-6xl">${ssrInterpolate_1(__props.heading)}</h1>`);
      if (__props.subtitle) {
        _push(`<p class="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-black">${ssrInterpolate_1(__props.subtitle)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/PageHero.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
