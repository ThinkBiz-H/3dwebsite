import { v as vueExports, s as ssrRenderAttrs_1, d as ssrInterpolate_1, r as aboutStory, c as ssrRenderList_1, w as editorialProcess, x as neverDo, y as correctionsPolicy, n as ssrRenderAttr_1, z as aboutContact, b as ssrRenderComponent_1, A as closingQuote, _ as _sfc_main$9, o as useSeoMeta, B as aboutHero } from "../entry-server.mjs";
import { _ as _sfc_main$a } from "./PageHero-C6df2H0i.mjs";
import { r as revealHeading, a as revealUp } from "./useReveal-BQH7su09.mjs";
import { G as GlowCard, _ as _sfc_main$8 } from "./FeatureIcon-TMx3acNY.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main$7 = {
  __name: "CompanyStory",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const paraEl = vueExports.ref(null);
    const visualEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, {
        type: "words",
        trigger: sectionEl.value,
        stagger: 0.02
      });
      revealUp(paraEl.value.children, {
        trigger: paraEl.value,
        start: "top 85%",
        y: 24,
        stagger: 0.1
      });
      revealUp(visualEl.value, {
        trigger: sectionEl.value,
        start: "top 80%",
        y: 30
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative overflow-hidden py-18"
      }, _attrs))}><div class="absolute inset-0 -z-10"><div class="absolute left-1/3 top-20 h-72 w-72 rounded-full bg-cyan-500/10 blur-[120px]"></div><div class="absolute right-0 bottom-0 h-96 w-96 rounded-full bg-blue-600/10 blur-[160px]"></div></div><div class="mx-auto grid max-w-7xl items-center gap-12 px-6 lg:grid-cols-2 lg:px-10"><div><p class="mb-5 text-sm font-semibold uppercase tracking-[0.25em] text-cyan-400">${ssrInterpolate_1(vueExports.unref(aboutStory).eyebrow)}</p><h2 class="max-w-xl font-display text-5xl font-bold leading-tight text-black">${ssrInterpolate_1(vueExports.unref(aboutStory).heading)}</h2><div class="mt-10 space-y-6"><!--[-->`);
      ssrRenderList_1(vueExports.unref(aboutStory).paragraphs, (p, i) => {
        _push(`<p class="max-w-xl text-lg leading-8 text-black">${ssrInterpolate_1(p)}</p>`);
      });
      _push(`<!--]--></div></div><div class="relative"><div class="rounded-3xl border border-white/10 bg-slate-900/70 p-8 backdrop-blur-xl shadow-2xl"><div class="flex items-center justify-between"><div><p class="text-sm text-slate-400">Trusted Learning Platform</p><h3 class="mt-2 text-3xl font-bold text-white">CryptoLearner</h3></div><div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-500/15"> 📘 </div></div><div class="mt-10 space-y-6"><div class="rounded-2xl bg-slate-800/60 p-5"><div class="flex justify-between"><span class="text-slate-400"> Beginner Guide </span><span class="text-cyan-400"> 100% </span></div><div class="mt-3 h-2 overflow-hidden rounded-full bg-slate-700"><div class="h-full w-full rounded-full bg-cyan-400"></div></div></div><div class="rounded-2xl bg-slate-800/60 p-5"><div class="flex justify-between"><span class="text-slate-400"> Wallet Security </span><span class="text-cyan-400"> 84% </span></div><div class="mt-3 h-2 overflow-hidden rounded-full bg-slate-700"><div class="h-full w-4/5 rounded-full bg-cyan-400"></div></div></div><div class="rounded-2xl bg-slate-800/60 p-5"><div class="flex justify-between"><span class="text-slate-400"> DeFi &amp; NFTs </span><span class="text-cyan-400"> 56% </span></div><div class="mt-3 h-2 overflow-hidden rounded-full bg-slate-700"><div class="h-full w-2/4 rounded-full bg-cyan-400"></div></div></div></div></div><div class="absolute -left-10 -bottom-10 rounded-2xl border border-white/10 bg-slate-900/90 p-5 backdrop-blur-xl shadow-xl"><p class="text-4xl font-bold text-cyan-400">50+</p><p class="mt-2 text-sm text-slate-400">Beginner Friendly Lessons</p></div><div class="absolute -right-8 top-8 rounded-full border border-cyan-400/30 bg-cyan-500/10 px-5 py-2 text-sm font-medium text-cyan-300 backdrop-blur-xl"> Learn • Practice • Stay Safe </div></div></div></section>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/CompanyStory.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "EditorialProcess",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const listEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(listEl.value.children, { trigger: listEl.value, start: "top 85%", y: 30, stagger: 0.08 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-7xl px-6 py-16 lg:px-10 lg:py-20"
      }, _attrs))}><div class="mx-auto max-w-2xl text-center"><p class="mb-4 text-sm font-semibold text-cyan-600">${ssrInterpolate_1(vueExports.unref(editorialProcess).eyebrow)}</p><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(editorialProcess).heading)}</h2></div><div class="mx-auto mt-16 max-w-3xl divide-y divide-slate-200 border-t border-slate-200"><!--[-->`);
      ssrRenderList_1(vueExports.unref(editorialProcess).steps, (step, i) => {
        _push(`<div class="grid grid-cols-[56px_1fr] gap-6 py-8"><div class="font-display text-3xl font-bold leading-none text-blue-600">${ssrInterpolate_1(String(i + 1).padStart(2, "0"))}</div><div><h3 class="text-lg font-semibold text-gray-900">${ssrInterpolate_1(step.title)}</h3><p class="mt-2 leading-relaxed text-gray-500">${ssrInterpolate_1(step.description)}</p></div></div>`);
      });
      _push(`<!--]--></div><p class="mx-auto mt-10 max-w-3xl text-sm leading-relaxed text-gray-500">${ssrInterpolate_1(vueExports.unref(editorialProcess).note)}</p></section>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/EditorialProcess.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "NeverList",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const listEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(listEl.value.children, { trigger: listEl.value, start: "top 85%", y: 20, stagger: 0.08 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-7xl px-6 py-16 lg:px-10 lg:py-20"
      }, _attrs))}><div class="mx-auto max-w-2xl text-center"><p class="mb-4 text-sm font-semibold text-blue-600">${ssrInterpolate_1(vueExports.unref(neverDo).eyebrow)}</p><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(neverDo).heading)}</h2></div><div class="mx-auto mt-14 max-w-2xl space-y-4"><!--[-->`);
      ssrRenderList_1(vueExports.unref(neverDo).items, (item) => {
        _push(`<div class="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white px-6 py-4 shadow-soft"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="mt-0.5 h-5 w-5 shrink-0 text-blue-600"><path d="M20 6 9 17l-5-5"></path></svg><p class="text-[15px] leading-relaxed text-gray-700">${ssrInterpolate_1(item)}</p></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/NeverList.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const _sfc_main$4 = {
  __name: "CorrectionsPolicy",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const boxEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(boxEl.value, { trigger: boxEl.value, start: "top 88%", y: 20 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-4xl px-6 py-16 lg:px-10"
      }, _attrs))}><div class="mx-auto max-w-2xl text-center"><p class="mb-4 text-sm font-semibold text-cyan-600">${ssrInterpolate_1(vueExports.unref(correctionsPolicy).eyebrow)}</p><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(correctionsPolicy).heading)}</h2></div><div class="mx-auto mt-12 max-w-2xl rounded-2xl border-l-4 border-blue-500 bg-blue-50 p-8"><p class="text-[15px] leading-7 text-gray-700">${ssrInterpolate_1(vueExports.unref(correctionsPolicy).intro)} <a${ssrRenderAttr_1("href", vueExports.unref(correctionsPolicy).linkHref)} class="font-semibold text-blue-700 underline underline-offset-2 hover:text-blue-800">${ssrInterpolate_1(vueExports.unref(correctionsPolicy).linkLabel)}</a>. </p><p class="mt-4 text-[15px] leading-7 text-gray-700">${ssrInterpolate_1(vueExports.unref(correctionsPolicy).closing)}</p></div></section>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/CorrectionsPolicy.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {
  __name: "AboutContactOptions",
  __ssrInlineRender: true,
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const gridEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.03 });
      revealUp(gridEl.value.children, { trigger: gridEl.value, start: "top 85%", y: 40, stagger: 0.12 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-7xl px-6 py-16 lg:px-10 lg:py-20"
      }, _attrs))}><div class="mx-auto max-w-2xl text-center"><p class="mb-4 text-sm font-semibold text-blue-600">${ssrInterpolate_1(vueExports.unref(aboutContact).eyebrow)}</p><h2 class="font-display text-3xl font-bold leading-tight tracking-tight text-gray-900 sm:text-4xl">${ssrInterpolate_1(vueExports.unref(aboutContact).heading)}</h2><p class="mt-4 text-lg text-gray-500">${ssrInterpolate_1(vueExports.unref(aboutContact).subtitle)}</p></div><div class="mx-auto mt-14 grid max-w-5xl grid-cols-1 gap-5 sm:grid-cols-3"><!--[-->`);
      ssrRenderList_1(vueExports.unref(aboutContact).options, (opt) => {
        _push(ssrRenderComponent_1(GlowCard, {
          key: opt.label,
          class: "p-8",
          "data-cursor-hover": ""
        }, {
          default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex h-11 w-11 items-center justify-center rounded-full bg-blue-50 text-blue-600"${_scopeId}>`);
              _push2(ssrRenderComponent_1(_sfc_main$8, {
                name: opt.icon
              }, null, _parent2, _scopeId));
              _push2(`</div><h3 class="mt-6 text-sm font-medium text-gray-500"${_scopeId}>${ssrInterpolate_1(opt.label)}</h3><p class="mt-1 text-lg font-semibold text-gray-900"${_scopeId}>${ssrInterpolate_1(opt.title)}</p><p class="mt-3 text-sm leading-relaxed text-gray-500"${_scopeId}>${ssrInterpolate_1(opt.detail)}</p>`);
            } else {
              return [
                vueExports.createVNode("div", { class: "flex h-11 w-11 items-center justify-center rounded-full bg-blue-50 text-blue-600" }, [
                  vueExports.createVNode(_sfc_main$8, {
                    name: opt.icon
                  }, null, 8, ["name"])
                ]),
                vueExports.createVNode("h3", { class: "mt-6 text-sm font-medium text-gray-500" }, vueExports.toDisplayString(opt.label), 1),
                vueExports.createVNode("p", { class: "mt-1 text-lg font-semibold text-gray-900" }, vueExports.toDisplayString(opt.title), 1),
                vueExports.createVNode("p", { class: "mt-3 text-sm leading-relaxed text-gray-500" }, vueExports.toDisplayString(opt.detail), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div><p class="mx-auto mt-8 max-w-2xl text-center text-xs font-medium text-amber-700">${ssrInterpolate_1(vueExports.unref(aboutContact).safetyNote)}</p></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/AboutContactOptions.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = {
  __name: "ClosingQuote",
  __ssrInlineRender: true,
  setup(__props) {
    const quoteEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealUp(quoteEl.value, { trigger: quoteEl.value, start: "top 85%", y: 20 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({ class: "border-y border-slate-200 bg-blue-50/50 px-6 py-20 lg:px-10" }, _attrs))}><p class="mx-auto max-w-3xl text-center text-lg italic leading-8 text-gray-700">${ssrInterpolate_1(vueExports.unref(closingQuote).text)}</p></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/about/ClosingQuote.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  setup(__props) {
    const sectionEl = vueExports.ref(null);
    const headingEl = vueExports.ref(null);
    const subEl = vueExports.ref(null);
    const ctaEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      revealHeading(headingEl.value, { type: "words", trigger: sectionEl.value, stagger: 0.025 });
      revealUp(subEl.value, { trigger: sectionEl.value, y: 20 });
      revealUp(ctaEl.value, { trigger: sectionEl.value, y: 20, delay: 0.1 });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs_1(vueExports.mergeProps({
        ref_key: "sectionEl",
        ref: sectionEl,
        class: "relative mx-auto max-w-6xl px-6 py-16 lg:px-10"
      }, _attrs))} data-v-6fdb582a><div class="relative overflow-hidden rounded-[2.5rem] border border-slate-200/80 bg-white px-8 py-20 text-center shadow-lift sm:px-16" data-v-6fdb582a><div class="pointer-events-none absolute inset-0 animated-gradient opacity-70" data-v-6fdb582a></div><div class="relative z-10 mx-auto max-w-2xl" data-v-6fdb582a><h2 class="font-display text-4xl font-bold leading-tight tracking-tight text-gray-900 sm:text-5xl" data-v-6fdb582a>${ssrInterpolate_1(__props.data.heading)}</h2><p class="mx-auto mt-6 max-w-md text-base text-gray-500" data-v-6fdb582a>${ssrInterpolate_1(__props.data.subtitle)}</p><div class="mt-10 flex justify-center" data-v-6fdb582a>`);
      _push(ssrRenderComponent_1(_sfc_main$9, { "data-cursor-hover": "" }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate_1(__props.data.cta)}`);
          } else {
            return [
              vueExports.createTextVNode(vueExports.toDisplayString(__props.data.cta), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/CtaBanner.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "About",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: "About Cryptolearner | Simple Crypto Education",
      description: "Learn about Cryptolearner and our mission to make Bitcoin, blockchain, Web3, Ethereum, NFTs, and DeFi easier to understand for everyone.",
      path: "/about"
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent_1(_sfc_main$a, {
        eyebrow: vueExports.unref(aboutHero).eyebrow,
        heading: vueExports.unref(aboutHero).heading,
        subtitle: vueExports.unref(aboutHero).subtitle
      }, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$7, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$6, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$5, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$4, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$3, null, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$2, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/About.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
