import { S as SplitText, g as gsapWithCSS } from "../entry-server.mjs";
function revealHeading(el, { type = "chars", trigger = el, start = "top 82%", stagger = 0.02, delay = 0 } = {}) {
  if (!el) return null;
  const split = new SplitText(el, {
    type: type === "chars" ? "chars,words" : "words,lines",
    linesClass: "split-line"
  });
  const targets = type === "chars" ? split.chars : type === "words" ? split.words : split.lines;
  gsapWithCSS.set(targets, { yPercent: 130, opacity: 0, rotateZ: type === "chars" ? 6 : 0 });
  gsapWithCSS.to(targets, {
    yPercent: 0,
    opacity: 1,
    rotateZ: 0,
    duration: 1,
    ease: "power4.out",
    stagger,
    delay,
    scrollTrigger: {
      trigger,
      start,
      toggleActions: "play none none reverse"
    }
  });
  return split;
}
function revealUp(targets, { trigger, start = "top 85%", y = 40, stagger = 0.12, delay = 0 } = {}) {
  if (!targets) return null;
  const tween = gsapWithCSS.fromTo(
    targets,
    { y, opacity: 0 },
    {
      y: 0,
      opacity: 1,
      duration: 1,
      ease: "power3.out",
      stagger,
      delay,
      scrollTrigger: {
        trigger: trigger || targets,
        start,
        toggleActions: "play none none reverse"
      }
    }
  );
  return tween;
}
export {
  revealUp as a,
  revealHeading as r
};
