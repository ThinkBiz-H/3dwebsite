import { v as vueExports, b as ssrRenderComponent_1, d as ssrInterpolate_1 } from "../entry-server.mjs";
import { a as formatDate } from "./text-scSNyQat.mjs";
import { p as prefetchRoute, _ as _sfc_main$1 } from "./AuthorAvatar--12iQkRN.mjs";
import "./useBookmarks-CDn9mt3k.mjs";
const _sfc_main = {
  __name: "BlogCard",
  __ssrInlineRender: true,
  props: {
    post: { type: Object, required: true },
    basePath: { type: String, default: "/blog" }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(ssrRenderComponent_1(_component_router_link, vueExports.mergeProps({
        to: `${__props.basePath}/${__props.post.slug}`,
        "data-cursor-hover": "",
        class: "group flex h-full flex-col overflow-hidden rounded-[28px] border border-[#E8EEF5] bg-white transition-all duration-300 ease-out hover:-translate-y-2 hover:shadow-[0_20px_48px_-20px_rgba(15,23,42,0.16)]",
        onMouseenter: ($event) => vueExports.unref(prefetchRoute)("blog-details")
      }, _attrs), {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-1 flex-col p-6"${_scopeId}><div class="flex items-center gap-2 text-xs text-gray-400"${_scopeId}>`);
            if (__props.post.difficulty) {
              _push2(`<span class="rounded-full bg-slate-50 px-2 py-0.5 font-semibold text-gray-500"${_scopeId}>${ssrInterpolate_1(__props.post.difficulty)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<span${_scopeId}>${ssrInterpolate_1(__props.post.readingTime)} min read</span></div><h3 class="mt-3 text-lg font-semibold leading-snug text-gray-900 transition-colors group-hover:text-blue-700"${_scopeId}>${ssrInterpolate_1(__props.post.title)}</h3><p class="mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-gray-500"${_scopeId}>${ssrInterpolate_1(__props.post.description)}</p><div class="mt-5 flex items-center justify-between border-t border-slate-100 pt-4"${_scopeId}><div class="flex items-center gap-2.5"${_scopeId}>`);
            _push2(ssrRenderComponent_1(_sfc_main$1, {
              name: __props.post.author || "cryptolearner.us Team",
              size: "sm"
            }, null, _parent2, _scopeId));
            _push2(`<div class="leading-tight"${_scopeId}><p class="text-xs font-medium text-gray-700"${_scopeId}>${ssrInterpolate_1(__props.post.author || "cryptolearner.us Team")}</p><p class="text-[11px] text-gray-400"${_scopeId}>${ssrInterpolate_1(vueExports.unref(formatDate)(__props.post.createdAt))}</p></div></div><span class="flex items-center gap-1 text-xs font-semibold text-blue-600 opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100"${_scopeId}> Read <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-3 w-3 transition-transform duration-300 group-hover:translate-x-1"${_scopeId}><path d="M4 10h12M11 5l5 5-5 5"${_scopeId}></path></svg></span></div></div>`);
          } else {
            return [
              vueExports.createVNode("div", { class: "flex flex-1 flex-col p-6" }, [
                vueExports.createVNode("div", { class: "flex items-center gap-2 text-xs text-gray-400" }, [
                  __props.post.difficulty ? (vueExports.openBlock(), vueExports.createBlock("span", {
                    key: 0,
                    class: "rounded-full bg-slate-50 px-2 py-0.5 font-semibold text-gray-500"
                  }, vueExports.toDisplayString(__props.post.difficulty), 1)) : vueExports.createCommentVNode("", true),
                  vueExports.createVNode("span", null, vueExports.toDisplayString(__props.post.readingTime) + " min read", 1)
                ]),
                vueExports.createVNode("h3", { class: "mt-3 text-lg font-semibold leading-snug text-gray-900 transition-colors group-hover:text-blue-700" }, vueExports.toDisplayString(__props.post.title), 1),
                vueExports.createVNode("p", { class: "mt-2 line-clamp-2 flex-1 text-sm leading-relaxed text-gray-500" }, vueExports.toDisplayString(__props.post.description), 1),
                vueExports.createVNode("div", { class: "mt-5 flex items-center justify-between border-t border-slate-100 pt-4" }, [
                  vueExports.createVNode("div", { class: "flex items-center gap-2.5" }, [
                    vueExports.createVNode(_sfc_main$1, {
                      name: __props.post.author || "cryptolearner.us Team",
                      size: "sm"
                    }, null, 8, ["name"]),
                    vueExports.createVNode("div", { class: "leading-tight" }, [
                      vueExports.createVNode("p", { class: "text-xs font-medium text-gray-700" }, vueExports.toDisplayString(__props.post.author || "cryptolearner.us Team"), 1),
                      vueExports.createVNode("p", { class: "text-[11px] text-gray-400" }, vueExports.toDisplayString(vueExports.unref(formatDate)(__props.post.createdAt)), 1)
                    ])
                  ]),
                  vueExports.createVNode("span", { class: "flex items-center gap-1 text-xs font-semibold text-blue-600 opacity-0 transition-all duration-300 group-hover:translate-x-0.5 group-hover:opacity-100" }, [
                    vueExports.createTextVNode(" Read "),
                    (vueExports.openBlock(), vueExports.createBlock("svg", {
                      viewBox: "0 0 20 20",
                      fill: "none",
                      stroke: "currentColor",
                      "stroke-width": "1.8",
                      class: "h-3 w-3 transition-transform duration-300 group-hover:translate-x-1"
                    }, [
                      vueExports.createVNode("path", { d: "M4 10h12M11 5l5 5-5 5" })
                    ]))
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/BlogCard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
