import { v as vueExports, s as ssrRenderAttrs_1, b as ssrRenderComponent_1, d as ssrInterpolate_1, n as ssrRenderAttr_1, V as ssrIncludeBooleanAttr, W as ssrLooseContain_1, X as ssrLooseEqual_1, c as ssrRenderList_1, f as ssrRenderClass_1, m as getPages, Y as deletePage } from "../entry-server.mjs";
import { a as formatDate } from "./text-scSNyQat.mjs";
import { _ as _sfc_main$1 } from "./ConfirmModal-Dm0M1IVG.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main = {
  __name: "PageList",
  __ssrInlineRender: true,
  setup(__props) {
    const pages = vueExports.ref([]);
    const loading = vueExports.ref(true);
    const error = vueExports.ref("");
    const search = vueExports.ref("");
    const statusFilter = vueExports.ref("all");
    const pendingDelete = vueExports.ref(null);
    const togglingId = vueExports.ref(null);
    async function load() {
      loading.value = true;
      error.value = "";
      try {
        pages.value = await getPages({ publishedOnly: false });
      } catch (err) {
        console.error("[PageList] failed to load pages:", err);
        error.value = "Could not load pages. Check your Firebase configuration.";
      } finally {
        loading.value = false;
      }
    }
    const filteredPages = vueExports.computed(() => {
      const q = search.value.trim().toLowerCase();
      return pages.value.filter((p) => {
        if (q) {
          const matchTitle = p.title?.toLowerCase().includes(q);
          const matchSlug = p.slug?.toLowerCase().includes(q);
          const matchDesc = p.shortDescription?.toLowerCase().includes(q);
          if (!matchTitle && !matchSlug && !matchDesc) return false;
        }
        if (statusFilter.value === "published" && !p.published) return false;
        if (statusFilter.value === "draft" && p.published) return false;
        return true;
      });
    });
    async function onConfirmDelete() {
      if (!pendingDelete.value) return;
      const id = pendingDelete.value.id;
      try {
        await deletePage(id);
        pages.value = pages.value.filter((p) => p.id !== id);
      } catch (err) {
        console.error("[PageList] failed to delete page:", err);
        error.value = "Could not delete page. Try again.";
      } finally {
        pendingDelete.value = null;
      }
    }
    vueExports.onMounted(load);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(_attrs)}><div class="flex flex-wrap items-center justify-between gap-4"><div><h1 class="font-display text-2xl font-bold tracking-tight text-gray-900">Pages</h1><p class="mt-1 text-sm text-gray-500">Standalone landing pages (e.g. /money, /bitcoin, /ethereum, /blockchain, /web3).</p></div>`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-page-new" },
        class: "rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700 shadow-sm"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` + New page `);
          } else {
            return [
              vueExports.createTextVNode(" + New page ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (error.value) {
        _push(`<p class="mt-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">${ssrInterpolate_1(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-8 flex flex-wrap items-center gap-3"><div class="relative w-full max-w-xs"><input${ssrRenderAttr_1("value", search.value)} type="search" placeholder="Search by title, /slug or description…" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 pl-9 text-sm text-gray-900 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100"><svg class="pointer-events-none absolute left-3 top-3 h-4 w-4 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.35-4.35"></path></svg></div><select class="rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-400"><option value="all"${ssrIncludeBooleanAttr(Array.isArray(statusFilter.value) ? ssrLooseContain_1(statusFilter.value, "all") : ssrLooseEqual_1(statusFilter.value, "all")) ? " selected" : ""}>All statuses</option><option value="published"${ssrIncludeBooleanAttr(Array.isArray(statusFilter.value) ? ssrLooseContain_1(statusFilter.value, "published") : ssrLooseEqual_1(statusFilter.value, "published")) ? " selected" : ""}>Published</option><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(statusFilter.value) ? ssrLooseContain_1(statusFilter.value, "draft") : ssrLooseEqual_1(statusFilter.value, "draft")) ? " selected" : ""}>Draft</option></select></div><div class="mt-6 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-soft">`);
      if (loading.value) {
        _push(`<div class="px-6 py-12 text-center text-sm text-gray-400"> Loading pages… </div>`);
      } else if (!filteredPages.value.length) {
        _push(`<div class="px-6 py-12 text-center text-sm text-gray-400">${ssrInterpolate_1(pages.value.length ? "No pages match those filters." : 'No pages created yet. Click "+ New page" to create one.')}</div>`);
      } else {
        _push(`<table class="w-full text-left text-sm"><thead class="border-b border-slate-100 text-xs uppercase tracking-wide text-gray-400"><tr><th class="px-6 py-3 font-medium">Page Title &amp; Slug</th><th class="px-6 py-3 font-medium">Description</th><th class="px-6 py-3 font-medium">Sort Order</th><th class="px-6 py-3 font-medium">Status</th><th class="px-6 py-3 font-medium">Updated</th><th class="px-6 py-3 text-right font-medium">Actions</th></tr></thead><tbody class="divide-y divide-slate-100"><!--[-->`);
        ssrRenderList_1(filteredPages.value, (page) => {
          _push(`<tr class="hover:bg-slate-50/60 transition-colors"><td class="px-6 py-4">`);
          _push(ssrRenderComponent_1(_component_router_link, {
            to: { name: "admin-page-edit", params: { id: page.id } },
            class: "font-medium text-gray-900 hover:text-blue-600 transition-colors"
          }, {
            default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`${ssrInterpolate_1(page.title || "(Untitled page)")}`);
              } else {
                return [
                  vueExports.createTextVNode(vueExports.toDisplayString(page.title || "(Untitled page)"), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<div class="mt-0.5 flex items-center gap-1.5 text-xs text-gray-400"><span class="font-mono text-gray-500">/${ssrInterpolate_1(page.slug)}</span><a${ssrRenderAttr_1("href", "/" + page.slug)} target="_blank" title="View live page" class="text-blue-500 hover:text-blue-700"> ↗ </a></div></td><td class="px-6 py-4 max-w-xs truncate text-xs text-gray-500">${ssrInterpolate_1(page.shortDescription || "—")}</td><td class="px-6 py-4 text-sm text-gray-600 font-mono">${ssrInterpolate_1(page.sortOrder ?? 0)}</td><td class="px-6 py-4"><button type="button"${ssrIncludeBooleanAttr(togglingId.value === page.id) ? " disabled" : ""} class="${ssrRenderClass_1([
            page.published ? "bg-cyan-50 text-cyan-700 hover:bg-cyan-100" : "bg-slate-100 text-gray-500 hover:bg-slate-200",
            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium transition-colors cursor-pointer"
          ])}" title="Click to toggle publish status"><span class="${ssrRenderClass_1([page.published ? "bg-cyan-500" : "bg-gray-400", "h-1.5 w-1.5 rounded-full"])}"></span> ${ssrInterpolate_1(page.published ? "Published" : "Draft")}</button></td><td class="px-6 py-4 text-xs text-gray-500">${ssrInterpolate_1(vueExports.unref(formatDate)(page.updatedAt || page.createdAt))}</td><td class="px-6 py-4 text-right"><div class="flex justify-end items-center gap-3">`);
          _push(ssrRenderComponent_1(_component_router_link, {
            to: { name: "admin-page-edit", params: { id: page.id } },
            class: "font-medium text-blue-600 hover:text-blue-700 text-sm"
          }, {
            default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Edit `);
              } else {
                return [
                  vueExports.createTextVNode(" Edit ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<button type="button" class="font-medium text-red-500 hover:text-red-600 text-sm"> Delete </button></div></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent_1(_sfc_main$1, {
        open: !!pendingDelete.value,
        title: "Delete this page?",
        message: pendingDelete.value ? `“${pendingDelete.value.title}” (/${pendingDelete.value.slug}) will be permanently removed.` : "",
        onConfirm: onConfirmDelete,
        onCancel: ($event) => pendingDelete.value = null
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/PageList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
