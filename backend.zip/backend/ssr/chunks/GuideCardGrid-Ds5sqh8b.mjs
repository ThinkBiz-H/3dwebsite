import { a as useRouter, s as ssrRenderAttrs_1, v as vueExports, d as ssrInterpolate_1, f as ssrRenderClass_1, c as ssrRenderList_1, b as ssrRenderComponent_1 } from "../entry-server.mjs";
import { u as useGuideCards } from "./useGuideCards-DW5n9iRx.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
const _sfc_main$2 = {
  __name: "GuideCard",
  __ssrInlineRender: true,
  props: {
    card: { type: Object, required: true },
    // { title, description, article: Object|null, ... }
    index: { type: Number, required: true },
    categoryLabel: { type: String, required: true }
  },
  setup(__props) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<article${ssrRenderAttrs_1(vueExports.mergeProps({
        class: [
          "group grid md:grid-cols-[180px_1fr] gap-6 bg-white border border-sky-100 rounded-2xl p-6 shadow-sm transition-all duration-200",
          __props.card.article ? "cursor-pointer hover:shadow-md hover:border-sky-300 hover:-translate-y-0.5" : ""
        ]
      }, _attrs))}><div class="flex md:flex-col gap-3 md:gap-2"><span class="text-xs uppercase tracking-widest text-sky-700 font-semibold">${ssrInterpolate_1(__props.categoryLabel)}</span><span class="text-xs text-slate-400 font-mono md:mt-1"> #${ssrInterpolate_1(String(__props.index + 1).padStart(2, "0"))}</span></div><div><h3 class="${ssrRenderClass_1([__props.card.article && "group-hover:text-sky-700", "text-xl font-semibold text-slate-900 font-['Space_Grotesk'] mb-2 transition-colors"])}">${ssrInterpolate_1(__props.card.title)}</h3><p class="text-slate-600 leading-7">${ssrInterpolate_1(__props.card.description)}</p>`);
      if (__props.card.article) {
        _push(`<div class="mt-4 inline-flex items-center gap-1 text-sm font-medium text-sky-600 opacity-0 group-hover:opacity-100 transition-opacity"> Read guide <span aria-hidden="true">→</span></div>`);
      } else {
        _push(`<span class="mt-4 inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-400"> Coming soon </span>`);
      }
      _push(`</div></article>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/guides/GuideCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
    class: "grid md:grid-cols-[180px_1fr] gap-6 bg-white border border-sky-100 rounded-2xl p-6 shadow-sm",
    role: "presentation",
    "aria-hidden": "true"
  }, _attrs))}><div class="flex md:flex-col gap-3 md:gap-2"><div class="skeleton-shimmer h-3 w-24 rounded-full"></div><div class="skeleton-shimmer h-3 w-8 rounded-full"></div></div><div class="space-y-3"><div class="skeleton-shimmer h-5 w-2/3 rounded-full"></div><div class="skeleton-shimmer h-3.5 w-full rounded-full"></div><div class="skeleton-shimmer h-3.5 w-4/5 rounded-full"></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/guides/GuideCardSkeleton.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const GuideCardSkeleton = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "GuideCardGrid",
  __ssrInlineRender: true,
  props: {
    category: { type: String, required: true },
    // one of GUIDE_CATEGORIES' values
    categoryLabel: { type: String, required: true }
  },
  setup(__props) {
    const props = __props;
    const { cards, loading, error } = useGuideCards(props.category);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(_attrs)}>`);
      if (vueExports.unref(loading)) {
        _push(`<div class="space-y-4"><!--[-->`);
        ssrRenderList_1(4, (i) => {
          _push(ssrRenderComponent_1(GuideCardSkeleton, { key: i }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else if (vueExports.unref(error)) {
        _push(`<p class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">${ssrInterpolate_1(vueExports.unref(error))}</p>`);
      } else if (!vueExports.unref(cards).length) {
        _push(`<p class="rounded-2xl border border-sky-100 bg-white px-6 py-10 text-center text-sm text-slate-500"> Guides for this section are on the way. </p>`);
      } else {
        _push(`<div class="space-y-4"><!--[-->`);
        ssrRenderList_1(vueExports.unref(cards), (card, i) => {
          _push(ssrRenderComponent_1(_sfc_main$2, {
            key: card.id,
            card,
            index: i,
            "category-label": __props.categoryLabel
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/guides/GuideCardGrid.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
