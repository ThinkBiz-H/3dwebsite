import { v as vueExports, s as ssrRenderAttrs_1, n as ssrRenderAttr_1, c as ssrRenderList_1, V as ssrIncludeBooleanAttr, W as ssrLooseContain_1, X as ssrLooseEqual_1, d as ssrInterpolate_1, f as ssrRenderClass_1, b as ssrRenderComponent_1 } from "../entry-server.mjs";
import { a as formatDate } from "./text-scSNyQat.mjs";
import { _ as _sfc_main$1 } from "./ConfirmModal-Dm0M1IVG.mjs";
const _sfc_main = {
  __name: "PostManagerTable",
  __ssrInlineRender: true,
  props: {
    posts: { type: Array, required: true },
    loading: { type: Boolean, default: false },
    editRouteName: { type: String, required: true }
  },
  emits: ["delete"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const search = vueExports.ref("");
    const category = vueExports.ref("all");
    const status = vueExports.ref("all");
    const pendingDelete = vueExports.ref(null);
    const categories = vueExports.computed(() => {
      const set = new Set(props.posts.map((p) => p.category).filter(Boolean));
      return ["all", ...set];
    });
    const filtered = vueExports.computed(() => {
      const q = search.value.trim().toLowerCase();
      return props.posts.filter((p) => {
        if (q && !p.title?.toLowerCase().includes(q)) return false;
        if (category.value !== "all" && p.category !== category.value) return false;
        if (status.value === "published" && !p.published) return false;
        if (status.value === "draft" && p.published) return false;
        return true;
      });
    });
    function onConfirmDelete() {
      emit("delete", pendingDelete.value.id);
      pendingDelete.value = null;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(_attrs)}><div class="flex flex-wrap items-center gap-3"><input${ssrRenderAttr_1("value", search.value)} type="search" placeholder="Search by title…" class="w-full max-w-xs rounded-xl border border-slate-200 px-4 py-2.5 text-sm text-gray-900 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100"><select class="rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-400"><!--[-->`);
      ssrRenderList_1(categories.value, (c) => {
        _push(`<option${ssrRenderAttr_1("value", c)}${ssrIncludeBooleanAttr(Array.isArray(category.value) ? ssrLooseContain_1(category.value, c) : ssrLooseEqual_1(category.value, c)) ? " selected" : ""}>${ssrInterpolate_1(c === "all" ? "All categories" : c)}</option>`);
      });
      _push(`<!--]--></select><select class="rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-blue-400"><option value="all"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain_1(status.value, "all") : ssrLooseEqual_1(status.value, "all")) ? " selected" : ""}>All statuses</option><option value="published"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain_1(status.value, "published") : ssrLooseEqual_1(status.value, "published")) ? " selected" : ""}>Published</option><option value="draft"${ssrIncludeBooleanAttr(Array.isArray(status.value) ? ssrLooseContain_1(status.value, "draft") : ssrLooseEqual_1(status.value, "draft")) ? " selected" : ""}>Draft</option></select></div><div class="mt-6 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-soft">`);
      if (__props.loading) {
        _push(`<div class="px-6 py-10 text-center text-sm text-gray-400">Loading…</div>`);
      } else if (!filtered.value.length) {
        _push(`<div class="px-6 py-10 text-center text-sm text-gray-400">No posts match those filters.</div>`);
      } else {
        _push(`<table class="w-full text-left text-sm"><thead class="border-b border-slate-100 text-xs uppercase tracking-wide text-gray-400"><tr><th class="px-6 py-3 font-medium">Title</th><th class="px-6 py-3 font-medium">Category</th><th class="px-6 py-3 font-medium">Status</th><th class="px-6 py-3 font-medium">Updated</th><th class="px-6 py-3"></th></tr></thead><tbody class="divide-y divide-slate-100"><!--[-->`);
        ssrRenderList_1(filtered.value, (post) => {
          _push(`<tr><td class="max-w-xs truncate px-6 py-4 font-medium text-gray-900">${ssrInterpolate_1(post.title)}</td><td class="px-6 py-4 text-gray-500">${ssrInterpolate_1(post.category || "—")}</td><td class="px-6 py-4"><span class="${ssrRenderClass_1([post.published ? "bg-cyan-50 text-cyan-700" : "bg-slate-100 text-gray-500", "rounded-full px-2.5 py-1 text-xs font-medium"])}">${ssrInterpolate_1(post.published ? "Published" : "Draft")}</span></td><td class="px-6 py-4 text-gray-500">${ssrInterpolate_1(vueExports.unref(formatDate)(post.updatedAt || post.createdAt))}</td><td class="px-6 py-4 text-right"><div class="flex justify-end gap-4">`);
          _push(ssrRenderComponent_1(_component_router_link, {
            to: { name: __props.editRouteName, params: { id: post.id } },
            class: "font-medium text-blue-600 hover:text-blue-700"
          }, {
            default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Edit `);
              } else {
                return [
                  vueExports.createTextVNode(" Edit ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`<button class="font-medium text-red-500 hover:text-red-600">Delete</button></div></td></tr>`);
        });
        _push(`<!--]--></tbody></table>`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent_1(_sfc_main$1, {
        open: !!pendingDelete.value,
        title: "Delete this post?",
        message: pendingDelete.value ? `“${pendingDelete.value.title}” will be permanently removed.` : "",
        onConfirm: onConfirmDelete,
        onCancel: ($event) => pendingDelete.value = null
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/admin/PostManagerTable.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
