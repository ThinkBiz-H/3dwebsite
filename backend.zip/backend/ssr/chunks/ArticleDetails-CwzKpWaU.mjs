import { u as useRoute, v as vueExports, b as ssrRenderComponent_1 } from "../entry-server.mjs";
import { i as incrementArticleViews, g as getArticles, a as getArticle } from "./articles-DKIQjXzJ.mjs";
import { _ as _sfc_main$1 } from "./ArticlePage-CjkjFwF9.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./text-scSNyQat.mjs";
import "./sanitizeArticleHtml-CaIpdonf.mjs";
import "./seoSchemas-BVwnPOyc.mjs";
import "./useReveal-BQH7su09.mjs";
import "./cloudinary-oFvjB332.mjs";
import "./useBookmarks-CDn9mt3k.mjs";
import "./AuthorAvatar--12iQkRN.mjs";
import "./BlogCard-CSiqgIBk.mjs";
const _sfc_main = {
  __name: "ArticleDetails",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const guidePaths = [
      "getting-started",
      "safety",
      "coins",
      "exchanges",
      "taxes",
      "glossary"
    ];
    const basePath = vueExports.computed(() => {
      const first = route.path.split("/")[1];
      return guidePaths.includes(first) ? `/${first}` : "/articles";
    });
    const listRouteName = vueExports.computed(() => {
      const first = route.path.split("/")[1];
      return guidePaths.includes(first) ? first : "articles";
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent_1(_sfc_main$1, vueExports.mergeProps({
        "get-fn": vueExports.unref(getArticle),
        "list-fn": vueExports.unref(getArticles),
        "increment-views-fn": vueExports.unref(incrementArticleViews),
        "base-path": basePath.value,
        "list-route-name": listRouteName.value,
        "json-ld-type": "Article",
        collection: "articles"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/ArticleDetails.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
