import { v as vueExports, s as ssrRenderAttrs_1, n as ssrRenderAttr_1, d as ssrInterpolate_1, e as ssrRenderSlot_1 } from "../entry-server.mjs";
const PAGE_SIZE = 9;
function usePostListing(fetchFn) {
  const posts = vueExports.ref([]);
  const loading = vueExports.ref(true);
  const error = vueExports.ref("");
  const search = vueExports.ref("");
  const category = vueExports.ref("all");
  const tag = vueExports.ref("all");
  const difficulty = vueExports.ref("all");
  const readingTimeBucket = vueExports.ref("all");
  const sortBy = vueExports.ref("newest");
  const page = vueExports.ref(1);
  vueExports.onMounted(async () => {
    try {
      posts.value = await fetchFn({ publishedOnly: true });
    } catch (err) {
      console.error("[post-listing] load failed:", err.code, err.message, err);
      error.value = "Could not load posts. Check your Firebase configuration.";
    } finally {
      loading.value = false;
    }
  });
  const categories = vueExports.computed(() => {
    const set = new Set(posts.value.map((p) => p.category).filter(Boolean));
    return ["all", ...set];
  });
  const allTags = vueExports.computed(() => {
    const set = new Set(posts.value.flatMap((p) => p.tags || []));
    return [...set].sort();
  });
  const difficulties = vueExports.computed(() => {
    const set = new Set(posts.value.map((p) => p.difficulty).filter(Boolean));
    return ["all", ...set];
  });
  function matchesReadingTimeBucket(minutes, bucket) {
    if (bucket === "all") return true;
    const t = minutes || 0;
    if (bucket === "under5") return t < 5;
    if (bucket === "5to10") return t >= 5 && t <= 10;
    if (bucket === "over10") return t > 10;
    return true;
  }
  const featuredPosts = vueExports.computed(() => {
    const marked = posts.value.filter((p) => p.featured);
    return marked.length ? marked : posts.value.slice(0, 1);
  });
  const featured = vueExports.computed(() => featuredPosts.value[0] || null);
  const byViewsDesc = vueExports.computed(
    () => [...posts.value].sort((a, b) => (b.views || 0) - (a.views || 0))
  );
  const trending = vueExports.computed(() => byViewsDesc.value.slice(0, 5));
  const editorsChoice = vueExports.computed(() => byViewsDesc.value.slice(5, 9));
  const recentlyUpdated = vueExports.computed(
    () => [...posts.value].filter(
      (p) => p.updatedAt && p.createdAt && p.updatedAt.getTime() - p.createdAt.getTime() > 6e4
    ).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)).slice(0, 6)
  );
  const filtered = vueExports.computed(() => {
    const q = search.value.trim().toLowerCase();
    return posts.value.filter((p) => {
      if (q && !p.title?.toLowerCase().includes(q) && !p.description?.toLowerCase().includes(q))
        return false;
      if (category.value !== "all" && p.category !== category.value)
        return false;
      if (tag.value !== "all" && !p.tags?.includes(tag.value)) return false;
      if (difficulty.value !== "all" && p.difficulty !== difficulty.value)
        return false;
      if (!matchesReadingTimeBucket(p.readingTime, readingTimeBucket.value))
        return false;
      return true;
    });
  });
  const isFiltering = vueExports.computed(
    () => !!search.value.trim() || category.value !== "all" || tag.value !== "all" || difficulty.value !== "all" || readingTimeBucket.value !== "all"
  );
  const featuredIds = vueExports.computed(
    () => new Set(featuredPosts.value.map((p) => p.id))
  );
  const latest = vueExports.computed(() => {
    const base = isFiltering.value ? filtered.value : posts.value.filter((p) => !featuredIds.value.has(p.id));
    const sorted = [...base];
    if (sortBy.value === "oldest")
      sorted.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    else if (sortBy.value === "popular")
      sorted.sort((a, b) => (b.views || 0) - (a.views || 0));
    else if (sortBy.value === "trending") {
      const score = (p) => {
        const ageDays = p.createdAt ? Math.max(1, (Date.now() - p.createdAt.getTime()) / 864e5) : 1;
        return (p.views || 0) / ageDays;
      };
      sorted.sort((a, b) => score(b) - score(a));
    } else if (sortBy.value === "az")
      sorted.sort((a, b) => a.title.localeCompare(b.title));
    else sorted.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return sorted;
  });
  vueExports.watch([search, category, tag, difficulty, readingTimeBucket, sortBy], () => {
    page.value = 1;
  });
  const totalPages = vueExports.computed(
    () => Math.max(1, Math.ceil(latest.value.length / PAGE_SIZE))
  );
  const paged = vueExports.computed(() => {
    const start = (page.value - 1) * PAGE_SIZE;
    return latest.value.slice(start, start + PAGE_SIZE);
  });
  function relatedTo(post, count = 3) {
    return posts.value.filter((p) => p.id !== post.id && p.category === post.category).slice(0, count);
  }
  return {
    posts,
    loading,
    error,
    search,
    category,
    tag,
    difficulty,
    readingTimeBucket,
    sortBy,
    page,
    categories,
    allTags,
    difficulties,
    featured,
    featuredPosts,
    trending,
    editorsChoice,
    recentlyUpdated,
    isFiltering,
    latest,
    paged,
    totalPages,
    relatedTo
  };
}
const _sfc_main$2 = {
  __name: "SearchBar",
  __ssrInlineRender: true,
  props: {
    modelValue: { type: String, default: "" },
    placeholder: { type: String, default: "Search articles…" }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const focused = vueExports.ref(false);
    vueExports.ref(null);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
        class: ["flex h-12 items-center gap-2.5 rounded-2xl border bg-white px-4 transition-all duration-300", focused.value ? "border-blue-400 shadow-[0_0_0_4px_rgba(37,99,235,0.08)]" : "border-[#E8EEF5]"]
      }, _attrs))}><svg aria-hidden="true" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-4 w-4 shrink-0 text-gray-400"><circle cx="9" cy="9" r="6.5"></circle><path d="m18 18-4.3-4.3"></path></svg><input${ssrRenderAttr_1("value", __props.modelValue)} type="search" role="searchbox" aria-label="Search articles"${ssrRenderAttr_1("placeholder", __props.placeholder)} class="w-full min-w-0 border-none bg-transparent text-sm text-gray-900 outline-none placeholder:text-gray-400">`);
      if (__props.modelValue) {
        _push(`<button type="button" aria-label="Clear search" class="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-gray-400 transition-colors hover:bg-slate-100 hover:text-gray-600"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-3 w-3"><path d="m5 5 10 10M15 5 5 15"></path></svg></button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/SearchBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "EmptyState",
  __ssrInlineRender: true,
  props: {
    title: { type: String, default: "No articles found" },
    message: { type: String, default: "Try a different search term or clear your filters." }
  },
  emits: ["clear"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "mx-auto flex max-w-md flex-col items-center rounded-[28px] border border-[#E8EEF5] bg-white py-20 text-center" }, _attrs))}><svg viewBox="0 0 120 120" class="h-28 w-28" aria-hidden="true"><circle cx="60" cy="60" r="46" fill="#F7F9FC"></circle><rect x="34" y="40" width="52" height="38" rx="8" fill="#fff" stroke="#E8EEF5" stroke-width="2"></rect><path d="M34 54h52" stroke="#E8EEF5" stroke-width="2"></path><circle cx="44" cy="47" r="2" fill="#CBD5E1"></circle><circle cx="52" cy="47" r="2" fill="#CBD5E1"></circle><rect x="42" y="62" width="24" height="4" rx="2" fill="#E8EEF5"></rect><rect x="42" y="70" width="16" height="4" rx="2" fill="#E8EEF5"></rect><circle cx="80" cy="76" r="15" fill="#fff" stroke="#BFDBFE" stroke-width="2.5"></circle><path d="m90 86 7 7" stroke="#BFDBFE" stroke-width="2.5" stroke-linecap="round"></path><path d="m75 76 4 4 6-7" stroke="#93C5FD" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg><p class="mt-6 text-base font-semibold text-gray-900">${ssrInterpolate_1(__props.title)}</p>`);
      if (__props.message) {
        _push(`<p class="mt-2 max-w-xs text-sm text-gray-500">${ssrInterpolate_1(__props.message)}</p>`);
      } else {
        _push(`<!---->`);
      }
      if (_ctx.$slots.action) {
        _push(`<button class="group mt-7 inline-flex items-center gap-1.5 rounded-full border border-[#E8EEF5] px-5 py-2.5 text-sm font-semibold text-gray-700 transition-all duration-300 hover:border-blue-300 hover:bg-blue-50 hover:text-blue-700">`);
        ssrRenderSlot_1(_ctx.$slots, "action", {}, null, _push, _parent);
        _push(`<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1"><path d="M4 10h12M11 5l5 5-5 5"></path></svg></button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/EmptyState.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "LoadMore",
  __ssrInlineRender: true,
  props: {
    loading: { type: Boolean, default: false }
  },
  emits: ["click"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs_1(vueExports.mergeProps({
        type: "button",
        class: "group inline-flex items-center gap-2 rounded-full border border-[#E8EEF5] bg-white px-7 py-3.5 text-sm font-semibold text-gray-900 shadow-[0_1px_2px_rgba(15,23,42,0.04)] transition-all duration-300 hover:-translate-y-0.5 hover:border-blue-300 hover:shadow-[0_12px_28px_-12px_rgba(37,99,235,0.25)] disabled:pointer-events-none disabled:opacity-50",
        disabled: __props.loading
      }, _attrs))}>`);
      if (__props.loading) {
        _push(`<svg viewBox="0 0 20 20" fill="none" class="h-4 w-4 animate-spin text-blue-600"><circle cx="10" cy="10" r="7.5" stroke="currentColor" stroke-width="2" stroke-opacity="0.2"></circle><path d="M17.5 10a7.5 7.5 0 0 0-7.5-7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path></svg>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<span>${ssrInterpolate_1(__props.loading ? "Loading…" : "Load more articles")}</span>`);
      if (!__props.loading) {
        _push(`<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.8" class="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-y-0.5"><path d="M5 8l5 5 5-5"></path></svg>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/LoadMore.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main$2 as _,
  _sfc_main$1 as a,
  _sfc_main as b,
  usePostListing as u
};
