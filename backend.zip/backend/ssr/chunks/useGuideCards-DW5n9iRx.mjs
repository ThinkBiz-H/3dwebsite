import { v as vueExports } from "../entry-server.mjs";
import { l as listGuideCards } from "./guideCards-BmvXYWk4.mjs";
import { g as getArticles } from "./articles-DKIQjXzJ.mjs";
function useGuideCards(category) {
  const cards = vueExports.ref([]);
  const loading = vueExports.ref(true);
  const error = vueExports.ref("");
  vueExports.onMounted(async () => {
    try {
      const [guideCards, articles] = await Promise.all([
        listGuideCards({ category, enabledOnly: true }),
        getArticles({ publishedOnly: true })
      ]);
      const byCardId = new Map(articles.filter((a) => a.guideCardId).map((a) => [a.guideCardId, a]));
      cards.value = guideCards.map((card) => ({ ...card, article: byCardId.get(card.cardId) || null }));
    } catch (err) {
      console.error("[guide-cards] load failed:", err.code, err.message, err);
      error.value = "Could not load guides right now.";
    } finally {
      loading.value = false;
    }
  });
  return { cards, loading, error };
}
export {
  useGuideCards as u
};
