import { a as useRouter, s as ssrRenderAttrs_1, v as vueExports, c as ssrRenderList_1, d as ssrInterpolate_1, f as ssrRenderClass_1, o as useSeoMeta, b as ssrRenderComponent_1 } from "../entry-server.mjs";
import { u as useGuideCards } from "./useGuideCards-DW5n9iRx.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
import "./guideCards-BmvXYWk4.mjs";
import "./articles-DKIQjXzJ.mjs";
const _sfc_main$1 = {
  __name: "GlossaryCardGrid",
  __ssrInlineRender: true,
  props: {
    category: { type: String, required: true }
  },
  setup(__props) {
    const props = __props;
    useRouter();
    const { cards, loading, error } = useGuideCards(props.category);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(_attrs)}>`);
      if (vueExports.unref(loading)) {
        _push(`<div class="grid md:grid-cols-2 gap-4"><!--[-->`);
        ssrRenderList_1(6, (i) => {
          _push(`<div class="rounded-2xl border border-sky-100 bg-white p-6 shadow-sm" role="presentation" aria-hidden="true"><div class="skeleton-shimmer h-5 w-1/2 rounded-full"></div><div class="skeleton-shimmer mt-3 h-3.5 w-full rounded-full"></div><div class="skeleton-shimmer mt-2 h-3.5 w-3/4 rounded-full"></div></div>`);
        });
        _push(`<!--]--></div>`);
      } else if (vueExports.unref(error)) {
        _push(`<p class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">${ssrInterpolate_1(vueExports.unref(error))}</p>`);
      } else if (!vueExports.unref(cards).length) {
        _push(`<p class="rounded-2xl border border-sky-100 bg-white px-6 py-10 text-center text-sm text-slate-500"> New terms are added regularly. </p>`);
      } else {
        _push(`<div class="grid md:grid-cols-2 gap-4"><!--[-->`);
        ssrRenderList_1(vueExports.unref(cards), (card) => {
          _push(`<article class="${ssrRenderClass_1([
            card.article ? "cursor-pointer hover:shadow-md hover:border-sky-300 hover:-translate-y-0.5" : "",
            "group bg-white border border-sky-100 rounded-2xl p-6 shadow-sm transition-all duration-200"
          ])}"><h3 class="${ssrRenderClass_1([card.article && "group-hover:text-sky-700", "text-xl font-semibold text-slate-900 font-['Space_Grotesk'] mb-2 transition-colors"])}">${ssrInterpolate_1(card.title)}</h3><p class="text-slate-600 leading-7">${ssrInterpolate_1(card.description)}</p>`);
          if (card.article) {
            _push(`<div class="mt-3 inline-flex items-center gap-1 text-sm font-medium text-sky-600 opacity-0 group-hover:opacity-100 transition-opacity"> Read more <span aria-hidden="true">→</span></div>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</article>`);
        });
        _push(`<!--]--></div>`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/guides/GlossaryCardGrid.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Glossary",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      title: "Crypto Glossary | Crypto Terms & Definitions",
      description: "Explore the Cryptolearner glossary to understand crypto terms and definitions, from Bitcoin and blockchain to Web3, DeFi, NFTs, wallets, and more.",
      path: "/glossary"
    });
    const showContact = vueExports.ref(false);
    const fabRef = vueExports.ref(null);
    const panelRef = vueExports.ref(null);
    const handleOutsideClick = (e) => {
      if (!showContact.value) return;
      const inPanel = panelRef.value && panelRef.value.contains(e.target);
      const inFab = fabRef.value && fabRef.value.contains(e.target);
      if (!inPanel && !inFab) showContact.value = false;
    };
    vueExports.onMounted(() => document.addEventListener("click", handleOutsideClick));
    vueExports.onUnmounted(() => document.removeEventListener("click", handleOutsideClick));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs_1(vueExports.mergeProps({ class: "min-h-screen bg-gradient-to-b from-sky-50 via-blue-50 to-white text-slate-800" }, _attrs))}><section class="relative overflow-hidden px-6 pt-20 pb-16"><div class="pointer-events-none absolute -top-32 -right-32 h-96 w-96 rounded-full bg-sky-200/50 blur-3xl"></div><div class="pointer-events-none absolute -bottom-24 -left-24 h-80 w-80 rounded-full bg-blue-200/40 blur-3xl"></div><div class="relative max-w-5xl mx-auto"><span class="inline-block text-xs font-semibold tracking-[0.2em] uppercase text-sky-700 bg-sky-100 border border-sky-200 px-3 py-1 rounded-full"> Glossary </span><h1 class="mt-6 text-4xl md:text-5xl font-bold text-slate-900 leading-tight font-[&#39;Space_Grotesk&#39;]"> Crypto has its own language. <span class="text-sky-600">Here&#39;s the dictionary.</span></h1><p class="mt-6 text-lg text-slate-600 leading-8 max-w-3xl"> Every industry develops its own shorthand, and crypto has more of it than most. This section is a running list of terms you&#39;ll run into everywhere else on this site (and across the internet), each explained in one or two plain sentences. </p><div class="mt-8 inline-flex items-start gap-3 bg-white/70 backdrop-blur border border-sky-200 rounded-xl px-5 py-4 shadow-sm"><span class="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-sky-600 text-white text-xs font-bold"> i </span><p class="text-sm text-slate-600 leading-6"><strong class="text-slate-800">Who this is for:</strong> anyone who hits an unfamiliar word mid-article and wants a fast, clear answer — no searching required. </p></div></div></section><section class="px-6 py-16 border-t border-sky-100"><div class="max-w-5xl mx-auto"><div class="flex items-end justify-between mb-10"><h2 class="text-3xl font-bold text-slate-900 font-[&#39;Space_Grotesk&#39;]"> Sample Entries </h2></div>`);
      _push(ssrRenderComponent_1(_sfc_main$1, { category: "glossary" }, null, _parent));
      _push(`<div class="mt-10 bg-amber-50 border-l-4 border-amber-500 rounded-r-xl p-6 text-amber-900 leading-7"><strong class="text-amber-800">Living page:</strong> This glossary is a living page — new terms are added as they come up across our guides. If you searched for a term and didn&#39;t find it here, use the “Talk to us” button and we&#39;ll add it. <b>Talk to us</b> button. </div></div></section>`);
      if (showContact.value) {
        _push(`<div class="fixed bottom-24 right-6 z-50 w-[22rem] max-w-[calc(100vw-3rem)] rounded-2xl bg-white border border-sky-200 shadow-2xl shadow-sky-200/50 overflow-hidden"><div class="bg-gradient-to-br from-sky-500 to-blue-600 px-6 py-5 text-white"><div class="text-xs uppercase tracking-widest text-sky-100 font-semibold"> Get in touch </div><h4 class="mt-1 text-lg font-semibold font-[&#39;Space_Grotesk&#39;]"> Talk to CryptoLearner </h4><p class="mt-1 text-sm text-sky-50/90 leading-6"> Questions, corrections, or feedback on a guide — we read every message ourselves. </p></div><div class="p-4 space-y-2"><a class="flex items-center gap-3 rounded-xl p-3 hover:bg-sky-50 transition-colors" href="tel:+18005551234"><div class="flex h-10 w-10 items-center justify-center rounded-full bg-sky-100 text-sky-700 text-lg"> ☎ </div><div class="text-sm"><b class="block text-slate-800">Call us</b><span class="text-slate-500"> +1 (213) 538-2554 · Mon–Fri, 9am–6pm ET </span></div></a><a class="flex items-center gap-3 rounded-xl p-3 hover:bg-sky-50 transition-colors" href="https://wa.me/18005551234" target="_blank" rel="noopener"><div class="flex h-10 w-10 items-center justify-center rounded-full bg-sky-100 text-sky-700 text-lg"> 💬 </div><div class="text-sm"><b class="block text-slate-800">Chat on WhatsApp</b><span class="text-slate-500">Usually replies within an hour</span></div></a><a class="flex items-center gap-3 rounded-xl p-3 hover:bg-sky-50 transition-colors" href="mailto:support@cryptolearner.us"><div class="flex h-10 w-10 items-center justify-center rounded-full bg-sky-100 text-sky-700 text-lg"> ✉ </div><div class="text-sm"><b class="block text-slate-800">Email us</b><span class="text-slate-500">support@cryptolearner.us</span></div></a></div><div class="border-t border-sky-100 bg-sky-50/60 px-5 py-3"><p class="text-xs text-slate-500 leading-5"> We never ask for wallet keys, passwords, or payment over chat. </p></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full bg-gradient-to-br from-sky-500 to-blue-600 px-5 py-3 text-white font-medium shadow-lg shadow-sky-300/50 hover:shadow-xl hover:shadow-sky-400/50 hover:-translate-y-0.5 transition-all"><span class="relative flex h-2 w-2"><span class="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-75"></span><span class="relative inline-flex h-2 w-2 rounded-full bg-white"></span></span><span>${ssrInterpolate_1(showContact.value ? "Close" : "Talk to us")}</span></button></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/views/Glossary.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
