import { s as ssrRenderAttrs_1, v as vueExports, d as ssrInterpolate_1, b as ssrRenderComponent_1, c as ssrRenderList_1, f as ssrRenderClass_1 } from "../entry-server.mjs";
import { g as getBlogs } from "./blogs-CoVMFDK3.mjs";
import { g as getArticles } from "./articles-DKIQjXzJ.mjs";
import { a as formatDate } from "./text-scSNyQat.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main$1 = {
  __name: "StatCard",
  __ssrInlineRender: true,
  props: {
    label: { type: String, required: true },
    value: { type: [String, Number], required: true },
    icon: { type: String, default: "grid" }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "rounded-2xl border border-slate-200/80 bg-white p-6 shadow-soft" }, _attrs))}><div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-50 text-blue-600"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" class="h-5 w-5">`);
      if (__props.icon === "book") {
        _push(`<path d="M4 5.5C4 4.67 4.67 4 5.5 4H12v16H5.5A1.5 1.5 0 0 1 4 18.5v-13Z"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "book") {
        _push(`<path d="M20 5.5C20 4.67 19.33 4 18.5 4H12v16h6.5a1.5 1.5 0 0 0 1.5-1.5v-13Z"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "file") {
        _push(`<path d="M6 3.5h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-16a1 1 0 0 1 1-1Z"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "file") {
        _push(`<path d="M8 12h8M8 16h8M8 8h4"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "eye") {
        _push(`<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "eye") {
        _push(`<circle cx="12" cy="12" r="2.6"></circle>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "draft") {
        _push(`<path d="M4 19.5 15 8.5l3 3-11 11H4v-3Z"></path>`);
      } else {
        _push(`<!---->`);
      }
      if (__props.icon === "draft") {
        _push(`<path d="M13 10.5l3-3 3 3-3 3"></path>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</svg></div><p class="mt-4 text-2xl font-bold text-gray-900">${ssrInterpolate_1(__props.value)}</p><p class="mt-1 text-sm text-gray-500">${ssrInterpolate_1(__props.label)}</p></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/admin/StatCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  setup(__props) {
    const blogs = vueExports.ref([]);
    const articles = vueExports.ref([]);
    const loading = vueExports.ref(true);
    const error = vueExports.ref("");
    const publishedBlogs = vueExports.computed(() => blogs.value.filter((b) => b.published));
    const draftBlogs = vueExports.computed(() => blogs.value.filter((b) => !b.published));
    const publishedArticles = vueExports.computed(
      () => articles.value.filter((a) => a.published)
    );
    const recentPosts = vueExports.computed(() => {
      return [
        ...blogs.value.map((b) => ({ ...b, kind: "Blog" })),
        ...articles.value.map((a) => ({ ...a, kind: "Article" }))
      ].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 6);
    });
    vueExports.onMounted(async () => {
      try {
        const [b, a] = await Promise.all([
          getBlogs({ publishedOnly: false }),
          getArticles({ publishedOnly: false })
        ]);
        blogs.value = b;
        articles.value = a;
      } catch (err) {
        error.value = 'Could not load Firestore data. Check your .env Firebase configuration and that the "blogs"/"articles" collections exist.';
      } finally {
        loading.value = false;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(`<div${ssrRenderAttrs_1(_attrs)}><div class="flex flex-wrap items-center justify-between gap-4"><div><h1 class="font-display text-2xl font-bold tracking-tight text-gray-900"> Dashboard </h1><p class="mt-1 text-sm text-gray-500"> An overview of everything published on cryptolearner.us. </p></div><div class="flex flex-wrap gap-3">`);
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-page-new" },
        class: "rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` New page `);
          } else {
            return [
              vueExports.createTextVNode(" New page ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-blog-new" },
        class: "rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-blue-700"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` New blog post `);
          } else {
            return [
              vueExports.createTextVNode(" New blog post ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent_1(_component_router_link, {
        to: { name: "admin-article-new" },
        class: "rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 transition-colors hover:bg-slate-50"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` New article `);
          } else {
            return [
              vueExports.createTextVNode(" New article ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
      if (error.value) {
        _push(`<p class="mt-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">${ssrInterpolate_1(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">`);
      _push(ssrRenderComponent_1(_sfc_main$1, {
        label: "Total blogs",
        value: loading.value ? "—" : blogs.value.length,
        icon: "book"
      }, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$1, {
        label: "Total articles",
        value: loading.value ? "—" : articles.value.length,
        icon: "file"
      }, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$1, {
        label: "Published",
        value: loading.value ? "—" : publishedBlogs.value.length + publishedArticles.value.length,
        icon: "eye"
      }, null, _parent));
      _push(ssrRenderComponent_1(_sfc_main$1, {
        label: "Drafts",
        value: loading.value ? "—" : draftBlogs.value.length,
        icon: "draft"
      }, null, _parent));
      _push(`</div><div class="mt-10 rounded-2xl border border-slate-200/80 bg-white shadow-soft"><div class="flex items-center justify-between border-b border-slate-100 px-6 py-5"><h2 class="text-base font-semibold text-gray-900">Recent posts</h2></div>`);
      if (loading.value) {
        _push(`<div class="px-6 py-10 text-center text-sm text-gray-400"> Loading… </div>`);
      } else if (!recentPosts.value.length) {
        _push(`<div class="px-6 py-10 text-center text-sm text-gray-400"> Nothing published yet — create your first post to see it here. </div>`);
      } else {
        _push(`<ul class="divide-y divide-slate-100"><!--[-->`);
        ssrRenderList_1(recentPosts.value, (post) => {
          _push(`<li class="flex items-center justify-between px-6 py-4"><div class="min-w-0"><p class="truncate text-sm font-medium text-gray-900">${ssrInterpolate_1(post.title)}</p><p class="mt-0.5 text-xs text-gray-400">${ssrInterpolate_1(post.kind)} · ${ssrInterpolate_1(vueExports.unref(formatDate)(post.createdAt))}</p></div><div class="flex items-center gap-3"><span class="${ssrRenderClass_1([
            post.published ? "bg-cyan-50 text-cyan-700" : "bg-slate-100 text-gray-500",
            "rounded-full px-2.5 py-1 text-xs font-medium"
          ])}">${ssrInterpolate_1(post.published ? "Published" : "Draft")}</span>`);
          _push(ssrRenderComponent_1(_component_router_link, {
            to: {
              name: post.kind === "Blog" ? "admin-blog-edit" : "admin-article-edit",
              params: { id: post.id }
            },
            class: "text-sm font-medium text-blue-600 hover:text-blue-700"
          }, {
            default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Edit `);
              } else {
                return [
                  vueExports.createTextVNode(" Edit ")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div></li>`);
        });
        _push(`<!--]--></ul>`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
