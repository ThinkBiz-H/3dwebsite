import { v as vueExports, g as gsapWithCSS, s as ssrRenderAttrs_1, c as ssrRenderList_1, f as ssrRenderClass_1, n as ssrRenderAttr_1, d as ssrInterpolate_1, b as ssrRenderComponent_1, q as ssrRenderStyle_1, o as useSeoMeta, O as SITE_URL } from "../entry-server.mjs";
import { g as getBlogs } from "./blogs-CoVMFDK3.mjs";
import { u as usePostListing, _ as _sfc_main$8, a as _sfc_main$9, b as _sfc_main$a } from "./LoadMore-BKFlF3Fv.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.mjs";
import { o as optimizedUrl } from "./cloudinary-oFvjB332.mjs";
import { p as prefetchRoute, _ as _sfc_main$7 } from "./AuthorAvatar--12iQkRN.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main$6 = {
  __name: "BlogSidebar",
  __ssrInlineRender: true,
  props: {
    categories: { type: Array, default: () => [] },
    // distinct category names, dynamic — no 'all'
    posts: { type: Array, default: () => [] },
    modelValue: { type: String, default: "all" }
    // 'all' | 'featured' | <category name>
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const listEl = vueExports.ref(null);
    const featuredCount = vueExports.computed(() => props.posts.filter((p) => p.featured).length);
    const categoryCounts = vueExports.computed(() => {
      const counts = /* @__PURE__ */ new Map();
      for (const p of props.posts) {
        if (!p.category) continue;
        counts.set(p.category, (counts.get(p.category) || 0) + 1);
      }
      return counts;
    });
    const items = vueExports.computed(() => [
      { key: "all", label: "All Articles", count: props.posts.length },
      { key: "featured", label: "Featured", count: featuredCount.value },
      ...props.categories.map((name) => ({
        key: name,
        label: name,
        count: categoryCounts.value.get(name) || 0
      }))
    ]);
    vueExports.onMounted(() => {
      gsapWithCSS.set(listEl.value?.children, { opacity: 0, x: -10 });
      gsapWithCSS.to(listEl.value?.children, {
        opacity: 1,
        x: 0,
        duration: 0.5,
        ease: "power3.out",
        stagger: 0.04,
        delay: 0.1
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs_1(vueExports.mergeProps({
        "aria-label": "Blog categories",
        class: "lg:sticky lg:top-24 lg:border-r lg:border-[#E8EEF5] lg:pr-6"
      }, _attrs))}><ul class="flex gap-1.5 overflow-x-auto [scrollbar-width:none] lg:block lg:space-y-1 lg:overflow-visible"><!--[-->`);
      ssrRenderList_1(items.value, (item) => {
        _push(`<li class="shrink-0 lg:shrink"><button type="button" class="${ssrRenderClass_1([__props.modelValue === item.key ? "bg-blue-50 text-blue-700" : "text-gray-600 hover:bg-slate-100", "group relative flex w-full items-center gap-2 whitespace-nowrap rounded-xl px-3.5 py-2.5 text-left text-sm transition-colors duration-200"])}"${ssrRenderAttr_1("aria-current", __props.modelValue === item.key ? "true" : void 0)}><span class="${ssrRenderClass_1([__props.modelValue === item.key ? "scale-y-100" : "scale-y-0", "absolute left-0 top-1/2 hidden h-4 w-[3px] -translate-y-1/2 rounded-full bg-blue-600 transition-transform duration-200 lg:block"])}"></span><span class="min-w-0 flex-1 truncate font-medium">${ssrInterpolate_1(item.label)}</span><span class="${ssrRenderClass_1([__props.modelValue === item.key ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-gray-400", "shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold tabular-nums"])}">${ssrInterpolate_1(item.count)}</span></button></li>`);
      });
      _push(`<!--]--></ul></nav>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/BlogSidebar.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<nav${ssrRenderAttrs_1(vueExports.mergeProps({
    "aria-hidden": "true",
    role: "presentation",
    class: "lg:sticky lg:top-24 lg:border-r lg:border-[#E8EEF5] lg:pr-6"
  }, _attrs))}><ul class="flex gap-1.5 overflow-x-auto [scrollbar-width:none] lg:block lg:space-y-1 lg:overflow-visible"><!--[-->`);
  ssrRenderList_1(5, (i) => {
    _push(`<li class="shrink-0 lg:shrink"><div class="flex w-full items-center gap-2 whitespace-nowrap rounded-xl px-3.5 py-2.5"><div class="skeleton-shimmer h-3.5 w-24 rounded-full lg:w-28"></div><div class="skeleton-shimmer ml-auto h-5 w-7 shrink-0 rounded-full"></div></div></li>`);
  });
  _push(`<!--]--></ul></nav>`);
}
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/BlogSidebarSkeleton.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const BlogSidebarSkeleton = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["ssrRender", _sfc_ssrRender$2]]);
const selectClass = "h-11 cursor-pointer appearance-none rounded-2xl border border-[#E8EEF5] bg-white pl-4 pr-9 text-sm font-medium text-gray-700 outline-none transition-colors duration-300 hover:border-slate-300 focus:border-blue-400 focus:ring-4 focus:ring-blue-100";
const _sfc_main$4 = {
  __name: "FilterBar",
  __ssrInlineRender: true,
  props: {
    difficulties: { type: Array, default: () => [] },
    // dynamic, includes 'all'; empty/['all'] hides the control
    difficulty: { type: String, default: "all" },
    readingTimeBucket: { type: String, default: "all" },
    sortBy: { type: String, default: "newest" }
  },
  emits: ["update:difficulty", "update:readingTimeBucket", "update:sortBy"],
  setup(__props) {
    const READING_TIME_OPTIONS = [
      { value: "all", label: "Any length" },
      { value: "under5", label: "Under 5 min" },
      { value: "5to10", label: "5–10 min" },
      { value: "over10", label: "10+ min" }
    ];
    const SORT_OPTIONS = [
      { value: "newest", label: "Newest" },
      { value: "oldest", label: "Oldest" },
      { value: "popular", label: "Popular" },
      { value: "trending", label: "Trending" }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "flex flex-wrap items-center gap-3" }, _attrs))}>`);
      if (__props.difficulties.length > 1) {
        _push(`<div class="relative"><select${ssrRenderAttr_1("value", __props.difficulty)} aria-label="Filter by difficulty" class="${ssrRenderClass_1(selectClass)}"><!--[-->`);
        ssrRenderList_1(__props.difficulties, (d) => {
          _push(`<option${ssrRenderAttr_1("value", d)}>${ssrInterpolate_1(d === "all" ? "Any difficulty" : d)}</option>`);
        });
        _push(`<!--]--></select><span class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">⌄</span></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="relative"><select${ssrRenderAttr_1("value", __props.readingTimeBucket)} aria-label="Filter by reading time" class="${ssrRenderClass_1(selectClass)}"><!--[-->`);
      ssrRenderList_1(READING_TIME_OPTIONS, (opt) => {
        _push(`<option${ssrRenderAttr_1("value", opt.value)}>${ssrInterpolate_1(opt.label)}</option>`);
      });
      _push(`<!--]--></select><span class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">⌄</span></div><div class="relative"><select${ssrRenderAttr_1("value", __props.sortBy)} aria-label="Sort articles" class="${ssrRenderClass_1(selectClass)}"><!--[-->`);
      ssrRenderList_1(SORT_OPTIONS, (opt) => {
        _push(`<option${ssrRenderAttr_1("value", opt.value)}>Sort: ${ssrInterpolate_1(opt.label)}</option>`);
      });
      _push(`<!--]--></select><span class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">⌄</span></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/FilterBar.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
    class: "flex flex-col gap-3 sm:flex-row sm:items-center",
    role: "presentation",
    "aria-hidden": "true"
  }, _attrs))}><div class="skeleton-shimmer h-12 w-full rounded-2xl sm:w-72"></div><div class="flex flex-wrap items-center gap-3"><div class="skeleton-shimmer h-11 w-32 rounded-2xl"></div><div class="skeleton-shimmer h-11 w-32 rounded-2xl"></div><div class="skeleton-shimmer h-11 w-32 rounded-2xl"></div></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/SearchFilterSkeleton.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const SearchFilterSkeleton = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$2 = {
  __name: "BlogGridCard",
  __ssrInlineRender: true,
  props: {
    post: { type: Object, required: true },
    basePath: { type: String, default: "/blog" }
  },
  setup(__props) {
    const props = __props;
    const PALETTE = [
      { bg: "#EAF2FF", fg: "#1D4ED8" },
      { bg: "#EAFBF3", fg: "#047857" },
      { bg: "#FFF3E0", fg: "#B45309" },
      { bg: "#F4EEFF", fg: "#6D28D9" },
      { bg: "#FDEAEF", fg: "#BE185D" },
      { bg: "#E8FBFC", fg: "#0E7490" }
    ];
    const categorySwatch = vueExports.computed(() => {
      const label = props.post.category || "";
      let hash = 0;
      for (let i = 0; i < label.length; i++)
        hash = (hash * 31 + label.charCodeAt(i)) % PALETTE.length;
      return PALETTE[Math.abs(hash)];
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_router_link = vueExports.resolveComponent("router-link");
      _push(ssrRenderComponent_1(_component_router_link, vueExports.mergeProps({
        to: `${__props.basePath}/${__props.post.slug}`,
        "data-cursor-hover": "",
        class: "group flex h-full flex-col overflow-hidden rounded-[24px] border border-[#E8EEF5] bg-white shadow-[0_10px_40px_rgba(15,23,42,0.05)] transition-all duration-[350ms] ease-out hover:-translate-y-2 hover:shadow-[0_24px_60px_-12px_rgba(15,23,42,0.14)]",
        onMouseenter: ($event) => vueExports.unref(prefetchRoute)("blog-details")
      }, _attrs), {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="aspect-video overflow-hidden rounded-t-[24px] bg-slate-100"${_scopeId}>`);
            if (__props.post.coverImage) {
              _push2(`<img${ssrRenderAttr_1("src", vueExports.unref(optimizedUrl)(__props.post.coverImage, { width: 640 }))}${ssrRenderAttr_1("alt", __props.post.title)} loading="lazy" class="h-full w-full object-cover transition-transform duration-[350ms] ease-out group-hover:scale-105"${_scopeId}>`);
            } else {
              _push2(`<div class="flex h-full w-full items-center justify-center text-sm text-gray-300"${_scopeId}> No cover image </div>`);
            }
            _push2(`</div><div class="flex flex-1 flex-col p-6"${_scopeId}><h3 class="text-lg font-semibold leading-snug text-gray-900 transition-colors duration-[350ms] group-hover:text-blue-600"${_scopeId}>${ssrInterpolate_1(__props.post.title)}</h3><p class="mt-2 line-clamp-2 text-sm leading-relaxed text-gray-500"${_scopeId}>${ssrInterpolate_1(__props.post.description)}</p>`);
            if (__props.post.category) {
              _push2(`<span class="mt-4 inline-flex w-fit items-center gap-1.5 text-xs font-semibold" style="${ssrRenderStyle_1({ color: categorySwatch.value.fg })}"${_scopeId}><span class="h-2 w-2 shrink-0 rounded-full" style="${ssrRenderStyle_1({ backgroundColor: categorySwatch.value.fg })}"${_scopeId}></span> ${ssrInterpolate_1(__props.post.category)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="mt-auto flex items-center gap-2 pt-5 text-sm text-gray-500"${_scopeId}>`);
            _push2(ssrRenderComponent_1(_sfc_main$7, {
              name: __props.post.author || "cryptolearner.us Team",
              size: "sm"
            }, null, _parent2, _scopeId));
            _push2(`<span class="font-medium text-gray-700"${_scopeId}>${ssrInterpolate_1(__props.post.author || "cryptolearner.us Team")}</span><span${_scopeId}>•</span><span${_scopeId}>${ssrInterpolate_1(__props.post.readingTime)} min read</span></div></div>`);
          } else {
            return [
              vueExports.createVNode("div", { class: "aspect-video overflow-hidden rounded-t-[24px] bg-slate-100" }, [
                __props.post.coverImage ? (vueExports.openBlock(), vueExports.createBlock("img", {
                  key: 0,
                  src: vueExports.unref(optimizedUrl)(__props.post.coverImage, { width: 640 }),
                  alt: __props.post.title,
                  loading: "lazy",
                  class: "h-full w-full object-cover transition-transform duration-[350ms] ease-out group-hover:scale-105"
                }, null, 8, ["src", "alt"])) : (vueExports.openBlock(), vueExports.createBlock("div", {
                  key: 1,
                  class: "flex h-full w-full items-center justify-center text-sm text-gray-300"
                }, " No cover image "))
              ]),
              vueExports.createVNode("div", { class: "flex flex-1 flex-col p-6" }, [
                vueExports.createVNode("h3", { class: "text-lg font-semibold leading-snug text-gray-900 transition-colors duration-[350ms] group-hover:text-blue-600" }, vueExports.toDisplayString(__props.post.title), 1),
                vueExports.createVNode("p", { class: "mt-2 line-clamp-2 text-sm leading-relaxed text-gray-500" }, vueExports.toDisplayString(__props.post.description), 1),
                __props.post.category ? (vueExports.openBlock(), vueExports.createBlock("span", {
                  key: 0,
                  class: "mt-4 inline-flex w-fit items-center gap-1.5 text-xs font-semibold",
                  style: { color: categorySwatch.value.fg }
                }, [
                  vueExports.createVNode("span", {
                    class: "h-2 w-2 shrink-0 rounded-full",
                    style: { backgroundColor: categorySwatch.value.fg }
                  }, null, 4),
                  vueExports.createTextVNode(" " + vueExports.toDisplayString(__props.post.category), 1)
                ], 4)) : vueExports.createCommentVNode("", true),
                vueExports.createVNode("div", { class: "mt-auto flex items-center gap-2 pt-5 text-sm text-gray-500" }, [
                  vueExports.createVNode(_sfc_main$7, {
                    name: __props.post.author || "cryptolearner.us Team",
                    size: "sm"
                  }, null, 8, ["name"]),
                  vueExports.createVNode("span", { class: "font-medium text-gray-700" }, vueExports.toDisplayString(__props.post.author || "cryptolearner.us Team"), 1),
                  vueExports.createVNode("span", null, "•"),
                  vueExports.createVNode("span", null, vueExports.toDisplayString(__props.post.readingTime) + " min read", 1)
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/BlogGridCard.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({
    class: "flex h-full flex-col overflow-hidden rounded-[24px] border border-[#E8EEF5] bg-white shadow-[0_10px_40px_rgba(15,23,42,0.05)]",
    role: "presentation",
    "aria-hidden": "true"
  }, _attrs))}><div class="aspect-video overflow-hidden rounded-t-[24px] bg-slate-100"><div class="skeleton-shimmer h-full w-full"></div></div><div class="flex flex-1 flex-col p-6"><div class="skeleton-shimmer h-5 w-11/12 rounded-full"></div><div class="skeleton-shimmer mt-2 h-5 w-2/3 rounded-full"></div><div class="skeleton-shimmer mt-3 h-3.5 w-full rounded-full"></div><div class="skeleton-shimmer mt-1.5 h-3.5 w-4/5 rounded-full"></div><div class="skeleton-shimmer mt-4 h-3.5 w-20 rounded-full"></div><div class="mt-auto flex items-center gap-2 pt-5"><div class="skeleton-shimmer h-7 w-7 rounded-full"></div><div class="skeleton-shimmer h-3.5 w-24 rounded-full"></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/components/sections/blog/BlogGridCardSkeleton.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const BlogGridCardSkeleton = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const PAGE_STEP = 9;
const _sfc_main = {
  __name: "Blog",
  __ssrInlineRender: true,
  setup(__props) {
    const {
      posts,
      loading,
      error,
      search,
      category,
      difficulty,
      readingTimeBucket,
      sortBy,
      categories,
      difficulties,
      isFiltering
    } = usePostListing(getBlogs);
    const activeSidebar = vueExports.ref("all");
    const sidebarCategories = vueExports.computed(
      () => categories.value.filter((c) => c !== "all")
    );
    const visibleCount = vueExports.ref(PAGE_STEP);
    const loadingMore = vueExports.ref(false);
    vueExports.watch(activeSidebar, (val) => {
      category.value = val === "featured" ? "all" : val;
    });
    vueExports.watch(
      [search, category, difficulty, readingTimeBucket, sortBy, activeSidebar],
      () => {
        visibleCount.value = PAGE_STEP;
      }
    );
    function matchesReadingTimeBucket(minutes, bucket) {
      if (bucket === "all") return true;
      const t = minutes || 0;
      if (bucket === "under5") return t < 5;
      if (bucket === "5to10") return t >= 5 && t <= 10;
      if (bucket === "over10") return t > 10;
      return true;
    }
    const gridPosts = vueExports.computed(() => {
      const q = search.value.trim().toLowerCase();
      const base = posts.value.filter((p) => {
        if (q && !p.title?.toLowerCase().includes(q) && !p.description?.toLowerCase().includes(q))
          return false;
        if (category.value !== "all" && p.category !== category.value) return false;
        if (difficulty.value !== "all" && p.difficulty !== difficulty.value)
          return false;
        if (!matchesReadingTimeBucket(p.readingTime, readingTimeBucket.value))
          return false;
        return true;
      });
      const sorted = [...base];
      if (sortBy.value === "oldest")
        sorted.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
      else if (sortBy.value === "popular")
        sorted.sort((a, b) => (b.views || 0) - (a.views || 0));
      else if (sortBy.value === "trending") {
        const score = (p) => {
          const ageDays = p.createdAt ? Math.max(1, (Date.now() - p.createdAt.getTime()) / 864e5) : 1;
          return (p.views || 0) / ageDays;
        };
        sorted.sort((a, b) => score(b) - score(a));
      } else sorted.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      return sorted;
    });
    const displayPosts = vueExports.computed(() => {
      if (activeSidebar.value === "featured")
        return posts.value.filter((p) => p.featured);
      return gridPosts.value;
    });
    const visiblePosts = vueExports.computed(
      () => displayPosts.value.slice(0, visibleCount.value)
    );
    const hasMore = vueExports.computed(() => visibleCount.value < displayPosts.value.length);
    function loadMore() {
      loadingMore.value = true;
      setTimeout(() => {
        visibleCount.value += PAGE_STEP;
        loadingMore.value = false;
      }, 250);
    }
    function clearFilters() {
      search.value = "";
      difficulty.value = "all";
      readingTimeBucket.value = "all";
      activeSidebar.value = "all";
    }
    const headerEl = vueExports.ref(null);
    const gridEl = vueExports.ref(null);
    vueExports.onMounted(() => {
      gsapWithCSS.fromTo(
        headerEl.value,
        { opacity: 0, y: 16 },
        { opacity: 1, y: 0, duration: 0.7, ease: "power3.out" }
      );
    });
    vueExports.watch(
      visiblePosts,
      async () => {
        await vueExports.nextTick();
        const cards = gridEl.value?.querySelectorAll("[data-blog-card]");
        if (!cards?.length) return;
        gsapWithCSS.fromTo(
          cards,
          { opacity: 0, y: 24 },
          { opacity: 1, y: 0, duration: 0.6, ease: "power3.out", stagger: 0.08 }
        );
      },
      { immediate: true }
    );
    useSeoMeta(() => ({
      title: "Blog",
      description: "Learn blockchain, wallets and crypto through simple articles.",
      path: "/blog",
      jsonLd: {
        "@context": "https://schema.org",
        "@type": "Blog",
        name: "cryptolearner.us Blog",
        url: `${SITE_URL}/blog`
      }
    }));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "bg-[#F7F9FC] pt-28 pb-10 sm:pt-32 sm:pb-14" }, _attrs))}><div class="mx-auto max-w-[1500px] px-6 lg:px-10"><div class="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between"><div><h1 class="font-display text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl"> Blog </h1><p class="mt-2 max-w-lg text-sm leading-relaxed text-gray-500"> Learn blockchain, wallets and crypto through simple articles. </p></div><div class="relative">`);
      if (vueExports.unref(loading)) {
        _push(ssrRenderComponent_1(SearchFilterSkeleton, { key: "search-filter-skeleton" }, null, _parent));
      } else {
        _push(`<div class="flex flex-col gap-3 sm:flex-row sm:items-center"><div class="sm:w-72">`);
        _push(ssrRenderComponent_1(_sfc_main$8, {
          modelValue: vueExports.unref(search),
          "onUpdate:modelValue": ($event) => vueExports.isRef(search) ? search.value = $event : null
        }, null, _parent));
        _push(`</div>`);
        _push(ssrRenderComponent_1(_sfc_main$4, {
          difficulty: vueExports.unref(difficulty),
          "onUpdate:difficulty": ($event) => vueExports.isRef(difficulty) ? difficulty.value = $event : null,
          "reading-time-bucket": vueExports.unref(readingTimeBucket),
          "onUpdate:readingTimeBucket": ($event) => vueExports.isRef(readingTimeBucket) ? readingTimeBucket.value = $event : null,
          "sort-by": vueExports.unref(sortBy),
          "onUpdate:sortBy": ($event) => vueExports.isRef(sortBy) ? sortBy.value = $event : null,
          difficulties: vueExports.unref(difficulties)
        }, null, _parent));
        _push(`</div>`);
      }
      _push(`</div></div>`);
      if (vueExports.unref(error)) {
        _push(`<p class="mt-8 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800" role="alert">${ssrInterpolate_1(vueExports.unref(error))}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-[260px_1fr]"><div class="relative">`);
      if (vueExports.unref(loading)) {
        _push(ssrRenderComponent_1(BlogSidebarSkeleton, { key: "sidebar-skeleton" }, null, _parent));
      } else {
        _push(ssrRenderComponent_1(_sfc_main$6, {
          key: "sidebar-real",
          modelValue: activeSidebar.value,
          "onUpdate:modelValue": ($event) => activeSidebar.value = $event,
          categories: sidebarCategories.value,
          posts: vueExports.unref(posts)
        }, null, _parent));
      }
      _push(`</div><div class="relative min-w-0">`);
      if (vueExports.unref(loading)) {
        _push(`<div class="grid grid-cols-1 gap-8 sm:grid-cols-2 xl:grid-cols-3"><!--[-->`);
        ssrRenderList_1(PAGE_STEP, (i) => {
          _push(ssrRenderComponent_1(BlogGridCardSkeleton, { key: i }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else if (!visiblePosts.value.length) {
        _push(ssrRenderComponent_1(_sfc_main$9, {
          key: "empty",
          title: vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? "No articles found" : "No articles yet",
          message: vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? "Try a different search term or clear your filters." : "New lessons and updates will show up here as soon as they’re published.",
          onClear: clearFilters
        }, vueExports.createSlots({ _: 2 }, [
          vueExports.unref(isFiltering) || activeSidebar.value !== "all" ? {
            name: "action",
            fn: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Clear filters`);
              } else {
                return [
                  vueExports.createTextVNode("Clear filters")
                ];
              }
            }),
            key: "0"
          } : void 0
        ]), _parent));
      } else {
        _push(`<div><div class="grid grid-cols-1 gap-8 sm:grid-cols-2 xl:grid-cols-3"><!--[-->`);
        ssrRenderList_1(visiblePosts.value, (post) => {
          _push(ssrRenderComponent_1(_sfc_main$2, {
            key: post.id,
            post,
            "base-path": "/blog",
            "data-blog-card": ""
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
        if (hasMore.value) {
          _push(`<div class="mt-12 flex justify-center">`);
          _push(ssrRenderComponent_1(_sfc_main$a, {
            loading: loadingMore.value,
            onClick: loadMore
          }, null, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      }
      _push(`</div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/Blog.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
