import { u as useRoute, a as useRouter, v as vueExports, s as ssrRenderAttrs_1, n as ssrRenderAttr_1, d as ssrInterpolate_1, b as ssrRenderComponent_1, _ as _sfc_main$1 } from "../entry-server.mjs";
import { useAuthStore } from "./auth-BWvem-zv.mjs";
import "node:stream";
import "util";
import "crypto";
import "process";
import "tls";
import "fs";
import "os";
import "net";
import "events";
import "stream";
import "path";
import "http2";
import "http";
import "url";
import "dns";
import "zlib";
const _sfc_main = {
  __name: "Login",
  __ssrInlineRender: true,
  setup(__props) {
    useRoute();
    useRouter();
    useAuthStore();
    const fields = vueExports.reactive({ email: "", password: "" });
    const error = vueExports.ref("");
    const loading = vueExports.ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs_1(vueExports.mergeProps({ class: "w-full max-w-sm rounded-2xl border border-slate-200/80 bg-white p-8 shadow-lift" }, _attrs))}><div class="text-center"><div class="font-display text-xl font-semibold tracking-tight text-gray-900"> cryptolearner.us </div><p class="mt-2 text-sm text-gray-500"> Sign in to manage blogs and articles. </p></div><form class="mt-8 space-y-4"><div><label class="text-sm font-medium text-gray-700" for="email">Email</label><input id="email"${ssrRenderAttr_1("value", fields.email)} type="email" required class="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100" placeholder="you@lumenledger.com"></div><div><label class="text-sm font-medium text-gray-700" for="password">Password</label><input id="password"${ssrRenderAttr_1("value", fields.password)} type="password" required class="mt-2 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-gray-900 outline-none transition-colors focus:border-blue-400 focus:ring-2 focus:ring-blue-100" placeholder="••••••••"></div>`);
      if (error.value) {
        _push(`<p class="text-sm text-red-500">${ssrInterpolate_1(error.value)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent_1(_sfc_main$1, {
        as: "button",
        type: "submit",
        class: "w-full"
      }, {
        default: vueExports.withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate_1(loading.value ? "Signing in…" : "Sign in")}`);
          } else {
            return [
              vueExports.createTextVNode(vueExports.toDisplayString(loading.value ? "Signing in…" : "Sign in"), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</form></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = vueExports.useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("src/pages/admin/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
